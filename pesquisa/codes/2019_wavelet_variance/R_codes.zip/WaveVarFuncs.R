#########################
#########################
## mean type estimate

# This function returns a matrix of length mscale x 3, where the first
#  column has the estimated wavelet variances for a time series and
# the second and third columns have their corresponding lower and upper bound 
# of a 95% confidence interval, respectivelly. These bounds are computed using
# the Theorem 1 of Serrouk et al (2000), who showed that the wavelet variance
# estimator has asymptotic normal distribution under some conditions (needs at
# least the first four moments finite) even when for non-Gaussian processes.
# Then, their approximation for the variance of the wavelet variance estimator
# is used to compute the bounds.
# The inputs are:
# x: the data set
# L: length of the wavelet filter used
# wf: wavelet filter used
# mscale: name of the wavelet filter used
# dpss: list with data tapers for each wavelet level
# lampplus: list with the sum of each data tapers at each wavelet level
w.variance.n <-function(x, L, wf, mscale, dpss, lamplus)
{
  # sample size
  n=length(x)
  
  obsxwvar = vest = upciobsx = lociobsx = rep(0,mscale)
  # Obtaining the MODWT coefficients for obsx
  obsxw = modwt(x, n.levels=mscale, wf=wf)
  
  for(jscale in 1:mscale){
    # length of the j-th level MODWT wavelet filter
    Lj=(2^jscale-1)*(L-1)+1    
    # number of wavelet coefficients used to estimate the wavelet variance
    pp=n-Lj+1
    # estimating the j-th level wavelet variance
    obsxwvar[jscale] = mean(obsxw[[jscale]][Lj:n]^2)
    
    # multiplying the squared wavelet coefficients used to estimate the 
    # j-th level wavelet variance to each of the 5 tapers in the j-th
    # element of the list dpss. The result is a 1x5 vector
    J = (obsxw[[jscale]][Lj:n]^2)%*%dpss[[jscale]]
    # Least-square estimator of the wavelet variance. See Equation (12) of
    # Serrouk et al (2000)
    u0= J%*%t(lamplus[[jscale]])/sum(lamplus[[jscale]]^2)
    # approximation to the variance of the wavelet variance esimator
    # proposed by Serrouk et al (2000, Equation (13))
    vest[jscale] = mean((J-c(u0)*lamplus[[jscale]])^2)/pp
    # upper bound of the confidence interval
    upciobsx[jscale]= obsxwvar[jscale] + qnorm(.975) *  sqrt(vest[jscale])
    # lower bound of the confidence interval
    lociobsx[jscale]= obsxwvar[jscale] + qnorm(.025) *  sqrt(vest[jscale])
  }
  # returning a matrix with the wavelet coefficients and its respective
  # confidence interval
  return(cbind(obsxwvar, lociobsx, upciobsx))
  
}



#########################
#########################
#median type estimator

w.variance.r <-function(x, L, wf, mscale, dpss, lamplus)
{
  # sample size
  n=length(x)
  
  logrobsxci=robustobsxwvar=robustobsci=logrobsxwvar=logrobsupci=logrobsloci=rep(0,mscale)
  # Obtaining the MODWT coefficients for obsx
  obsxw = modwt(x, n.levels=mscale, wf=wf)
  
  for(jscale in 1:mscale){
    # length of the j-th level MODWT wavelet filter
    Lj = (2^jscale-1)*(L-1)+1
    # number of wavelet coefficients used to estimate the wavelet variance
    pp = n-Lj+1
    # robust estimator Tn of the solution point mu0
    robustobsxwvar[jscale] = median(log(obsxw[[jscale]][Lj:n]^2)) 
    # signal of the difference of the log transformation of the coefficients
    # and the robust estimate of mu0
    ser=sign( log(obsxw[[jscale]][Lj:n]^2) - robustobsxwvar[jscale] )
    # obtaining the Jk of Mondal and Percival (2010, Equation (11)), which
    # are the elements of the vector multiplied by the data tapers for level
    # j in dpss
    J = ser%*%dpss[[jscale]]
    # least square estimate of mu0
    u0 = J%*%t(lamplus[[jscale]])/sum(lamplus[[jscale]]^2)
    # Estimate of the term A_phi given in Equation (12) of Mondal and 
    # Percival (2010) divided by their term B, the number of coefficients
    # this term appears in Equation (15) as $\hat{\sigma}^2/B$
    robustobsci[jscale] = mean((J-c(u0)*lamplus[[jscale]])^2)/pp
    # derivative of the lambda function sign evaluated at the solution point
    # mu0, see Mondal and Percival (2010, Equation (13))
    lammu = abs(-2*dnorm(qnorm(.75))*qnorm(.75))
    logrobsxwvar[jscale] = robustobsxwvar[jscale] - 2*log(qnorm(.75))
    # approximate variance of the estimator Tn of the solution point mu0, given
    # in the Theorem 1 of Mondal and Percival (2010)
    logrobsxci[jscale] = robustobsci[jscale]/lammu^2
    # upper bound of the confidence interval for mu0
    logrobsupci[jscale] = logrobsxwvar[jscale] + 1.96 * sqrt(logrobsxci[jscale])
    # lower bound of the confidence interval for mu0
    logrobsloci[jscale] = logrobsxwvar[jscale] - 1.96 * sqrt(logrobsxci[jscale])
  }
  
  # we return a matrix where the second column contains the robust estimators
  # given in Equation (15) of Mondal and Percival (2010), and the first and
  # third columns contain their corresponding lower and upper bands of a 95%
  # confidence interval
  return(cbind(exp(logrobsxwvar - logrobsxci/2 ),
               exp(logrobsloci - logrobsxci/2 ),
               exp(logrobsupci - logrobsxci/2 )))
}

#########################
#########################
## stable estimators


# This function returns a matrix of length mscale x 3, where the first
#  column has the estimated wavelet variances for the time series with
# stable distributed innovations, and the second and third
# columns have their corresponding lower and upper bound of a conflev*100%
# confidence interval, respectivelly. The inputs are:
# x: the data set
# L: length of the wavelet filter used
# wf: wavelet filter used
# mscale: name of the wavelet filter used
# alpha: estimate of the stable index
# conflev: level of the confidence intervals
w.variance.s <-function(x, L, wf, mscale, alpha, conflev)
{
  
  # length of the data set
  n = length(x)
  # the vector obsxwar will store the observed wavelet variances and the
  # vcotors upciobsx and lociobsx will store, respectivelly, the upper and 
  # lower bounds of the wavelet variance confidence interval
  obsxwvar = upciobsx = lociobsx =rep(0,mscale)
  # Obtaining the MODWT coefficients for obsx
  obsxw = modwt(x, n.levels=mscale, wf=wf)
  
  # scale parameter estimated
  sigma = (gamma(1 - alpha/2)*cos(pi*alpha/4))^(2/alpha)
  # the functions setParam and qEstable are from the package FMStable. The first
  # is used to set the parameters of the stable distribution we want to 
  # analyze, and it returns an object that is used in other functions.
  # qEstable is used to computes quantiles.
  # Here we ser pm=S1 to use the same parametrization of Samorodnitsky and 
  # Taqqu (1994), which is also the same for the characteristic function 
  # presented in Equation 8 of Anderson and Meerschaert (1998).
  stablePar = setParam(alpha=alpha/2,location = 0, logscale = log(sigma), pm = "S1")
  # quantiles used to compute the conflev*100% confidence interval
  s1 = qEstable((1 - conflev)/2, stablePar, log=FALSE, lower.tail=TRUE)
  s2 = qEstable(.5 + conflev/2, stablePar, log=FALSE, lower.tail=TRUE)
  
  for(jscale in 1:mscale){
    # length of the j-th level MODWT wavelet filter
    Lj=(2^jscale-1)*(L-1)+1
    # number of wavelet coefficients used to estimate the wavelet variance
    Mj=n-Lj+1
    # norming constant a_Mj suggested in the paper
    aMj=Mj^(1/alpha)
    # estimating the j-th level wavelet variance
    obsxwvar[jscale] = mean(obsxw[[jscale]][Lj:n]^2)
    # upper bound of the confidence interval
    upciobsx[jscale]= obsxwvar[jscale]/(1 + s1*(aMj^2)/Mj)
    # lower bound of the confidence interval
    lociobsx[jscale]= obsxwvar[jscale]/(1 + s2*(aMj^2)/Mj)
  }
  # returning a matrix with the wavelet coefficients and its respective
  # confidence interval
  return(cbind(obsxwvar, lociobsx, upciobsx))
  
}


# function to create a plot with the time series formed by wavelet 
# coefficients at each decomposition level
# The inputs are the following.
# y: list with the modwt transform of the time series
# wf: wavelet filter used
# mscale: number of time scales used
fWaveCoefTS = function(y,wf,mscale){
  # length of the time series
  n = length(y[[1]])
  # length of the Daubechies filter used
  L = length(wavelet.filter(wf))
  # matrix to store the MODWT coefficients
  wcoef = matrix(NA,n, mscale)
  
  for(jscale in 1:mscale){
    # length of the j-th level MODWT wavelet filter
    Lj=(2^jscale-1)*(L-1)+1
    # storing the Nj = n - Lj + 1 MODWT coefficients for j-th level
    # in the matrix wcoef
    wcoef[(Lj/2):(n-Lj/2), jscale]  = y[[jscale]][Lj:n]
  }
  
  ## modwt plot
  names.w <- c(expression(W[1]), expression(W[2]), expression(W[3]), expression(W[4]), expression(W[5]),expression(W[6]), expression(W[7]), expression(W[8]), expression(W[9]), expression(W[10]), expression(W[11]), expression(W[12]), expression(W[13]), expression(W[14]), expression(W[15]) )
  
  par(mfcol=c(mscale+1,1), pty="m", mar=c(0,4,0,0), cex=1.25)
  for(i in 1:mscale)
    plot.ts(wcoef[,i], axes=FALSE, ylab=names.w[i])
  plot.ts(rep(0,n), axes=F , ylab=" ", ylim=c(-1,0))
  text(n/2,-.75, "time")
}

#########################
#########################

# Function to plot the logarithm of wavelet variances with a segmented line
# at the characteristic scale estimate when a peak is found. A matrix is also
# returned, where the first column has the indeces where a peak is found, 
# the third column contains the characteristic scale estimates, and the 
# second and fourth columns have their respective approximate 95% confidence
# intervals.
# The inputs are the following.
# y: list with the modwt transform of the time series
# wf: wavelet filter used
# mscale: number of time scales used
# alpha: estimate of the tail index of the time series
# Nrep: number of replication used in the simulation to compute approximate
# 95% confidence intervals for the characteristic scales
# subtitle: variable with a subtitle text if not null
fCharScal = function(y,wf,mscale,Nrep, alpha,subtitle=NULL){
  # length of the time series
  n = length(y[[1]])
  # length of the Daubechies filter used
  L = length(wavelet.filter(wf))
  
  ## stable estimators
  # scale parameter estimated
  sigma = (gamma(1 - alpha/2)*cos(pi*alpha/4))^(2/alpha)
  # norming constant a_N suggested in the paper
  bn = n^(1/alpha)
  
  # matrix to store the sequences a_Mj and the number of coefficients Mj
  wvar = rep(0,mscale)
  wvar.aMj = matrix(0,mscale,2)
  for(jscale in 1:mscale){
    # length of the j-th level MODWT wavelet filter
    Lj=(2^jscale-1)*(L-1)+1
    # estimating the j-th level wavelet variance
    wvar[jscale] = mean(y[[jscale]][Lj:n]^2)
    # number of wavelet coefficients used to estimate the wavelet variance
    wvar.aMj[jscale,2] = n-Lj+1
    # norming constant a_Mj suggested in the paper
    wvar.aMj[jscale,1] = (wvar.aMj[jscale,2])^(1/alpha)
  }
  
  
  # matrix to store which levels contain a local characteristic scale
  # For each row, if the value on the first column is zero, the corresponding
  # level does not contain a local characteristic scale, otherwise it will have
  # the value of the level with the corresponding characteristic scale on the
  # same row on the second column
  mLocCha = matrix(0,mscale-2,2)
  for(j in 2:(mscale-1)){
    # checking if the j-th wavelet variance is a local maximum
    if((wvar[j]>wvar[j-1])&&(wvar[j]>wvar[j+1])){
      # level with a local characteristic scale
      mLocCha[j-1,1] = j
      # computing the characteristic scale estimate using Equation (3) of
      # Keim and Percival (2015)
      b1 = (log2(wvar[j+1]) - log2(wvar[j-1]))/2
      b2 = log2(wvar[j+1]) - 2*log2(wvar[j]) + log2(wvar[j-1])
      mLocCha[j-1,2] = (2^(-b1/b2))*(2^(j-1))
    }
  }
  
  # Here we simulate from the large sample distribution of the wavelet variances
  # to compute approximate confidence intervals for the characteristic scales
  
  # matrix to store if a characteristic was obtained (1 if yes and 0 if no) in the
  # 1st column and the characteristic scale estimate in the second if 1
  mCharScMC = matrix(0,Nrep,2)
  # matrix to store the approximate confidence interval in the 1st and 3rd columns
  # and the characteristic scale estimate in the 2nd column
  mCIcharsc = matrix(0,sum(mLocCha[,1]!=0),3)
  cont = 1  # counting variable
  
  # plot of the wavelet variances where we shall draw confidence intervals in the
  # characteristic scale estimates
  if(is.null(subtitle)){
    plot(c(0:(mscale-1)),log2(wvar),ylab=" ",xlab=expression(log[2](tau[j]^2)))
    title(ylab=expression(log[2](nu[j]^2)),line=2, cex.lab=1)
  }else{
    plot(c(0:(mscale-1)),log2(wvar),ylab=" ",ann = "FALSE")
    title(ylab=expression(log[2](nu[j]^2)),xlab=expression(log[2](tau[j]^2)),line=2.5, cex.lab=1)
    title(xlab = subtitle,line=3.5, cex.lab=1.3)
  }
  
  for(j in mLocCha[mLocCha[,1]!=0,1]){
    # fitting  a quadratic function to the log2 of the wavelet variance
    # and log2 of the time scale
    vlogt = c(j-2,j-1,j)
    vlogt2 = vlogt^2
    mX = cbind(rep(1,3),vlogt,vlogt2)
    vlogwvar = log2(wvar[c(j-1,j,j+1)])
    vcoef = solve(mX)%*%vlogwvar
    # estimate of the characteristic scale
    abline(v=-vcoef[2]/(2*vcoef[3]),lty=2)
    # plotting the quadratic fit
    mX = cbind(rep(1,100),seq(j-2,j,length=100),seq(j-2,j,length=100)^2)
    vY = mX%*%vcoef
    lines(seq(j-2,j,length=100),vY)
    # simulating from the large sample of the wavelet variance
    for(i in 1:Nrep){
      # common stable random variable
      S1 = rstable(1,alpha=alpha/2,beta=1,gamma = sigma, delta = 0, pm = 1)
      # simulated wavelet variances
      v1 = wvar[j-1]*(1 + S1*(wvar.aMj[j+1,1]^2)/wvar.aMj[j-1,2])
      v2 = wvar[j]*(1 + S1*(wvar.aMj[j+1,1]^2)/wvar.aMj[j,2])
      v3 = wvar[j+1]*(1 + S1*(wvar.aMj[j+1,1]^2)/wvar.aMj[j+1,2])
      if((v2>v1)&&(v2>v3)){
        # simulated characteristic scale
        mCharScMC[i,1] = 1
        b1 = (log2(v3) - log2(v1))/2
        b2 = log2(v3) - 2*log2(v2) + log2(v1)
        mCharScMC[i,2] = (2^(-b1/b2))*(2^(j-1))
      }
    }
    # 95% confidence interval and the estimate of the characteristic scale
    mCIcharsc[cont,1] = quantile(mCharScMC[mCharScMC[,1]!=0,2],c(.025))
    mCIcharsc[cont,2] = 2^(-vcoef[2]/(2*vcoef[3]))
    mCIcharsc[cont,3] = quantile(mCharScMC[mCharScMC[,1]!=0,2],c(.975))
    # maximum of the quadratic curve
    ymax = c(1,log2(mCIcharsc[cont,2]),log2(mCIcharsc[cont,2])^2)%*%vcoef
    # limits of the confidence interval
    vxquant = log2(c(mCIcharsc[cont,1],mCIcharsc[cont,3]))
    cont = cont + 1
    # cleaning the matrices with characteristic scale obtained
    mCharScMC = matrix(0,Nrep,2)
  }
  
  # confidence interval of the characteristic scales
  return(cbind(which(mLocCha[,1]!=0) + 1, mCIcharsc))
}


# function that plots the (natural) logarithm of the wavelet 
# variances of first differences of the time series
# The inputs are
# x: time series
# wf: wavelet filter used
# mscale: number of time scales used
fLogWaveVar1Diff = function(x,wf,mscale,subtitle=NULL){
  # length of the time series
  n = length(x)
  # length of the Daubechies filter used
  L = length(wavelet.filter(wf))
  # wavelet coefficients of the first difference of the time series
  diffwv = modwt(diff(x),wf = wf, n.levels = mscale)
  # computing the wavelet variances of the first difference
  wvar_diffwv = rep(0,mscale)
  for(jscale in 1:mscale){
    Lj=(2^jscale-1)*(L-1)+1
    wvar_diffwv[jscale] = mean(diffwv[[jscale]][Lj:(n-1)]^2)
  }
  if(is.null(subtitle)){
    plot(log(wvar_diffwv),ann=FALSE)
    title(ylab=expression(log(nu[list(j,Y)]^2)),xlab="j",line=2, cex.lab=1.3)
    fit = lm(log(wvar_diffwv)~seq(1:mscale))
    abline(fit)
  }else{
    plot(log(wvar_diffwv),ann=FALSE)
    title(ylab=expression(log(nu[list(j,Y)]^2)),xlab="j",line=2, cex.lab=1.3)
    title(xlab = subtitle,line=3.5, cex.lab=1.3)
    fit = lm(log(wvar_diffwv)~seq(1:mscale))
    abline(fit)
  }
  
  return(fit)
}


##################################################################
##################################################################
# Functions to compute bias corrected estimators

# function used in the function fTn
fMn = function(x.order,j,k){
  n = length(x.order)
  M = sum(log(x.order[(n-k+1):n]/x.order[n-k])^j)/k
  return(M)
}

# function used in the function fRhoHat. See Equation (3.1) of Gomes et al
# (2008, JRSS-B).
fTn = function(x.order,tau,k){
  n = length(x.order)
  M1 = fMn(x.order,1,k)
  M2 = fMn(x.order,2,k)
  M3 = fMn(x.order,3,k)
  if(tau==0){
    Tn = (log(M1) - log(M2/2)/2)/(log(M2/2)/2 - log(M3/6)/3)
  }else{
    Tn = ((M1^tau) - (M2/2)^(tau/2))/((M2/2)^(tau/2) - (M3/6)^(tau/3))
  }
  return(Tn)
}

# Function to estimate the second order shape parameter of the asymptotic
# distribution of Hill estimator.
# Inputs
# x.order: order statistics of the data
# tau: tuning parameter. Simplest option if {0,1}
# k: number of upper order statistics used to estimate rho
fRhoHat = function(x.order,tau,k){
  Tn = fTn(x.order,tau,k)
  r = -abs(3*(Tn - 1)/(Tn - 3))
  return(r)
}

# Function to compute a vector of scaled log-spacings. See Eq. (2.7) of
# Gomes et al (2008).
fScLogSpac = function(x.order,k){
  n = length(x.order)
  vW = rep(0,k)
  for(i in 1:k) vW[i] = i*(log(x.order[n-i+1]) - log(x.order[n-i]))
  return(vW)
}

# function to compute weighted average of scaled log-spacings. See Eq. (3.5) of
# Gomes et al (2008).
fEq3.5 = function(k,a,vW){
  return( sum(((c(1:k)/k)^a)*vW/k) )
}

# Function to estimate the second order scale parameter of the asymptotic
# distribution of Hill estimator.
# Inputs
# x.order: order statistics of the data
# r: an estimate of the second order shape parameter
# k: number of upper order statistics used to estimate rho
fBetaHat = function(x.order,r,k){
  n = length(x.order)
  vW = fScLogSpac(x.order,k)
  
  dr = fEq3.5(k,-r,rep(1,k))
  D0 = fEq3.5(k,0,vW)
  Dr = fEq3.5(k,-r,vW)
  D2r = fEq3.5(k,-2*r,vW)
  
  beta = ((k/n)^r)*(dr*D0 - Dr)/(dr*Dr - D2r)
  
  return(beta)
}

# Algorithm in section 2.3 of Gomes et al (2008). It is used to select the
# tunning parameter used to compute the second order shape parameter rho,
# returning the best option in a vector of possible values.
# Inputs
# x.order: order statistics of the data
# vTau: vector of tau values to be evaluated
# showPlot: conditional variable to show or not a plot with the squared
# differences to the median of rho values
fFindTau = function(x.order,vTau,showPlot=FALSE){
  n = length(x.order)
  n0 = min(which(x.order>0))
  vK = seq(ceiling(n^0.995),floor(n^0.999),1)-n0+1
  nK = length(vTau)
  vSS = rep(0,nK)
  for(i in 1:nK){
    vRhoK = sapply(vK,function(k) fRhoHat(x.order,vTau[i],k))
    medianRhoK = median(vRhoK)
    vSS[i] = sum((vRhoK - medianRhoK)^2)
  }
  
  if(showPlot) plot(vTau,vSS,ylab="Sum of squares",xlab=expression(tau))
  
  return(vTau[which(vSS==min(vSS))])
}

# Bias corrected Hill estimator, given by the weighted combination of log
# excesses. See Eq. (2.13) of Gomes et al (2013, JRSS-B)
fWLE = function(x.order,k,b,r){
  n = length(x.order)
  vWLE = rep(0,k)
  for(i in 1:(k-1)){
    psi_ik = -((i/k)^(-r) - 1)/(r*log(i/k))
    vWLE[i] = exp(-b*psi_ik*((n/k)^r))*(log(x.order[n-i+1]) - log(x.order[n-k]))
  }
  vWLE[k] = exp(-b*((n/k)^r))*(log(x.order[n-k+1]) - log(x.order[n-k]))
  
  return(sum(vWLE)/k)
}

# Ordinary Hill estimator for the tail index
fHill = function(x.order,k){
  n = length(x.order)
  
  Hk = sum(c(k:1)*log(x.order[(n-k+1):n]/x.order[(n-k):(n-1)]))/k
  
  return(Hk)
}

# Quick estimator of the tail index proposed by Gomes and Pestana (2007), see
# their Equation (3.8)
fHillquick = function(x.order){
  n = length(x.order)
  rhohat = -1
  betahat = 1
  # We use the optimal k for Hill estimator presented by Gomes and Pestana
  # (2007), see their Equation (3.2)
  k = ( ((1-rhohat)*(n^(-rhohat)))/(betahat*sqrt(-2*rhohat)) )^(2/(1-2*rhohat))
  
  Hk = sum(c(k:1)*log(x.order[(n-k+1):n]/x.order[(n-k):(n-1)]))/k
  
  return(Hk*(1-k/(2*n)))
}


# function to copute the bias corrected estimator WLE of Gomes et al (2008)
# in their application section, where the estimate is take as the median of
# WLE estimates computed for the number of upper order statistics varying in
# a specific range. See pg. 47 of Gomes et al (2008).
# x.order: order statistics of the data
# beta.hat: estimate of the second order scale parameter in Gomes et al (2008)
# rho.hat: estimate of the second order shape parameter in Gomes et al (2008)
# showplot: conditional variable to show or not a plot of WLE and Hill
# estimates for different values of k with 95% confidence intervals
fWLE_median_based = function(x.order,beta.hat,rho.hat,n0,showplot=0,subtitle=NULL){
  # lower and upper bounds of the range where the number k of upper order
  # statistics varies
  n_li = max(round((n0^(-2*rho.hat/(1-2*rho.hat)))/4),1)
  n_ls = max(round(4*(n0^(-2*rho.hat/(1-2*rho.hat)))), n_li)
  # computing the WLE and Hill estimates with confidence intervals
  mWLE = mHill = matrix(0,n_ls - n_li + 1,3)
  for(k in n_li:n_ls){
    # Bias corrected Hill estimate and its corresponding confidence intervals
    mWLE[k-n_li+1,2] = fWLE(x.order,k,beta.hat,rho.hat)
    mWLE[k-n_li+1,1] = mWLE[k-n_li+1,2]/(1 + 1.96/(k^0.5))
    mWLE[k-n_li+1,3] = mWLE[k-n_li+1,2]/(1 - 1.96/(k^0.5))
    
    # Ordinary Hill estimate and its corresponding confidence intervals
    mHill[k-n_li+1,2] = fHill(x.order,k)
    mHill[k-n_li+1,1] = mHill[k-n_li+1,2]/(1 + 1.96/(k^0.5) + 
                                             beta.hat*((n0/k)^rho.hat)/(1-rho.hat))
    mHill[k-n_li+1,3] = mHill[k-n_li+1,2]/(1 - 1.96/(k^0.5) + 
                                             beta.hat*((n0/k)^rho.hat)/(1-rho.hat))
  }
  
  # if rhho.hat is close to zero, we might have n_ls<10 and problems when
  # making the plot 
  if(showplot==1){
    # estimates from WLE
    x_li = max(n_li,10)
    plot(c(x_li:n_ls),mWLE[(x_li-n_li+1):length(mWLE[,2]),2],type="l",lwd=2,ann=FALSE,
         ylim=c(min(mWLE[(x_li-n_li+1):length(mWLE[,2]),],.25),
                max(mWLE[(x_li-n_li+1):length(mWLE[,2]),],.5)))
    title(ylab="WLE(k)", xlab="k",line=2, cex.lab=1.3)
    if(is.null(subtitle)){
      title(main="WLE")
    }else{
      title(xlab = subtitle,line=3.2, cex.lab=1.3)
    }
    lines(c(x_li:n_ls),mWLE[(x_li-n_li+1):length(mWLE[,2]),1],type="l",lty=1,lwd=0.5)
    lines(c(x_li:n_ls),mWLE[(x_li-n_li+1):length(mWLE[,2]),3],type="l",lty=1,lwd=0.5)
    abline(h=c(.5,.25))
  }
  
  if(showplot==2){
    # estimates from WLE
    x_li = max(n_li,10)
    par(mfrow=c(1,2))
    plot(c(x_li:n_ls),mWLE[(x_li-n_li+1):length(mWLE[,2]),2],type="l",lwd=2,ann=FALSE,
         ylim=c(min(mWLE[(x_li-n_li+1):length(mWLE[,2]),],.25),
                max(mWLE[(x_li-n_li+1):length(mWLE[,2]),],.5)))
    title(ylab="WLE(k)", xlab="k",line=2, cex.lab=1.3)
    if(is.null(subtitle)){
      title(main="WLE")
    }else{
      title(xlab = subtitle[1],line=3.2, cex.lab=1.3)
    }
    lines(c(x_li:n_ls),mWLE[(x_li-n_li+1):length(mWLE[,2]),1],type="l",lty=1,lwd=0.5)
    lines(c(x_li:n_ls),mWLE[(x_li-n_li+1):length(mWLE[,2]),3],type="l",lty=1,lwd=0.5)
    abline(h=c(.5,.25))
    # estimates from Hill estimator
    plot(c(x_li:n_ls),mHill[(x_li-n_li+1):length(mHill[,2]),2],type="l",lwd=2,ann=FALSE,
         ylim=c(min(mHill[(x_li-n_li+1):length(mHill[,2]),],.25),
                max(mHill[(x_li-n_li+1):length(mHill[,2]),],.5)))
    title(ylab=expression(hat(lambda)[H]), xlab="k",line=2, cex.lab=1.3)
    if(is.null(subtitle)){
      title(main="Hill estimator")
    }else{
      title(xlab = subtitle[2],line=3.2, cex.lab=1.3)
    }
    lines(c(x_li:n_ls),mHill[(x_li-n_li+1):length(mHill[,2]),1],type="l",lty=1,lwd=0.5)
    lines(c(x_li:n_ls),mHill[(x_li-n_li+1):length(mHill[,2]),3],type="l",lty=1,lwd=0.5)
    abline(h=c(.5,.25))
    
  }
  return(median(mWLE[,2]))
}


# function to create the AltHill plot of Drees et al (2000). In the horizontal
# lines in the plots show the region where the tail index alpha is between
# 2 and 4
# subtitle: vector with subtitle for the two plots is not null
# parplot: if true, both plots will be displayed side by side, and if false
# they will be plotted separately (useful to use with par outside the function)
fAltHillplot = function(x.order,n0,subtitle=NULL,hillplot=TRUE){
  # vector of powers of the sample size
  vTheta = seq(0,.99,length=(n0-1))
  
  vAltHill = vHill = rep(0,(n0-1))
  for(i in 10:(n0-10)){
    k = ceiling(n0^vTheta[i])
    vAltHill[i] = fHill(x.order,k)
    vHill[i] = fHill(x.order,i)
  }
  # limits of the y axis in the plot
  lo_Hill = min(vHill[c(10:(n0-10))],.25)
  up_Hill = max(vHill[c(10:(n0-10))], .5)
  lo_AltHill = min(vHill[c(10:(n0-10))],.25)
  up_AltHill = max(vHill[c(10:(n0-10))], .5)
  
  if(is.null(subtitle)){
    if(hillplot){
      par(mfrow=c(1,2))
      plot(c(10:(n0-10)),vHill[c(10:(n0-10))],type='l',ann=FALSE, 
           ylim=c(lo_Hill,up_Hill))
      title(ylab=expression(hat(lambda)[H](k)), xlab="k",line=2, cex.lab=1.3)
      title(main="Hill plot")
      abline(h=c(.5,.25))
      plot(vTheta[c(10:(n0-10))],vAltHill[c(10:(n0-10))],type='l',ann=FALSE, 
           ylim=c(lo_AltHill,up_AltHill))
      title(ylab=expression(hat(lambda)[H](scriptstyle(group(lceil,n[0]^xi,rceil)))), 
            xlab=expression(xi),line=2.2, cex.lab=1.3)
      title(main="AltHill plot")
      abline(h=c(.5,.25))
    }else{
      plot(vTheta[c(10:(n0-10))],vAltHill[c(10:(n0-10))],type='l',ann=FALSE, 
           ylim=c(lo_AltHill,up_AltHill))
      title(ylab=expression(hat(lambda)[H](scriptstyle(group(lceil,n[0]^xi,rceil)))), 
            xlab=expression(xi),line=2.2, cex.lab=1.3)
      title(main="AltHill plot")
      abline(h=c(.5,.25))
    }
  }else{
    if(hillplot){
      par(mfrow=c(1,2))
      plot(c(10:(n0-10)),vHill[c(10:(n0-10))],type='l',ann=FALSE, 
           ylim=c(lo_Hill,up_Hill))
      title(ylab=expression(hat(lambda)[H](k)), xlab="k",line=2, cex.lab=1.3)
      title(xlab = subtitle[1],line=3.5, cex.lab=1.3)
      abline(h=c(.5,.25))
      plot(vTheta[c(10:(n0-10))],vAltHill[c(10:(n0-10))],type='l',ann=FALSE, 
           ylim=c(lo_AltHill,up_AltHill))
      title(ylab=expression(hat(lambda)[H](scriptstyle(group(lceil,n[0]^xi,rceil)))), 
            xlab=expression(xi),line=2.2, cex.lab=1.3)
      title(xlab = subtitle[2],line=3.5, cex.lab=1.3)
      abline(h=c(.5,.25))
    }else{
      plot(vTheta[c(10:(n0-10))],vAltHill[c(10:(n0-10))],type='l',ann=FALSE, 
           ylim=c(lo_AltHill,up_AltHill))
      title(ylab=expression(hat(lambda)[H](scriptstyle(group(lceil,n[0]^xi,rceil)))), 
            xlab=expression(xi),line=2.2, cex.lab=1.3)
      title(xlab = subtitle[1],line=3.2, cex.lab=1.3)
      abline(h=c(.5,.25))
    }
  }
}

# Function to compute approximate confidence intervals for the wavelet
# variance by simulating from the large sample distribution of its
# estimator. The inputs are:
# x: the data set
# L: length of the wavelet filter used
# wf: wavelet filter used
# mscale: name of the wavelet filter used
# alpha: estimate of the stable index
# NREP: number of iterations used in the simulation
fSimCIWaveVar <-function(x, L, wf, mscale, alpha, NREP=1000)
{
  # length of the data set
  n = length(x)
  # the vector obsxwar will store the observed wavelet variances and the
  # vcotors upciobsx and lociobsx will store, respectivelly, the upper and 
  # lower bounds of the wavelet variance confidence interval
  obsxwvar = upciobsx = lociobsx = rep(0,mscale)
  # Obtaining the MODWT coefficients for obsx
  obsxw = modwt(x, n.levels=mscale, wf=wf)
  
  # scale parameter estimated
  sigma = (gamma(1 - alpha/2)*cos(pi*alpha/4))^(2/alpha)
  # the functions setParam and qEstable are from the package FMStable. The first
  # is used to set the parameters of the stable distribution we want to 
  # analyze, and it returns an object that is used in other functions.
  # qEstable is used to computes quantiles.
  # Here we ser pm=S1 to use the same parametrization of Samorodnitsky and 
  # Taqqu (1994), which is also the same for the characteristic function 
  # presented in Equation 8 of Anderson and Meerschaert (1998).
  stablePar = setParam(alpha=alpha/2,location = 0, logscale = log(sigma), pm = "S1")
  
  for(jscale in 1:mscale){
    # length of the j-th level MODWT wavelet filter
    Lj=(2^jscale-1)*(L-1)+1
    # number of wavelet coefficients used to estimate the wavelet variance
    Mj=n-Lj+1
    # norming constant a_Mj suggested in the paper
    aMj=Mj^(1/alpha)
    # estimating the j-th level wavelet variance
    obsxwvar[jscale] = mean(obsxw[[jscale]][Lj:n]^2)
    
    vS0 = rstable(NREP,alpha=alpha/2,beta=1,gamma = sigma, delta = 0, pm = 1)
    
    vWaveVarSim = ((aMj^2)*vS0/Mj + 1)*obsxwvar[jscale]
    
    # upper bound of the confidence interval
    upciobsx[jscale] = quantile(vWaveVarSim,0.975)
    # lower bound of the confidence interval
    lociobsx[jscale] = max(quantile(vWaveVarSim,0.025),0)
  }
  # returning a matrix with the wavelet coefficients and its respective
  # confidence interval
  return(cbind(obsxwvar, lociobsx, upciobsx))
  
}


