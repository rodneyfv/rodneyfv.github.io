%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Paper: Wavelet variance analysis for heavy-tailed time series
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Authors:
Rodney V. Fonseca
Debashis Mondal
Lingjiao Zhang
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Description of the files in the Rcodes folder.

Last modified by: Rodney Fonseca in 01/28/2019

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


WaveVarFuncs.R
File with some functions used to perform analysis of wavelet  variance and characteristic scales. It can be used by using 
the command <source("WaveVarFuncs.R")>.

salt_river.txt
Data set of the Salt River flow rate from 1913-10-01
until 2018-06-04. The first two columns are codes
of the data, the 3rd column have the days the data 
were collected, the 4th column have the variable of
interest, the flow rate, and the 5th column only have
A's, which mean all data were approved. More details
can be checked on the file 
USGS_09498500_SALT_RIVER_NEAR_ROOSEVELT_AZ.txt
This file is already in a way to be imported in R. 

salmon_river.txt
Data set of the Salmon River flow rate from 1928-10-01
until 2017-04-15. The structure is the same as in the
file salt_river.txt.

apple_river.txt
Data set of the Apple River flow rate from 1934-10-01
until 2017-11-27. The structure is the same as in the
file salt_river.txt.

Code_applications.R
Code to be used as supplement of the paper. Here we make the analyses of the Salt River, Salmon River and Apple river that are presented in the paper. To use this code, we need the data sets salmon_river.txt, salt_river.txt and apple_river.txt, and the functions in the file "WaveVarFuncs.R".

Code_simulation.R
Code to be used as supplement of the paper. In this code we make the simulation study presented in the supplementary material of the paper. For this code, we need the data set salt_river.txt and the functions in the file "WaveVarFuncs.R".


