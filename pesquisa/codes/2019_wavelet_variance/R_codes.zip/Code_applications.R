# Importing packages
library(waveslim)
library(fields)
library(stabledist)
library(FMStable)
# Importing functions presented in the paper
source("WaveVarFuncs.R")

# Wavelet filter used
wf = "la8"
# length of the Daubechies filter used
L = length(wavelet.filter(wf))

############################################################################
############################################################################
##########       SALT RIVER DATA
############################################################################
############################################################################

# daily Salt River time series
salt_data = read.table("salt_river.txt",header = FALSE)
x_salt = salt_data[,4]
# sample size
n_salt = length(x_salt)

# number of time scales used in the wavelet variance
mscale_salt = floor(log2((n_salt - 1)/(L-1) + 1))

# Obtaining the MODWT coefficients for x
y_salt = modwt(x_salt,wf = wf, n.levels = mscale_salt)


## MODWT plot
fWaveCoefTS(y_salt,wf,mscale_salt)
dev.off()


# order statistics of the differenced time series data
x.order_salt = sort(diff(x_salt), decreasing = FALSE)
# getting only positive values
x.order_salt = x.order_salt[which(x.order_salt>0)]
# getting only the peak over threshold
x.order_salt = x.order_salt[which(x.order_salt>=quantile(x.order_salt,.8))]
# length of the data used to estimate the tail index
n0_salt = length(x.order_salt)

# finding the more appropriate value of the tunning parameter xi
xi = fFindTau(x.order_salt,seq(0,1,.1))
# suggested number of upper orders statistics
k1 = round(n0_salt^.999)
# estimate of the second order parameters
rho.hat_salt = fRhoHat(x.order_salt,xi,k1)
beta.hat_salt = fBetaHat(x.order_salt,rho.hat_salt,k1)

# plot of the tail index estimates for different values of k and their
# corresponding confidence intervals. See pg. 47 of Gomes et al (2008).
WLE_salt = fWLE_median_based(x.order_salt,beta.hat_salt,rho.hat_salt,n0_salt,showplot=TRUE)

# Tail index estimate alpha. Notice that we take as tail index the 
# inverse of what is estimated by Gomes et al (2008).
alpha_salt = 1/WLE_salt;round(alpha_salt,4) 
# Using the estimate obtained by Anderson and Meerschaert (1998)
alpha_salt = 3.023

#########################
## tapers used to compute confidence intervals for mean type estimates,
## see paper of Serrouk et al (2000)
# list to store the data tapers of each level
dpss_salt = vector("list", mscale_salt)
# list to store the discrete Fourier transform of each tapers at each level
lamplus_salt = vector("list",mscale_salt)
# This might take a few minutes to run.
for(jscale in 1:mscale_salt){
  # length of the j-th level MODWT wavelet filter
  Lj<-(2^jscale-1)*(L-1)+1
  # number of wavelet coefficients used to estimate the wavelet variance
  Mj<-n_salt-Lj+1
  # Computing orthogonal tapers. Since we are using 5 tapers, a matrix
  # Mj x 5 is returned for level j.
  dpss_salt[[jscale]] = dpss.taper(Mj,5,nw=3.5)
  # computing the sum of the elements of each taper, i.e., the Fourier
  # transform of each taper evaluated at zero
  lamplus_salt[[jscale]] = rep(1,Mj)%*%dpss_salt[[jscale]]
}

# mean type wavelet variance estimates with confidence interval
output1_salt = w.variance.n(x_salt, L, wf, mscale_salt, dpss_salt, lamplus_salt)
# robust type wavelet variance estimates with confidence interval
output2_salt = w.variance.r(x_salt, L, wf, mscale_salt, dpss_salt, lamplus_salt)
# stable type wavelet variance estimates with confidence interval
output3_salt = w.variance.s(x_salt, L, wf, mscale_salt, alpha_salt, .95)

# checking if stable confidence intervals are left or right skewed
cbind(output3_salt[,1]-output3_salt[,2],output3_salt[,3]-output3_salt[,1])

lo = min(output1_salt,output2_salt,output3_salt)
up = max(output1_salt,output2_salt,output3_salt) + 1

# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_salt)-.2, output1_salt[,1], pch=22, ylab="wavelet variance", 
     xlab="j", ylim=c(lo,up), xlim=c(1,mscale_salt) )
for(j in 1:mscale_salt) lines ( c(j-.2,j-.2) , c(output1_salt[j,2], output1_salt[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_salt), output3_salt[,1], pch=19)
for(j in 1:mscale_salt) lines ( c(j,j) , c(output3_salt[j,2], output3_salt[j,3]), lwd=2 )
# median type wavelet variance estimates with confidence interval
points(c(1:mscale_salt) +.2, output2_salt[,1], pch=23)
for(j in 1:mscale_salt) lines ( c(j+.2,j+.2) , c(output2_salt[j,2], output2_salt[j,3]))

# matrix where the first column has the wavelet variance estimates, the
# second column has the  number of wavelet coefficients used to estimate the 
# corresponding wavelet variance, and the third column has the norming constants
# a_nj suggested in the paper
wvar_salt = matrix(0,mscale_salt,3)
for(jscale in 1:mscale_salt){
  # length of the j-th level MODWT wavelet filter
  Lj=(2^jscale-1)*(L-1)+1
  # estimating the j-th level wavelet variance
  wvar_salt[jscale,1] = mean(y_salt[[jscale]][Lj:n_salt]^2)
  # number of wavelet coefficients used to estimate the wavelet variance
  wvar_salt[jscale,2] = n_salt-Lj+1
  # norming constant a_Mj suggested in the paper
  wvar_salt[jscale,3] = (wvar_salt[jscale,2])^(1/alpha_salt)
}
wvar_salt

# Characteristic scales
round(fCharScal(y_salt,wf,mscale_salt,1000,alpha_salt),4)
dev.off()
# For robust estimates we only find a peak at the level 8

# plot of the logarithm of the wavelet variances of first differences
fit_LogWaveVar1Diff_salt = fLogWaveVar1Diff(x_salt,wf,mscale_salt)
round(coef(fit_LogWaveVar1Diff_salt)[2],4)
# Hurst exponent
round((coef(fit_LogWaveVar1Diff_salt)[2]/log(2) + 1)/2 + 1,4)

# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_salt,n0_salt)
dev.off()

# Log-log plot used by Anderson and Meerschaert (1998)
plot(log(x.order_salt[n0_salt:1]),log(c(1:n0_salt)/n0_salt),type='l',ann=FALSE)
title(main="Log-log plot",xlab=" ",
      ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
mWLE_salt = matrix(0,40 - 10 + 1,2)
for(k in 10:40){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_salt[k-10+1,2] = fWLE(x.order_salt,k,beta.hat_salt,rho.hat_salt)
  mWLE_salt[k-10+1,1] = k
}
k = mWLE_salt[min(which(mWLE_salt[,2]>=WLE_salt)),1]
# computing an estimate of the dispersion parameter D using the estimate given
# by Anderson and Meerschaert (1998)
alpha_salt = 1/WLE_salt
C.hat_salt = (k+1)*(x.order_salt[n0_salt-k]^alpha_salt)/n0_salt
# fitting a line with intercept log(D) and slope -alpha
abline(a=log(C.hat_salt),b=-alpha_salt,lty=2)
# Now using the estimate of Anderson and Meerschaert (1998)
alpha_salt = 3.023
k = mWLE_salt[min(which(mWLE_salt[,2]>=(1/alpha_salt))),1]
C.hat_salt = (k+1)*(x.order_salt[n0_salt-k]^alpha_salt)/n0_salt
abline(a=log(C.hat_salt),b=-alpha_salt)
legend(5,-6,c(expression(hat(q) == 3.023),expression(hat(q) == 3.728)),
       lty=c(1,2),bty="n")

############################################################################
############################################################################
##########       SALMON RIVER DATA
############################################################################
############################################################################

# daily Salmon River time series
salmon_data = read.table("salmon_river.txt",header = FALSE)
x_salmon = salmon_data[,4]
# sample size
n_salmon = length(x_salmon)
# number of time scales used in the wavelet variance
mscale_salmon = floor(log2((n_salmon - 1)/(L-1) + 1))

# Obtaining the MODWT coefficients for x
y_salmon = modwt(x_salmon,wf, mscale_salmon)


## MODWT plot
fWaveCoefTS(y_salmon,wf,mscale_salmon)
dev.off()



# order statistics of the differenced time series data
x.order_salmon = sort(diff(x_salmon), decreasing = FALSE)
# getting only positive values
x.order_salmon = x.order_salmon[which(x.order_salmon>0)]
# getting only the peak over threshold
x.order_salmon = x.order_salmon[which(x.order_salmon>=quantile(x.order_salmon,.8))]
# length of the data used to estimate the tail index
n0_salmon = length(x.order_salmon)

# finding the more appropriate value of the tunning parameter xi
xi = fFindTau(x.order_salmon,seq(0,1,.1))
# suggested number of upper orders statistics
k1 = round(n0_salmon^.999)
# estimate of the second order parameters
rho.hat_salmon = fRhoHat(x.order_salmon,xi,k1)
beta.hat_salmon = fBetaHat(x.order_salmon,rho.hat_salmon,k1)

# plot of the tail index estimates for different values of k and their
# corresponding confidence intervals. See pg. 47 of Gomes et al (2008).
WLE_salmon = fWLE_median_based(x.order_salmon,beta.hat_salmon,rho.hat_salmon,n0_salmon,showplot=TRUE)

# tail index estimate alpha. Notice that we take as tail index the 
# inverse of what is estimated by Gomes et al (2008).
alpha_salmon = 1/WLE_salmon;round(alpha_salmon,4)

#########################
## tapers used to compute confidence intervals for mean type estimates
# list to store the data tapers of each level
dpss_salmon = vector("list", mscale_salmon)
# list to store the discrete Fourier transform of each tapers at each level
lamplus_salmon = vector("list",mscale_salmon)
# This might take a few minutes to run.
for(jscale in 1:mscale_salmon){
  # length of the j-th level MODWT wavelet filter
  Lj<-(2^jscale-1)*(L-1)+1
  # number of wavelet coefficients used to estimate the wavelet variance
  Mj<-n_salmon-Lj+1
  # Computing orthogonal tapers. Since we are using 5 tapers, a matrix
  # Mj x 5 is returned for level j.
  dpss_salmon[[jscale]]<-dpss.taper(Mj,5,nw=3.5)
  # computing the sum of the elements of each taper, i.e., the Fourier
  # transform of each taper evaluated at zero
  lamplus_salmon[[jscale]]<-rep(1,Mj)%*%dpss_salmon[[jscale]]
}

# mean type wavelet variance estimates with confidence interval
output1_salmon = w.variance.n(x_salmon, L, wf, mscale_salmon, dpss_salmon, lamplus_salmon)
# robust type wavelet variance estimates with confidence interval
output2_salmon = w.variance.r(x_salmon, L, wf, mscale_salmon, dpss_salmon, lamplus_salmon)
# stable type wavelet variance estimates with confidence interval
output3_salmon = w.variance.s(x_salmon, L, wf, mscale_salmon, alpha_salmon, .95)

lo=min(output1_salmon,output2_salmon,output3_salmon)
up=max(output1_salmon,output2_salmon,output3_salmon)

# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_salmon)-.2, output1_salmon[,1], pch=22, ylab="wavelet variance", 
     xlab="j", ylim=c(lo,up), xlim=c(1,mscale_salmon) )
for(j in 1:mscale_salmon) lines ( c(j-.2,j-.2) , c(output1_salmon[j,2], output1_salmon[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_salmon), output3_salmon[,1], pch=19)
for(j in 1:mscale_salmon) lines ( c(j,j) , c(output3_salmon[j,2], output3_salmon[j,3]), lwd=2 )
# robust type wavelet variance estimates with confidence interval
points(c(1:mscale_salmon) +.2, output2_salmon[,1], pch=23)
for(j in 1:mscale_salmon) lines ( c(j+.2,j+.2) , c(output2_salmon[j,2], output2_salmon[j,3]))

# matrix where the first column has the wavelet variance estimates, the
# second column has the  number of wavelet coefficients used to estimate the 
# corresponding wavelet variance, and the third column has the norming constants
# a_Mj suggested in the paper
wvar_salmon = matrix(0,mscale_salmon,3)
for(jscale in 1:mscale_salmon){
  # length of the j-th level MODWT wavelet filter
  Lj=(2^jscale-1)*(L-1)+1
  # estimating the j-th level wavelet variance
  wvar_salmon[jscale,1] = mean(y_salmon[[jscale]][Lj:n_salmon]^2)
  # number of wavelet coefficients used to estimate the wavelet variance
  wvar_salmon[jscale,2] = n_salmon-Lj+1
  # norming constant a_Mj suggested in the paper
  wvar_salmon[jscale,3] = (wvar_salmon[jscale,2])^(1/alpha_salmon)
}
wvar_salmon

# Characteristic scales
round(fCharScal(y_salmon,wf,mscale_salmon,1000,alpha_salmon),4)
# For robust estimates we only find a peak at the level 8, but there is an
# increase in the last level, 12.

# plot of the logarithm of the wavelet variances of first differences
fit_LogWaveVar1Diff_salmon = fLogWaveVar1Diff(x_salmon,wf,mscale_salmon)
round(coef(fit_LogWaveVar1Diff_salmon)[2],4)
# Hurst exponent
round((coef(fit_LogWaveVar1Diff_salmon)[2]/log(2) + 1)/2 + 1,4)

# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_salmon,n0_salmon)
dev.off()

# Log-log plot used by Anderson and Meerschaert (1998)
plot(log(x.order_salmon[n0_salmon:1]),log(c(1:n0_salmon)/n0_salmon),type='l',ann=FALSE)
title(main="Log-log plot",xlab=" ",
      ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
mWLE_salmon = matrix(0,80 - 10 + 1,2)
for(k in 10:80){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_salmon[k-10+1,2] = fWLE(x.order_salmon,k,beta.hat_salmon,rho.hat_salmon)
  mWLE_salmon[k-10+1,1] = k
}
k = mWLE_salmon[min(which(mWLE_salmon[,2]>=WLE_salmon)),1]
# computing an estimate of the dispersion parameter D using the estimate given
# by Anderson and Meerschaert (1998)
C.hat_salmon = (k+1)*(x.order_salmon[n0_salmon-k]^alpha_salmon)/n0_salmon
# fitting a line with intercept log(D) and slope -alpha
abline(a=log(C.hat_salmon),b=-alpha_salmon)


############################################################################
############################################################################
##########       APPLE RIVER DATA
############################################################################
############################################################################

# daily Apple River time series
apple_data = read.table("apple_river.txt",header = FALSE)
x_apple = apple_data[,4]
# sample size
n_apple = length(x_apple)

# number of time scales used in the wavelet variance
mscale_apple = floor(log2((n_apple - 1)/(L-1) + 1))

# Obtaining the MODWT coefficients for x
y_apple = modwt(x_apple,wf, mscale_apple)


## MODWT plot
fWaveCoefTS(y_apple,wf,mscale_apple)
dev.off()


# order statistics of the differenced time series data
x.order_apple = sort(diff(x_apple), decreasing = FALSE)
# getting only positive values
x.order_apple = x.order_apple[which(x.order_apple>0)]
# getting only the peak over threshold
x.order_apple = x.order_apple[which(x.order_apple>=quantile(x.order_apple,.8))]
# length of the data used to estimate the tail index
n0_apple = length(x.order_apple)

# finding the more appropriate value of the tunning parameter tau
fFindTau(x.order_apple,seq(0,1,.1))
# suggested number of upper orders statistics
k1 = round(n0_apple^.999)
# estimate of the second order parameters
rho.hat_apple = fRhoHat(x.order_apple,0,k1)
beta.hat_apple = fBetaHat(x.order_apple,rho.hat_apple,k1)

# plot of the tail index estimates for different values of k and their
# corresponding confidence intervals. See pg. 47 of Gomes et al (2008).
WLE_apple = fWLE_median_based(x.order_apple,beta.hat_apple,rho.hat_apple,n0_apple,showplot=TRUE)

# tail index estimate alpha. Notice that we take as tail index the 
# inverse of what is estimated by Gomes et al (2008).
alpha_apple = 1/WLE_apple;round(alpha_apple,4)


#########################
## tapers used to compute confidence intervals for mean type estimates
# list to store the data tapers of each level
dpss_apple = vector("list", mscale_apple)
# list to store the discrete Fourier transform of each tapers at each level
lamplus_apple = vector("list",mscale_apple)
# This might take a few minutes to run.
for(jscale in 1:mscale_apple){
  # length of the j-th level MODWT wavelet filter
  Lj<-(2^jscale-1)*(L-1)+1
  # number of wavelet coefficients used to estimate the wavelet variance
  Mj<-n_apple-Lj+1
  # Computing orthogonal tapers. Since we are using 5 tapers, a matrix
  # Mj x 5 is returned for level j.
  dpss_apple[[jscale]]<-dpss.taper(Mj,5,nw=3.5)
  # computing the sum of the elements of each taper, i.e., the Fourier
  # transform of each taper evaluated at zero
  lamplus_apple[[jscale]]<-rep(1,Mj)%*%dpss_apple[[jscale]]
}

# mean type wavelet variance estimates with confidence interval
output1_apple = w.variance.n(x_apple, L, wf, mscale_apple, dpss_apple, lamplus_apple)
# robust type wavelet variance estimates with confidence interval
output2_apple = w.variance.r(x_apple, L, wf, mscale_apple, dpss_apple, lamplus_apple)
# stable type wavelet variance estimates with confidence interval
output3_apple = w.variance.s(x_apple, L, wf, mscale_apple, alpha_apple, .95)

lo=min(output1_apple,output2_apple,output3_apple)
up=max(output1_apple,output2_apple,output3_apple)

# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_apple)-.2, output1_apple[,1], pch=22, ylab="wavelet variance", 
     xlab="j", ylim=c(lo,up), xlim=c(1,mscale_apple) )
for(j in 1:mscale_apple) lines ( c(j-.2,j-.2) , c(output1_apple[j,2], output1_apple[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_apple), output3_apple[,1], pch=19)
for(j in 1:mscale_apple) lines ( c(j,j) , c(output3_apple[j,2], output3_apple[j,3]), lwd=2 )
# robust type wavelet variance estimates with confidence interval
points(c(1:mscale_apple) +.2, output2_apple[,1], pch=23)
for(j in 1:mscale_apple) lines ( c(j+.2,j+.2) , c(output2_apple[j,2], output2_apple[j,3]))

# matrix where the first column has the wavelet variance estimates, the
# second column has the  number of wavelet coefficients used to estimate the 
# corresponding wavelet variance, and the third column has the norming constants
# a_nj suggested in the paper
wvar_apple = matrix(0,mscale_apple,3)
for(jscale in 1:mscale_apple){
  # length of the j-th level MODWT wavelet filter
  Lj=(2^jscale-1)*(L-1)+1
  # estimating the j-th level wavelet variance
  wvar_apple[jscale,1] = mean(y_apple[[jscale]][Lj:n_apple]^2)
  # number of wavelet coefficients used to estimate the wavelet variance
  wvar_apple[jscale,2] = n_apple-Lj+1
  # norming constant a_nj suggested in the paper
  wvar_apple[jscale,3] = (wvar_apple[jscale,2])^(1/alpha_apple)
}
wvar_apple

# Characteristic scales
round(fCharScal(y_apple,wf,mscale_apple,1000,alpha_apple),4)
# For robust estimates we find peaks at levels 8 and 11

# plot of the logarithm of the wavelet variances of first differences
fit_LogWaveVar1Diff_apple = fLogWaveVar1Diff(x_apple,wf,mscale_apple)
round(coef(fit_LogWaveVar1Diff_apple)[2], 4)
# Hurst exponent
round((coef(fit_LogWaveVar1Diff_apple)[2]/log(2) + 1)/2 + 1, 4)

# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_apple,n0_apple)
dev.off()

# Log-log plot used by Anderson and Meerschaert (1998)
plot(log(x.order_apple[n0_apple:1]),log(c(1:n0_apple)/n0_apple),type='l',ann=FALSE)
title(main="Log-log plot",xlab=" ",
      ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
mWLE_apple = matrix(0,50 - 10 + 1,2)
for(k in 10:50){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_apple[k-10+1,2] = fWLE(x.order_apple,k,beta.hat_apple,rho.hat_apple)
  mWLE_apple[k-10+1,1] = k
}
k = mWLE_apple[min(which(mWLE_apple[,2]>=WLE_apple)),1]
# computing an estimate of the dispersion parameter D using the estimate given
# by Anderson and Meerschaert (1998)
C.hat_apple = (k+1)*(x.order_apple[n0_apple-k]^alpha_apple)/n0_apple
# fitting a line with intercept log(D) and slope -alpha
abline(a=log(C.hat_apple),b=-alpha_apple)

############################################################################
############################################################################


############################################################################
############################################################################
##########       FIGURES FOR THE PAPER
############################################################################
############################################################################


## MODWT plot of the Salt River data
pdf("/home/rodney/Downloads/watermodwt.pdf", width=8, height=10)

wcoef_salt = matrix(NA,n_salt, mscale_salt)
for(jscale in 1:mscale_salt){
  Lj=(2^jscale-1)*(L-1)+1
  wcoef_salt[(Lj/2):(n_salt-Lj/2), jscale]  = y_salt[[jscale]][Lj:n_salt]
}

names.w <- c(expression(W[1]), expression(W[2]), expression(W[3]), expression(W[4]), expression(W[5]),expression(W[6]), expression(W[7]), expression(W[8]), expression(W[9]), expression(W[10]), expression(W[11]), expression(W[12]), expression(W[13]), expression(W[14]), expression(W[15]) )
par(mfcol=c(mscale_salt+1,1), pty="m", mar=c(0,4,0,0), cex=1.25)
for(i in 1:mscale_salt)
  plot.ts(wcoef_salt[,i], axes=FALSE, ylab=names.w[i])
plot.ts(rep(0,length(x_salt)), axes=F , ylab=" ", ylim=c(-1,0))
text(c(800,  6372, 12744, 19116, 25488, 31860, 37532), rep(-.25,7), labels=c("1915","1931","1948", "1966", "1983", "2000", "2016"))
text(17500,-.75, "years")

dev.off()
###########################

## plot of log density and smooth periodogram for the Salt River data
pdf("/home/rodney/Downloads/waterdensity.pdf", width=8, height=4)

par(mfrow=c(1,2), mar=c(4,4,0,0)+.25)
plot(density(log(x_salt)),ann="FALSE", main=" ")
title(ylab="density",line=2, cex.lab=1.3)
title(xlab="log of daily flow",line=2, cex.lab=1.3)
title(xlab = "(a)",line=3, cex.lab=1.3)
spec.pgram(x_salt,ann="FALSE", main=" ", sub=" ", col=1)
title(ylab="spectrum",line=2, cex.lab=1.3)
title(xlab="frequency",line=1.8, cex.lab=1.3)
title(xlab = "(b)",line=2.8, cex.lab=1.3)

dev.off()
###########################


# Plot of the three river time series togheter
pdf("/home/rodney/Downloads/riverstimeseries.pdf", width=7.5, height=6)

par(mfrow=c(3,1), mai=c(.5,.5,.3,.3))

par(mai=c(.7,.3,.1,.3),mar=c(4,3.5,1,1))
plot(x_salt,ann="FALSE", type="l", xaxt='n')
axis(side=1,at=c(1,  6372, 12744, 19116, 25488, 31860, 38232), labels=c("1913","1931","1948", "1966", "1983", "2000", "2018"))
title(ylab="river flow in cfs",line=2, cex.lab=1.3)
title(xlab = "(a)",line=2.5, cex.lab=1.3)

par(mai=c(.7,.3,.1,.3),mar=c(5,3.5,1,1))
plot(x_salmon, ann="FALSE", type="l", xaxt='n')
axis(side=1,at=c(1, 5389, 10778, 16167, 21556, 26945, 32339), labels=c("1928","1943","1958", "1973", "1987", "2002", "2017"))
title(xlab = "(b)",line=2.5, cex.lab=1.3)

par(mai=c(.7,.3,.1,.3),mar=c(6,3.5,0,1))
plot(x_apple, ann="FALSE", type="l", xaxt='n')
axis(side=1,at=c(0, 5062, 10124, 15186, 20248, 25310, 30372), labels=c("1934","1948","1962", "1976", "1990", "2004", "2017"))
title(xlab = "years",line=2, cex.lab=1.3)
title(xlab = "(c)",line=3.5, cex.lab=1.3)

dev.off()
###########################


# Plot of the wavelet variance for the Salt River data in the original 
# scale and in a log scale with a characteristic scale estimate
pdf("/home/rodney/Downloads/saltwavevar.pdf", width=8, height=4)

par(mfrow=c(1,2), mar=c(5,4,1,0)+.25)

lo = min(output1_salt,output2_salt,output3_salt)
up = max(output1_salt,output2_salt,output3_salt)
# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_salt)-.2, output1_salt[,1], pch=22, ann="FALSE", 
     ylim=c(lo,up), xlim=c(1,mscale_salt) )
title(ylab=expression(nu[j]^2), xlab="j",line=2.5, cex.lab=1)
title(xlab = "(a)",line=3.5, cex.lab=1.3)
for(j in 1:mscale_salt) lines ( c(j-.2,j-.2) , c(output1_salt[j,2], output1_salt[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_salt), output3_salt[,1], pch=19)
for(j in 1:mscale_salt) lines ( c(j,j) , c(output3_salt[j,2], output3_salt[j,3]), lwd=2 )
# robust type wavelet variance estimates with confidence interval
points(c(1:mscale_salt) +.2, output2_salt[,1], pch=23)
for(j in 1:mscale_salt) lines ( c(j+.2,j+.2) , c(output2_salt[j,2], output2_salt[j,3]))

fCharScal(y_salt,wf,mscale_salt,1000,alpha_salt,subtitle="(b)")
dev.off()
###########################


# Figure with Hill plot, AltHill plot, log-log plot (of order statistics) and
# WLE plot with confidence intervals
pdf("/home/rodney/Downloads/HillPlotsSalt.pdf", width=8, height=3)

par(mfrow=c(1,3))

# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_salt,n0_salt,subtitle=c("(a)"),hillplot=FALSE)
# Log-log plot used by Anderson and Meerschaert
plot(log(x.order_salt[n0_salt:1]),log(c(1:n0_salt)/n0_salt),type='l',ann=FALSE)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.2)
title(ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab="(b)",line=3.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
mWLE_salt = matrix(0,40 - 10 + 1,2)
for(k in 10:40){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_salt[k-10+1,2] = fWLE(x.order_salt,k,beta.hat_salt,rho.hat_salt)
  mWLE_salt[k-10+1,1] = k
}
k = mWLE_salt[min(which(mWLE_salt[,2]>=WLE_salt)),1]
alpha_salt = 1/WLE_salt
C.hat_salt = (k+1)*(x.order_salt[n0_salt-k]^alpha_salt)/n0_salt
abline(a=log(C.hat_salt),b=-alpha_salt,lty=2)
alpha_salt = 3.023
k = mWLE_salt[min(which(mWLE_salt[,2]>=(1/alpha_salt))),1]
C.hat_salt = (k+1)*(x.order_salt[n0_salt-k]^alpha_salt)/n0_salt
abline(a=log(C.hat_salt),b=-alpha_salt)
legend(5,-5,c(expression(hat(q) == 3.023),expression(hat(q) == 3.728)),
       lty=c(1,2),bty="n")
# plot of WLE estimates with confidence intervals
WLE_salt = fWLE_median_based(x.order_salt,beta.hat_salt,rho.hat_salt,n0_salt,
                             showplot=1,"(c)")

dev.off()
###########################


# Plot of the wavelet variance for the Salmon River data in the original 
# scale and in a log scale with a characteristic scale estimate
pdf("/home/rodney/Downloads/salmonwavevar.pdf", width=8, height=4)

par(mfrow=c(1,2), mar=c(5,4,1,0)+.25)

lo = min(output1_salmon,output2_salmon,output3_salmon)
up = max(output1_salmon,output2_salmon,output3_salmon)
# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_salmon)-.2, output1_salmon[,1], pch=22, ann="FALSE", 
     ylim=c(lo,up), xlim=c(1,mscale_salmon) )
title(ylab=expression(nu[j]^2), xlab="j",line=2.5, cex.lab=1)
title(xlab = "(a)",line=3.5, cex.lab=1.3)
for(j in 1:mscale_salmon) lines ( c(j-.2,j-.2) , c(output1_salmon[j,2], output1_salmon[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_salmon), output3_salmon[,1], pch=19)
for(j in 1:mscale_salmon) lines ( c(j,j) , c(output3_salmon[j,2], output3_salmon[j,3]), lwd=2 )
# median type wavelet variance estimates with confidence interval
points(c(1:mscale_salmon) +.2, output2_salmon[,1], pch=23)
for(j in 1:mscale_salmon) lines ( c(j+.2,j+.2) , c(output2_salmon[j,2], output2_salmon[j,3]))

fCharScal(y_salmon,wf,mscale_salmon,1000,alpha_salmon,subtitle="(b)")
dev.off()
###########################


# Figure with Hill plot, AltHill plot, log-log plot (of order statistics) and
# WLE plot with confidence intervals
pdf("/home/rodney/Downloads/HillPlotsSalmon.pdf", width=8, height=3)

par(mfrow=c(1,3))

# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_salmon,n0_salmon,subtitle=c("(a)"),hillplot=FALSE)
# Log-log plot used by Anderson and Meerschaert
plot(log(x.order_salmon[n0_salmon:1]),log(c(1:n0_salmon)/n0_salmon),type='l',ann=FALSE)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.2)
title(ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab="(b)",line=3.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
mWLE_salmon = matrix(0,80 - 10 + 1,2)
for(k in 10:80){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_salmon[k-10+1,2] = fWLE(x.order_salmon,k,beta.hat_salmon,rho.hat_salmon)
  mWLE_salmon[k-10+1,1] = k
}
k = mWLE_salmon[min(which(mWLE_salmon[,2]>=WLE_salmon)),1]
C.hat_salmon = (k+1)*(x.order_salmon[n0_salmon-k]^alpha_salmon)/n0_salmon
abline(a=log(C.hat_salmon),b=-alpha_salmon)
# plot of WLE estimates with confidence intervals
WLE_salmon = fWLE_median_based(x.order_salmon,beta.hat_salmon,rho.hat_salmon,n0_salmon,
                               showplot=1,"(c)")

dev.off()
###########################


# Plot of the wavelet variance for the Apple River data in the original 
# scale and in a log scale with a characteristic scale estimate
pdf("/home/rodney/Downloads/applewavevar.pdf", width=8, height=4)

par(mfrow=c(1,2), mar=c(5,4,1,0)+.25)

lo=min(output1_apple,output2_apple,output3_apple)
up=max(output1_apple,output2_apple,output3_apple)
# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_apple)-.2, output1_apple[,1], pch=22, ann="FALSE", 
     ylim=c(lo,up), xlim=c(1,mscale_apple) )
title(ylab=expression(nu[j]^2), xlab="j",line=2.5, cex.lab=1)
title(xlab = "(a)",line=3.5, cex.lab=1.3)
for(j in 1:mscale_apple) lines ( c(j-.2,j-.2) , c(output1_apple[j,2], output1_apple[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_apple), output3_apple[,1], pch=19)
for(j in 1:mscale_apple) lines ( c(j,j) , c(output3_apple[j,2], output3_apple[j,3]), lwd=2 )
# median type wavelet variance estimates with confidence interval
points(c(1:mscale_apple) +.2, output2_apple[,1], pch=23)
for(j in 1:mscale_apple) lines ( c(j+.2,j+.2) , c(output2_apple[j,2], output2_apple[j,3]))

fCharScal(y_apple,wf,mscale_apple,1000,alpha_apple,subtitle="(b)")
dev.off()
###########################


# Figure with Hill plot, AltHill plot, log-log plot (of order statistics) and
# WLE plot with confidence intervals
pdf("/home/rodney/Downloads/HillPlotsApple.pdf", width=8, height=3)

par(mfrow=c(1,3))

# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_apple,n0_apple,subtitle=c("(a)"),hillplot=FALSE)
# Log-log plot used by Anderson and Meerschaert
plot(log(x.order_apple[n0_apple:1]),log(c(1:n0_apple)/n0_apple),type='l',ann=FALSE)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.2)
title(ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab="(b)",line=3.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
mWLE_apple = matrix(0,80 - 10 + 1,2)
for(k in 10:80){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_apple[k-10+1,2] = fWLE(x.order_apple,k,beta.hat_apple,rho.hat_apple)
  mWLE_apple[k-10+1,1] = k
}
# identifying which k approximately would give the estimate WLE obtained
mWLE_apple = matrix(0,50 - 10 + 1,2)
for(k in 10:50){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_apple[k-10+1,2] = fWLE(x.order_apple,k,beta.hat_apple,rho.hat_apple)
  mWLE_apple[k-10+1,1] = k
}
k = mWLE_apple[min(which(mWLE_apple[,2]>=WLE_apple)),1]
C.hat_apple = (k+1)*(x.order_apple[n0_apple-k]^alpha_apple)/n0_apple
abline(a=log(C.hat_apple),b=-alpha_apple)
# plot of WLE estimates with confidence intervals
WLE_apple = fWLE_median_based(x.order_apple,beta.hat_apple,rho.hat_apple,n0_apple,
                              showplot=1,"(c)")

dev.off()
###########################


# Plot of the log of the wavelet variance for the first differences of the
# three rivers' flow data
pdf("/home/rodney/Downloads/logdiffwavevar.pdf", width=8, height=3)

par(mfrow=c(1,3), mar=c(5,4,1,0)+.25)

fLogWaveVar1Diff(x_salt,wf,mscale_salt,subtitle = "(a)")
text(5,-3,"slope -1.6131",cex=1.5)

fLogWaveVar1Diff(x_salmon,wf,mscale_salmon,subtitle = "(b)")
text(5,-6,"slope -1.5907",cex=1.5)

fLogWaveVar1Diff(x_apple,wf,mscale_apple,subtitle = "(c)")
text(5,-5,"slope -1.6154",cex=1.5)

dev.off()

