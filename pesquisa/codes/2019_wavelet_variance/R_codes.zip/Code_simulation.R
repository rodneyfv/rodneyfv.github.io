# Code to simulate the AR model based on Anderson and Meerschaert (1998) application.
# We simulate from a AR(1) model with standardized Pareto innovations,
# and use the estimates they found for the periodic parameters. Then the
# wavelet variances of the simulated model are analyzed, as well as the bias
# corrected Hill estimator

# Importing packages
library(waveslim)
library(fields)
library(stabledist)
library(FMStable)
# Importing functions presented in the paper
source("WaveVarFuncs.R")


# Function to generate n iid values of a Pareto distribution with
# lower bound (scale) xm and shape parameter alpha
rPareto = function(n, xm, alpha){
  vu = runif(n)
  vPa = xm/(vu^(1/alpha))
  return(vPa)
}

# daily Salt River time series
salt_data = read.table("salt_river.txt",header = FALSE)
x_salt = salt_data[,4]
# sample size
n_salt = length(x_salt)
# separating the years, months and days in different vectors
vyears_salt = as.numeric(substr(as.character(salt_data[,3]),1,4))
vmonths_salt = as.numeric(substr(as.character(salt_data[,3]),6,7))

# Matrix where the first column is the average of each month for each year
# in the Salt River data. The second and third columns are the year and 
# month, respectivelly, corresponding to the average
k = 1
mAveSalt = matrix(0,n_salt,3)
for(i in 1913:2018){
  for(j in 1:12){
    vindex = intersect(which(vyears_salt==i),which(vmonths_salt==j))
    if(length(vindex)>0){
      mAveSalt[k,1] = mean(x_salt[vindex])
      mAveSalt[k,2] = i
      mAveSalt[k,3] = j
      k = k + 1
    }
  }
}
mAveSalt = mAveSalt[1:(k-1),]
head(mAveSalt,12)
tail(mAveSalt,12)

# mean of each month for the Salt River time series
vMu0 = rep(0,12)
for(i in 1:12) vMu0[i] = mean(mAveSalt[which(mAveSalt[,3]==i),1])
# estimates provided in the paper of Anderson and Meerschaert (1998)
# PARMA coefficients
vPhi0 = c(0.33978, 0.14341,2.75546,  0.43595,0.30891, 0.52567,0.54035, 
          0.58017,0.26821,0.38585,0.42231,0.29001)
# scales
vSig0 = c(788.82, 342.88, 862.43, 1977.22, 1676.53, 1707.71, 1158.67, 
          547.00, 104.82, 379.72, 453.80, 302.79)
# tail index
alpha0 = 3.023
# lower bound for the Pareto distribution (related to dispersion parameter)
xm0 = floor(min(mAveSalt[,1]))

# setting seed
set.seed(112018)
# using a sample size close to the length of the Salt River data
N = length(x_salt)
# standardized innovations (mean zero and variance 1) with Pareto distribution
vEps = rPareto(N+1000,xm0,alpha0)
vEps = (vEps - alpha0*xm0/(alpha0 - 1))/( xm0*sqrt(alpha0)/((alpha0 - 1)*sqrt(alpha0 - 2)))
# vector to store the simulated time series
vXsim = rep(0,N+1000)
# simulating the AR(1) model using the parameters for the month 12
vXsim[1] = mAveSalt[5,1]
for(i in 2:(N+1000)){
  vXsim[i] = vMu0[12] + (vXsim[i-1] - vMu0[12])*vPhi0[12] + 
    vSig0[12]*vEps[i]
}
vXsim = vXsim[(1+1000):(N+1000)]

# simulated data
plot(vXsim,type = 'l')

###############################################################
###############################################################
# Analysis of wavelet variances  of the simulated time series

# Wavelet filter used
wf = "la8"
# length of the Daubechies filter used
L = length(wavelet.filter(wf))
# sample size
n_sim = length(vXsim)
# number of time scales used in the wavelet variance
mscale_sim = floor(log2((n_sim - 1)/(L-1) + 1))

# Obtaining the MODWT coefficients for x
y_sim = modwt(vXsim,wf = wf, n.levels = mscale_sim)

## MODWT plot
fWaveCoefTS(y_sim,wf,mscale_sim)
dev.off()


# order statistics of the time series data
x.order_sim = sort(vXsim, decreasing = FALSE)

# tail index estimated with Hill estimator as done in 
# Anderson and Meerschaert (2018)
1/fHill(x.order_sim, 30)

acf(vXsim)
# order statistics of the differenced time series data
x.order_sim = sort(vXsim, decreasing = FALSE)
# getting only positive values
x.order_sim = x.order_sim[which(x.order_sim>0)]
# getting only the peak over threshold
x.order_sim = x.order_sim[which(x.order_sim>=quantile(x.order_sim,.8))]
# length of the data used to estimate the tail index
n0_sim = length(x.order_sim)

# finding the more appropriate value of the tunning parameter tau
xi = fFindTau(x.order_sim,seq(0,1,.1)); xi
# suggested number of upper orders statistics
k1 = round(n0_sim^.999)
# estimate of the second order parameters
rho.hat_sim = fRhoHat(x.order_sim,xi,k1)
beta.hat_sim = fBetaHat(x.order_sim,rho.hat_sim,k1)

# plot of the tail index estimates for different values of k and their
# corresponding confidence intervals. See pg. 47 of Gomes et al (2008).
WLE_sim = fWLE_median_based(x.order_sim,beta.hat_sim,rho.hat_sim,n0_sim,showplot=TRUE)

# tail index estimate alpha. Notice that we take as tail index the 
# inverse of what is estimated by Gomes et al (2008).
alpha_sim = 1/WLE_sim;round(alpha_sim,4)


# AltHill plot of Drees et al (2000)
fAltHillplot(x.order_sim,n0_sim)

# Log-log plot used by Anderson and Meerschaert (1998)
plot(log(x.order_sim[n0_sim:1]),log(c(1:n0_sim)/n0_sim),type='l',ann=FALSE)
title(main="Log-log plot",xlab=" ",
      ylab=expression(log(k/n)),line=1.8, cex.lab=1.3)
title(xlab=expression(log(Y[n-k+1:n])),line=2.2, cex.lab=1.3)
# identifying which k approximately would give the estimate WLE obtained
#round((n0_sim^(-2*rho.hat_sim/(1-2*rho.hat_sim)))/4)
#round((n0_sim^(-2*rho.hat_sim/(1-2*rho.hat_sim)))*4)
mWLE_sim = matrix(0,2600 - 170 + 1,2)
for(k in 170:2600){
  # Bias corrected Hill estimate and its corresponding confidence intervals
  mWLE_sim[k-170+1,2] = fWLE(x.order_sim,k,beta.hat_sim,rho.hat_sim)
  mWLE_sim[k-170+1,1] = k
}
k = mWLE_sim[min(which(abs(mWLE_sim[,2] -WLE_sim)<0.0001)),1]
# computing an estimate of the dispersion parameter D using the estimate given
# by Anderson and Meerschaert (1998)
C.hat_sim = (k+1)*(x.order_sim[n0_sim-k]^alpha_sim)/n0_sim
# fitting a line with intercept log(D) and slope -alpha
abline(a=log(C.hat_sim),b=-alpha_sim,lwd=2,lty=2)


# We need the variables dpss_salt and lamplus_salt
# list to store the data tapers of each level
dpss_salt = vector("list", mscale_salt)
# list to store the discrete Fourier transform of each tapers at each level
lamplus_salt = vector("list",mscale_salt)
for(jscale in 1:mscale_salt){
  # length of the j-th level MODWT wavelet filter
  Lj<-(2^jscale-1)*(L-1)+1
  # number of wavelet coefficients used to estimate the wavelet variance
  Mj<-n_salt-Lj+1
  # Computing orthogonal tapers. Since we are using 5 tapers, a matrix
  # Mj x 5 is returned for level j.
  dpss_salt[[jscale]] = dpss.taper(Mj,5,nw=3.5)
  # computing the sum of the elements of each taper, i.e., the Fourier
  # transform of each taper evaluated at zero
  lamplus_salt[[jscale]] = rep(1,Mj)%*%dpss_salt[[jscale]]
}


output1_sim = w.variance.n(vXsim, L, wf, mscale_sim, dpss_salt, lamplus_salt)
output2_sim = w.variance.r(vXsim, L, wf, mscale_sim, dpss_salt, lamplus_salt)
output3_sim = w.variance.s(vXsim, L, wf, mscale_sim, alpha_sim, .95)

lo = min(output1_sim,output2_sim,output3_sim)
up = max(output1_sim,output2_sim,output3_sim)
# mean type wavelet variance estimates with confidence interval
plot(c(1:mscale_sim)-.2, output1_sim[,1], pch=22, ann="FALSE", 
     ylim=c(lo,up),xlim=c(1,mscale_sim) )
title(ylab=expression(nu[j]^2), xlab="j",line=2.5, cex.lab=1)
title(xlab = "(d)",line=3.5, cex.lab=1.3)
for(j in 1:mscale_sim) lines ( c(j-.2,j-.2) , c(output1_sim[j,2], output1_sim[j,3]) )
# stable type wavelet variance estimates with confidence interval
points(c(1:mscale_sim), output3_sim[,1], pch=19)
for(j in 1:mscale_sim) lines ( c(j,j) , c(output3_sim[j,2], output3_sim[j,3]), lwd=2 )
# robust type wavelet variance estimates with confidence interval
points(c(1:mscale_sim) +.2, output2_sim[,1], pch=23)
for(j in 1:mscale_sim) lines ( c(j+.2,j+.2) , c(output2_sim[j,2], output2_sim[j,3]))
dev.off()

# Characteristic scales
fCharScal(y_sim,wf,mscale_sim,1000,alpha_sim)

# matrix where the first column has the wavelet variance estimates, the
# second column has the  number of wavelet coefficients used to estimate the 
# corresponding wavelet variance, and the third column has the norming constants
# a_Mj suggested in the paper
wvar_sim = matrix(0,mscale_sim,3)
for(jscale in 1:mscale_sim){
  # length of the j-th level MODWT wavelet filter
  Lj=(2^jscale-1)*(L-1)+1
  # estimating the j-th level wavelet variance
  wvar_sim[jscale,1] = mean(y_sim[[jscale]][Lj:n_sim]^2)
  # number of wavelet coefficients used to estimate the wavelet variance
  wvar_sim[jscale,2] = n_sim-Lj+1
  # norming constant a_Mj suggested in the paper
  wvar_sim[jscale,3] = (wvar_sim[jscale,2])^(1/alpha_sim)
}
wvar_sim

# plot of the logarithm of the wavelet variances of first differences
fit_LogWaveVar1Diff_sim = fLogWaveVar1Diff(vXsim,wf,mscale_sim)
round(coef(fit_LogWaveVar1Diff_sim)[2], 4)
# Hurst exponent
round((coef(fit_LogWaveVar1Diff_sim)[2]/log(2) + 1)/2 + 1, 4)


