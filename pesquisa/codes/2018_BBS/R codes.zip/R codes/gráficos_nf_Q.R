# Gráfico que mostra a proporção de vezes que a maximização não convergiu
# no MaxBFGS para os diferentes EMV's considerados, tomando valores diferentes
# de gama. Foram fixados alfa=.5, beta=1 e n=50.

mNF = read.table("EMVs_nf2.dat",header = FALSE)
postscript(file="EMVs_nfs.eps",horizontal = FALSE, width = 8.0, height = 6.0,
           paper="special")
matplot(mNF[,1],mNF[,-1],type="l",lty=c(1:4),xlab=expression(gamma),
        ylab = "pnf",lwd=1.3,col=1,ylim=c(0,1))
legend(-2,.9,c("EMV",expression(EMV[Bboot]),expression(EMV[pj]),
               expression(EMV[p])),lty=c(1:4),bty="n")
dev.off()

# Gráfico que mostra a proporção de vezes que a maximização não convergiu
# no MaxBFGS para os diferentes EMV's considerados, tomando diferentes
# tamanhos amostrais. Foram fixados alfa=.5, beta=1 e gama=1.

mNFn = read.table("EMVs_nf_variando_n2.dat",header = FALSE)
postscript(file="EMVs_nfs_variando_n.eps",horizontal = FALSE, width = 8.0, height = 6.0,
           paper="special")
matplot(mNFn[,1],mNFn[,-1],type="l",lty=c(1:4),xlab=expression(n),
        ylab = "pnf",lwd=1.3,col=1,ylim=c(0,1))
legend(30,1,c("EMV",expression(EMV[Bboot]),expression(EMV[pj]),
               expression(EMV[p])),lty=c(1:4),bty="n")
#legend(30,1,c("EMV",expression(EMV[Bboot])),
#       lty=c(1:2),bty="n")
#legend(100,1,c(expression(EMV[pj]), expression(EMV[p])),
#       lty=c(3:4),bty="n")
dev.off()


# Gráfico que mostra as penalizações Qa e Qg, obtidas modificando alguns termos
# da penalização pela priori de Jeffreys

# Penalização referente a gama
Qg = function(g){
  w = dnorm(g)/pnorm(-g)
  -.5*log((g-w)*w*(3+g*(g-w))/2 + 1)
}

# Penalização referente a alfa
Qa = function(a){
  log(1+a^2)
}

postscript(file="PenalQaQg.eps",horizontal = FALSE, width = 6.0, height = 4.0,
           paper="special")
par(mfrow=c(c(1,2)))
curve(Qg,xlim=c(-4,4),xlab=expression(gamma),ylab=expression(Q[gamma]))
curve(Qa,xlim=c(.01,4),xlab=expression(alpha),ylab=expression(Q[alpha]))
dev.off()

