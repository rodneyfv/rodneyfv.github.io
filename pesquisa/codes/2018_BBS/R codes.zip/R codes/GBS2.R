rgbs2 = function(n,a=1,b=1,nu=1){
  z = rnorm(n)
  t = b*((.5*a*z) + sqrt((.5*a*z)^2 + 1))^(1/nu)
  return(t)
}

dgbs2 = function(t,a=1,b=1,nu=1){
  nu*((t/b)^nu + (b/t)^nu)*exp(-.5*((t/b)^(2*nu) + (b/t)^(2*nu) - 2)/(a^2))/
    (t*a*sqrt(2*pi))
}

pgbs2 = function(t,a=1,b=1,nu=1){
  pnorm(((t/b)^nu - (b/t)^nu)/a)
}

a=4; b=1; nu=4

x = rgbs2(10000,a,b,nu)
hist(x,prob=TRUE)
curve(dgbs2(x,a,b,nu),add=TRUE)
m1 = mean(x)
m2 = var(x)
m3 = mean((x-m1)^3)
m4 = mean((x-m1)^4)
m1; sqrt(m2); m3/(m2^1.5); m4/(m2^2)

curve(dgbs2(x,5,1,5),xlim=c(0.01,2))
curve(dbbs(x,.2,1,-1),xlim=c(0.01,2),add=T)

postscript(file="pdf_bbs_gbs2.eps",horizontal = FALSE, width = 10.0, height = 8.0,
           paper="special")
curve(dbbs(x,.2,1,-1),xlim=c(0.01,2),ylim=c(0,2),lwd=1.5,lty=1,ylab="Densidade")
curve(dgbs2(x,5,1,5),xlim=c(0.01,2),add=T,ylim=c(0,2),lwd=1.5,lty=2)
dev.off()


