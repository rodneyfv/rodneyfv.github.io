require(gbs)
require(MASS)
require(gamlss.data)
source("BBS-functions.R")

########################

data(runoff)
mlebs(runoff)
MMEbbs(runoff)

hist(runoff,prob=TRUE,ylim = c(0,1.5))
curve(dgbs(x,.662,.691),xlim=c(0.01,5),add=TRUE,col=1,ylab="f(x)",ylim=c(0,3))
curve(dbbs(x,.626,.689,-.131),xlim=c(0.01,5),add=TRUE,col=2,ylab="f(x)",ylim=c(0,3))
curve(dbbs(x,0.53037, 0.67858, -0.50496),xlim=c(0.01,5),add=TRUE,col=2,ylab="f(x)",ylim=c(0,3))

########################

data(psi21)
psi21m = psi21
mean(psi21)
mlebs(psi21m)
MMEbbs(psi21m)

hist(psi21,prob=TRUE)
curve(dgbs(x,.3101348,1336.377),add=TRUE,col=1)
curve(dbbs(x,.3264863,1336.564,0.2794193),add=TRUE,col=2)
write.table(psi21,"psi21.mat",row.names = FALSE, col.names = FALSE, sep = ",")

########################

data(psi31)
mean(psi31); median(psi31); var(psi31);length(psi31)
mlebs(psi31)
hist(psi31, prob=T)
curve(dgbs(x,0.1703847,131.8188),add=TRUE,col=1,lwd=1.5,lty=1)
sqrt(diag(solve(-HessMat(psi31,0.1703847,131.8188,0)[c(1,2),c(1,2)])))
sqrt(diag(solve(-HessMat(psi31,.264,132.214,1.196))))

########################

data(fracture)
hist(fracture,prob=TRUE)
mlebs(fracture)
curve(dgbs(x,.122,73.745),add=TRUE,col=1)

MMEbbs(fracture)
curve(dbbs(x,.135,73.873,.245),add=TRUE,col=2)

########################

data(precipitations)
hist(precipitations,prob=TRUE,breaks=15)
mlebs(precipitations)
curve(dgbs(x,.5,1.917),add=TRUE,col=1)

MMEbbs(precipitations)
curve(dbbs(x,.279,2.205,-1.51),add=TRUE,col=2)

########################

data(repairtimes)
hist(repairtimes,prob=TRUE)
mlebs(repairtimes)
curve(dgbs(x,1.25,2.05),add=TRUE,col=1)

MMEbbs(repairtimes)
curve(dbbs(x,1.12,2.08,-.27),add=TRUE,col=2)

########################

faithful = read.table("faithful.mat")
head(faithful)
hist(faithful[,1],prob=TRUE)
# write.table(faithful[,3],"faithful.mat",row.names = FALSE, col.names = FALSE, sep = ",")

MMEbbs(faithful[,3])
curve(dbbs(x,.0898,65.785,-2.1255),add=TRUE,col=2)

########################

euro = read.table("euro.mat",sep=',')
head(euro)
euro2 = as.vector(as.matrix(euro))
length(euro2)

hist(euro2,prob=TRUE,n=14)
# write.table(euro,"euro.mat",row.names = FALSE, col.names = FALSE, sep = ",")

mlebs(euro2)
curve(dgbs(x,0.12402,1.35099),add=TRUE,col=1)
-2*loglikgbs(euro2) + 4           # AIC
-2*loglikgbs(euro2) + 2*log(110)  # BIC

MMEbbs(euro2)
curve(dbbs(x, 0.058064,1.3510,-1.8507),add=TRUE,col=2)
curve(dgbs2(x, 5.6042, 1.3529, 12.0478),add=TRUE,col=2)

-2*sum(log(dbbs(euro2,0.058064,1.3510,-1.8507))) + 6
-2*sum(log(dgbs2(euro2,5.6042, 1.3529, 12.0478))) + 6

ks.test(euro2, "pbbs",0.058064,1.3510,-1.8507)
ks.test(euro2, "pgbs2",5.6042, 1.3529, 12.0478)

########################

weibullsim = read.table("WeibullSim.mat")
dim(weibullsim)
weibullsim2 = as.vector(as.matrix(weibullsim))
length(weibullsim2)

hist(weibullsim2,prob=TRUE,n=9)
#write.table(weibullsim2,"weibullSim.mat",row.names = FALSE, col.names = FALSE, sep = ",")

mlebs(weibullsim2)
curve(dgbs(x,0.383839,1.125543),add=TRUE,col=1)
-2*loglikgbs(weibullsim2) + 4           # AIC
-2*loglikgbs(weibullsim2) + 2*log(110)  # BIC

MMEbbs(weibullsim2)
curve(dbbs(x,0.22913, 1.1769, -1.2625),add=TRUE,col=2)
curve(dgbs2(x,3.6325,1.1065,3.1135),add=TRUE,col=3)

-2*sum(log(dbbs(weibullsim2,0.22913, 1.1769, -1.2625))) + 6
-2*sum(log(dgbs2(weibullsim2,3.6325,1.1065,3.1135))) + 6

ks.test(weibullsim2, "pbbs",0.22913, 1.1769, -1.2625)
ks.test(weibullsim2, "pgbs2",3.6325,1.1065,3.1135)

########################

# strengths of glass fibres, measured at the National 
# Physical Laboratory
# Tese do Rodrigo Bernardo
#install.packages("gamlss.data")
data(glass)
#write.table(glass[,1],"glass.mat",row.names = FALSE, col.names = FALSE, sep = ",")
length(glass[,1])
hist(glass[,1],prob=TRUE,breaks=10,xlab="x",ylab="Densidade",main="")

mlebs(glass[,1])
curve(dgbs(x,0.2621206,1.456607),add=TRUE,col=1,lwd=1.5,lty=1)
sqrt(diag(solve(InfMat(0.2621206,1.456607, 0,63)[c(1,2),c(1,2)])))

MMEbbs(glass[,1])
curve(dbbs(x,0.2736016, 1.45678, 0.3551792),add=TRUE,col=2)  #MME
curve(dbbs(x,0.67738, 1.58, 3.3536),add=TRUE,col=1,lwd=1.5,lty=2)   # EMV penalizado
#Erros padrões da bbs com penalização
sqrt(diag(solve(-HessMat(glass[,1],0.67738, 1.58, 3.3536))))
curve(dbbs(x,6.1734, 1.5900, 36.312),add=TRUE,col=3)  # uĺtimo valor do EMV ordinário

sqrt(diag(solve(-HessMat(glass[,1],0.67738, 1.58, 3.35360))/63))
ks.test(glass[,1], "pbbs",0.67738, 1.58, 3.3536)
ks.test(glass[,1], "pgbs",0.2621206,1.456607)

# preparando o gráfico para o Latex
postscript(file="glass_fits.eps",horizontal = FALSE, width = 8.0, height = 6.0,
           paper="special")
hist(glass[,1],prob=TRUE,breaks=10,xlab="x",ylab="Densidade",main="")
curve(dgbs(x,0.2621206,1.456607),add=TRUE,col=1,lwd=1.5,lty=1)
curve(dbbs(x,0.67738, 1.58, 3.3536),add=TRUE,col=1,lwd=1.5,lty=2)   # EMV penalizado
dev.off()
# estatísticas descritivas
m1 = mean(glass[,1])
m2 = var(glass[,1])
m3 = mean((glass[,1]-m1)^3)/m2^1.5
m4 = mean((glass[,1]-m1)^4)/m2^2
min(glass[,1])
max(glass[,1])
median(glass[,1])

########################

# Failure time of mechanical components
# Tese do Rodrigo Bernardo
mechanical = c(0.067, 0.068, 0.076, 0.081, 0.084, 0.085, 0.085,
       0.086, 0.089, 0.098, 0.098, 0.114, 0.114, 0.115, 0.121,
       0.125, 0.131, 0.149, 0.160, 0.485)
hist(mechanical)

mlebs(mechanical)
curve(dgbs(x,0.4466415,0.1107203),add=TRUE,col=1)

MMEbbs(mechanical)
curve(dbbs(x,0.0466415,0.3107203, -7.14612),add=TRUE,col=2)

########################

# carbon monoxide data
# Tese da Maria do Carmo - p?g. 65 e 73
carbon = c(0.05, 0.05, 0.05, 1, 1, 2, 2, 3, 2, 3, 3, 3, 3, 3, 4, 5, 4, 6, 6, 7, 4, 4, 6, 6, 6, 6, 6, 6, 7, 5, 5, 6, 7, 8, 8, 5, 4, 4,
       4, 4, 5, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 8, 8, 5, 6, 6, 6, 8, 8, 8, 8, 8, 8,
       9, 9, 10, 10, 11, 11, 11, 11, 11, 12, 12, 12, 5, 9, 10, 10, 5, 6, 8, 9, 9, 9, 10, 11, 10, 10, 12, 15, 10, 11, 11,
       11, 11, 11, 12, 12, 12, 13, 14, 9, 6, 9, 9, 10, 10, 10, 10, 10, 10, 11, 11, 12, 10, 10, 10, 10, 10, 10, 11, 11,
       11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 11, 12, 12, 12, 13, 13, 15,
       16, 16, 17, 17, 18, 15, 10, 10, 10, 11, 11, 12, 12, 9, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12,
       12, 13, 13, 14, 14, 14, 14, 15, 12, 13, 13, 14, 14, 14, 16, 14, 15, 15, 15, 17, 18, 14, 15, 16, 15, 14, 11,
       11, 11, 12, 13, 13, 14, 15, 15, 9, 12, 12, 12, 12, 19, 12, 13, 14, 14, 14, 15, 16, 16, 14, 15, 15, 16, 14, 14,
       17, 9, 11, 12, 12, 13, 13, 13, 13, 14, 14, 15, 16, 18, 13, 13, 14, 14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 16,
       16, 16, 17, 17, 14, 14, 14, 15, 16, 17, 9, 13, 13, 14, 14, 15, 16, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 15,
       17, 17, 12, 15, 22, 12, 17, 17, 15, 14, 15, 15, 16, 16, 17, 17, 17, 15, 16, 20, 20, 13, 15, 15, 15, 12, 18,
       16, 16, 16, 14, 16, 15, 15, 16,18,16,16,18,16)
hist(carbon,prob=TRUE)

mlebs(carbon)
curve(dgbs(x,1.270188,5.561446),add=TRUE,col=1)

MMEbbs(carbon)
curve(dbbs(x,0.2835944,12.330812, 0.242424),add=TRUE,col=2)
median(carbon)

########################

# enzyme data
# dados do artigo de Balakrishnan et al (2011)

enzyme = c(0.021, 0.031, 0.044, 0.061, 0.070, 0.077,
           0.078, 0.080, 0.081, 0.083, 0.083, 0.084, 0.085, 0.088, 0.096, 0.096, 0.100, 0.106, 0.108, 0.108, 0.109, 0.111, 0.112, 0.113, 0.118, 0.118, 0.122,
           0.124, 0.124, 0.124, 0.126, 0.126, 0.126, 0.128, 0.129, 0.130, 0.130, 0.131, 0.132, 0.132, 0.134, 0.137, 0.137, 0.138, 0.142, 0.142, 0.144, 0.148, 0.148, 0.149, 0.149, 0.151,
           0.152, 0.152, 0.157, 0.159, 0.162, 0.162, 0.162, 0.166, 0.166, 0.167, 0.167, 0.171, 0.172, 0.172, 0.174, 0.175, 0.176, 0.176, 0.178, 0.179, 0.179, 0.180, 0.180, 0.182, 0.183,
           0.184, 0.184, 0.185, 0.185, 0.190, 0.190, 0.191, 0.192, 0.192, 0.192, 0.192, 0.193, 0.194, 0.195, 0.198, 0.198, 0.198, 0.200, 0.200,0.204, 0.205, 0.207, 0.210, 0.213, 0.214, 0.215,
           0.216, 0.222, 0.224, 0.225, 0.230, 0.230, 0.232, 0.232, 0.236, 0.238, 0.240, 0.241, 0.246, 0.250, 0.255, 0.258, 0.258, 0.258, 0.263, 0.264, 0.265, 0.275,
           0.277, 0.279, 0.280, 0.291, 0.291, 0.292, 0.293, 0.299, 0.305, 0.305, 0.308, 0.309, 0.313, 0.320, 0.320, 0.325, 0.340, 0.342, 0.347, 0.357, 0.360,
           0.368, 0.379, 0.387, 0.408, 0.409, 0.466, 0.520, 0.673, 0.687, 0.709, 0.718, 0.818, 0.839, 0.853, 0.860, 0.867, 0.875, 0.895, 0.902,
           0.909, 0.923, 0.929, 0.933, 0.945, 0.953, 0.953, 0.962, 0.967, 0.978, 0.985, 0.998, 1.003, 1.004, 1.007, 1.010, 1.018, 1.036, 1.036, 1.040, 1.052,
           1.073, 1.075, 1.113, 1.123, 1.161, 1.166, 1.169, 1.173, 1.176, 1.195, 1.195, 1.200, 1.229, 1.231, 1.241, 1.261, 1.271, 1.279, 1.293, 1.298,
           1.300, 1.310, 1.326, 1.329, 1.361, 1.369, 1.371, 1.374, 1.405, 1.419, 1.452, 1.461, 1.488, 1.516, 1.567, 1.573, 1.604, 1.622, 1.625,
           1.633, 1.672, 1.713, 1.741, 1.742, 1.768, 1.811, 1.848, 1.861, 1.885, 1.944, 1.950, 2.016, 2.183, 2.264, 2.338, 2.427, 2.518, 2.545,
           2.880)
# write.table(enzyme,"enzyme.mat",row.names = FALSE, col.names = FALSE, sep = ",")
hist(enzyme,prob=TRUE,breaks=20,main="",ylab="Densidade",xlab="x",ylim=c(0,2.6))
# estatísticas descritivas
m1 = mean(enzyme);m1
m2 = var(enzyme);m2
m3 = mean((enzyme-m1)^3)/m2^1.5; m3
m4 = mean((enzyme-m1)^4)/m2^2; m4
min(enzyme)
max(enzyme)
median(enzyme)
length(enzyme)

# ajuste da bs
mlebs(enzyme)
curve(dgbs(x,1.145776,0.3782713),add=TRUE,lty=1,lwd=2)
# erros padrões das estimativas da bs
sqrt(diag(solve(-HessMat(enzyme,1.145776,0.3782713,0)[c(1,2),c(1,2)])))

#MMEbbs(enzyme)
# ajuste com a bbs
curve(dbbs(x,0.58712, 0.44207, -1.6622),add=TRUE,lty=2,lwd=2)
# erros padrões das estimativas da bbs
sqrt(diag(solve(-HessMat(enzyme,0.58712, 0.44207, -1.6622))))
# ajuste com a gbs2
curve(dgbs2(x,2.2676, 0.38016, 0.83450),add=TRUE,lty=3,lwd=2)

# AIC
-2*sum(log(dgbs(enzyme,1.145776,0.3782713))) + 4
-2*sum(log(dbbs(enzyme,0.58712, 0.44207, -1.6622))) + 6
-2*sum(log(dgbs2(enzyme,2.2676, 0.38016, 0.83450))) + 6
# BIC
-2*sum(log(dgbs(enzyme,1.145776,0.3782713))) + 2*log(245)
-2*sum(log(dbbs(enzyme,0.58712, 0.44207, -1.6622))) + 3*log(245)
-2*sum(log(dgbs2(enzyme,2.2676, 0.38016, 0.83450))) + 3*log(245)

ks.test(enzyme, "pbbs",0.58712, 0.44207, -1.6622)
ks.test(enzyme, "pgbs2",2.2676, 0.38016, 0.83450)


########################

# depressive condition data
# dados do artigo de Balakrishnan et al (2011)
dcd2 = matrix(c(19, 16, 20, 15, 21, 14, 22, 9, 23, 12, 24, 10, 25, 6, 26, 9, 27, 8, 28, 5, 29, 6, 30, 4, 31, 3, 32, 4, 33, 1,
                34, 1, 35, 4, 36, 2, 37, 2, 39, 1, 42, 1, 44, 1),22,2,byrow=TRUE)
sum(dcd2[,2])
depressive = c(0)
for(i in 1:22){
  depressive = c(depressive, rep(dcd2[i,1], dcd2[i,2]))
}
depressive = depressive[-1]
length(depressive)
depressive2 = depressive - 16

#write.table(depressive2,"depressive2.mat",row.names = FALSE, col.names = FALSE, sep = ",")
hist(depressive2,prob=TRUE,breaks=20,main="",ylab="Densidade",xlab="x")
# estatísticas descritivas
m1 = mean(depressive2);m1
m2 = var(depressive2);m2
m3 = mean((depressive2-m1)^3)/m2^1.5; m3
m4 = mean((depressive2-m1)^4)/m2^2; m4
min(depressive2)
max(depressive2)
median(depressive2)

# Ajuste da bs
mlebs(depressive2)
curve(dgbs(x,0.603561,7.58351),add=TRUE,lty=1,lwd=2)
# erros padrões das estimativas da bs
sqrt(diag(solve(-HessMat(depressive2,0.603561,7.58351,0)[c(1,2),c(1,2)])))

#MMEbbs(depressive2)
# Ajuste da bbs
curve(dbbs(x,0.42460, 7.5444, -0.85414),lty=2,lwd=2,add=TRUE)
#Erros padrões da bbs
sqrt(diag(solve(-HessMat(depressive2,0.42460, 7.5444, -0.85414))))
# Ajuste da gbs2
curve(dgbs2(x,2.3892, 7.7452, 1.5390),lty=3,lwd=2,add=TRUE)

# AIC
-2*sum(log(dgbs(depressive2,0.603561,7.58351))) + 4
-2*sum(log(dbbs(depressive2,0.42460, 7.5444, -0.85414))) + 6
-2*sum(log(dgbs2(depressive2,2.3892, 7.7452, 1.5390))) + 6
# BIC
-2*sum(log(dgbs(depressive2,0.603561,7.58351))) + 2*log(134)
-2*sum(log(dbbs(depressive2,0.42460, 7.5444, -0.85414))) + 3*log(134)
-2*sum(log(dgbs2(depressive2,2.3892, 7.7452, 1.5390))) + 3*log(134)

ks.test(depressive2, "pbbs",0.42460, 7.5444, -0.85414)
ks.test(depressive2, "pgbs2",2.3892, 7.7452, 1.5390)
ks.test(depressive2, "pgbs",0.603561,7.58351)
-2*sum(log(dgbs(depressive2,0.603561,7.58351))) + 2*log(134)

# Preparando o gráfico das densidades para o Latex
postscript(file="depressive_fits.eps",horizontal = FALSE, width = 8.0, height = 6.0,
           paper="special")
hist(depressive2,prob=TRUE,breaks=20,main="",ylab="Densidade",xlab="x")
curve(dgbs(x,0.603561,7.58351),add=TRUE,lty=1,lwd=2)
curve(dbbs(x,0.42460, 7.5444, -0.85414),lty=2,lwd=2,add=TRUE)
curve(dgbs2(x,2.3892, 7.7452, 1.5390),lty=3,lwd=2,add=TRUE)
dev.off()

########################

require(bootstrap)
data(stamp)
hist(stamp[,1],prob=TRUE,breaks=20)
write.table(stamp[,1],"stamp.mat",row.names = FALSE, col.names = FALSE, sep = ",")

mlebs(stamp[,1])
curve(dgbs(x,0.1647308,0.08487361),add=TRUE,col=1)

MMEbbs(stamp[,1])
curve(dbbs(x,0.083002, 0.088481, -1.7421),add=TRUE,col=2)


######################################################################
# Adhesive strength - Devore 7th Ed., pg. 18

adhesive = c(11.5, 12.1, 9.9, 9.3, 7.8, 6.2, 6.6, 7.0, 13.4, 17.1, 9.3, 5.6,
         5.7, 5.4, 5.2, 5.1, 4.9, 10.7, 15.2, 8.5, 4.2, 4.0, 3.9, 3.8,
         3.6, 3.4, 20.6, 25.5, 13.8, 12.6, 13.1, 8.9, 8.2, 10.7, 14.2, 7.6,
         5.2, 5.5, 5.1, 5.0, 5.2, 4.8, 4.1, 3.8, 3.7, 3.6, 3.6, 3.6)
#write.table(adhesive,"adhesive.mat",row.names = FALSE, col.names = FALSE, sep = ",")
hist(adhesive,prob=TRUE,breaks=20,main="",ylab="Densidade",xlab="x")
# estatísticas descritivas
m1 = mean(adhesive);m1
m2 = var(adhesive);m2
m3 = mean((adhesive-m1)^3)/m2^1.5; m3
m4 = mean((adhesive-m1)^4)/m2^2; m4
min(adhesive)
max(adhesive)
median(adhesive)
length(adhesive)

# Ajuste da bs
mlebs(adhesive)
curve(dgbs(x,0.5424427,7.050655),add=TRUE,lty=1,lwd=2)
# erros padrões das estimativas da bs
sqrt(diag(solve(-HessMat(adhesive,0.5424427,7.050655,0)[c(1,2),c(1,2)])))

#MMEbbs(adhesive)
# Ajuste da bbs
curve(dbbs(x,0.30759, 7.3900, -1.3864),lty=2,lwd=2,add=TRUE)
#Erros padrões da bbs
sqrt(diag(solve(-HessMat(adhesive,0.30759, 7.3900, -1.3864))))
# Ajuste da gbs2
curve(dgbs2(x,3.1939, 8.0547, 1.9970),lty=3,lwd=2,add=TRUE,col=2)

# AIC
-2*sum(log(dgbs(adhesive,0.5424427,7.050655))) + 4
-2*sum(log(dbbs(adhesive,0.30759, 7.3900, -1.3864))) + 6
-2*sum(log(dgbs2(adhesive,3.1939, 8.0547, 1.9970))) + 6
# BIC
-2*sum(log(dgbs(adhesive,0.5424427,7.050655))) + 2*log(48)
-2*sum(log(dbbs(adhesive,0.30759, 7.3900, -1.3864))) + 3*log(48)
-2*sum(log(dgbs2(adhesive,3.1939, 8.0547, 1.9970))) + 3*log(48)

# Preparando o gráfico das densidades para o Latex
postscript(file="adhesive_fits.eps",horizontal = FALSE, width = 8.0, height = 6.0,
           paper="special")
hist(adhesive,prob=TRUE,breaks=20,main="",ylab="Densidade",xlab="x")
curve(dgbs(x,0.5424427,7.050655),add=TRUE,lty=1,lwd=2)
curve(dbbs(x,0.30759, 7.3900, -1.3864),lty=2,lwd=2,add=TRUE)
curve(dgbs2(x,3.1939, 8.0547, 1.9970),lty=3,lwd=2,add=TRUE)
dev.off()











