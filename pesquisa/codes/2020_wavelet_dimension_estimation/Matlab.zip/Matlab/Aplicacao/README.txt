3105065001ds0004_2014.xls
This file 3105065001ds0004_2014.xls can be downloaded on the following
website, and contains the Australian fertility data.
<http://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/3105.0.65.0012014?OpenDocument>


Australia_Fert_Rate.csv
Australian fertility data prepared to be read in the matlab.


Autralia_Fert_Rate_Bathia.m
Matlab code to analyze the fertility data using Bathia's method and the
method with data aggregation. Here, discretization of the observed
functions is not performed and numerical integration is used. Only
eigenvalues are computed, though.


Autralia_Fert_Rate_WavDimEst.m
Matlab code to analyze the fertility data using the wavelet methods
developed in the paper. We use the different types of bootstrap and
estimate the process' dimension using them. The methods of Bathia and
with data aggregation are also applied, but we approximate the integrals
using discretization.


DimEst_Aggreg_du.m
Nessa função é realizado o procedimento bootstrap para estimar a 
dimensão do processo usando o método com agregaçao de dados.
Y é a matriz de funções observadas, mEigFunc é a matriz de autofunções
calculadas usando a equação (2.13) de Bathia et al (2010),
NREP é o número de réplicas bootstrap e p é lag máximo, e o vetor de
pesos da agregaçao, vu e a distancia entre duas observaçoes consecutivas
usadas na discretizaçao do problema.


DimEst_Bathia_du.m
Nessa função é realizado o procedimento bootstrap para estimar a 
dimensão do processo usando o método proposto por Bathia et al (2010).
Nessa funçao as integrais sao aproximadas usando discretizaçao.
Y é a matriz de funções observadas, mEigFunc é a matriz de autofunções
calculadas usando a equação (2.13) de Bathia et al (2010),
NREP é o número de réplicas bootstrap e p é lag máximo, vu e a distancia 
entre duas observaçoes consecutivas usadas na discretizaçao do problema.


DimEst_wavestrap.m
Nessa função é realizado o procedimento bootstrap para estimar a 
dimensão do processo, mas diferentemente do que é feito em DimEst_boot.m,
aqui aproveitamos as decomposições obtidas para realizar a reamostragem
nos termos formados com os coeficientes, o que deixa o código mais rápido.
A é a matriz de coeficientes de ondaletas dos funcionais observados, 
nas colunas, para diferentes dias, nas linhas.
NREP é o número de réplicas bootstrap. p é lag máximo. 

DimEst_wavestrap_thresh.m
Nessa função é realizado o procedimento bootstrap para estimar a 
dimensão do processo, as decomposições obtidas são aproveitadas na
reamostragem, que teoricamente é feita sobre o resíduo obtido após ser 
feita uma limiarização sobre os coeficientes das decomposições da média
do processo e das autofunções.
A é a matriz de coeficientes de ondaletas dos funcionais observados, 
nas colunas, para diferentes dias, nas linhas.
NREP é o número de réplicas bootstrap. p é lag máximo. 


FuncMatProdYcentAggregVet.m
A função retorna uma matriz de dimensão (n-p-delta+1)x(n-p-delta+1) com o
produto dos funcionais observados centrados pela média e armazenados em
C e multiplicados pelos pesos no vetor w. Aqui, o produto e feito
conforme deve ser feito no caso em que se utiliza agregaçao.
O lag máximo do processo é dado em p e o lag usado com os
funcionais ponderados são armazenados em k.


MatGramSchm.m
função para aplicar o método de Gram-Schmidt aos vetores da matriz Y


SmoLogFertRate.csv
Data with the discretization of the observed Australian log-fertility 
rates to be used with the R code stationary_test.R to test the process'
stationarity.


stationary_test.R
R code used to perform a stationarity test in the observed Australian log-fertility rates using the package ftsa.

