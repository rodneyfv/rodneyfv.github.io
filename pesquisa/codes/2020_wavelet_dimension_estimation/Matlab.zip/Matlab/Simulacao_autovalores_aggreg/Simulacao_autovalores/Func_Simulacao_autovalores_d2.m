function [ mEigValDim2 ] = Func_Simulacao_autovalores_d2( n, NREP, p, vw )
% função para estimar a média dos autovalores estimados com o método de
% Bathia et al para dados agregados. n é o tamanho amostral usado, NREP é
% o número de réplicas usado, p é o lag máximo utilizado e vw é o vetor com
% os pesos de agregação.
% Nessa funçao e simulado um funcional de dimensao dois e depois calculamos
% os autovalores da matriz D obtida

delta = length(vw); % número de pesos usados
% matriz que armazena os autovalores estimados nas réplicas
mEigVal = zeros(NREP,10);

model_xi1 = arima('Constant',0,'AR',{-.65},'Variance',1.5);
model_xi2 = arima('Constant',0,'AR',{.4},'Variance',1.5);

    for jj=1:NREP
        xi1 = simulate(model_xi1,n);xi2 = simulate(model_xi2,n);

        % funcional observado
        fh_Y = cell(n,1);

        for ii=1:n
            vZ = normrnd(0,1,10,1);
            fh_Y{ii} = @(x) xi1(ii)*sqrt(2)*cos(pi*x) + xi2(ii)*sqrt(2)*cos(2*pi*x)...
                + sqrt(2)*(vZ(1)*sin(pi*x) + vZ(2)*sin(2*pi*x)/2 ...
                + vZ(3)*sin(3*pi*x)/4 + vZ(4)*sin(4*pi*x)/8 ...
                + vZ(5)*sin(5*pi*x)/16 + vZ(6)*sin(6*pi*x)/32 ...
                + vZ(7)*sin(7*pi*x)/64 + vZ(8)*sin(8*pi*x)/128 ...
                + vZ(9)*sin(9*pi*x)/256 + vZ(10)*sin(10*pi*x)/512);
        end

        %%%%%%%%%%%%%%%%

        % funcional observado centrado
        mat_G = integral(@(x) FuncMatProdYcent( fh_Y, x),0,1,'ArrayValued',true);

        % matriz com os produtos internos dos funcionais centrados multiplicados
        % pelos pesos
        Zk = zeros(n-p-delta+1,n-p-delta+1,p-delta+1);
        for k=delta:(p-delta+1)
            mat_Z = integral(@(x) FuncMatProdYcentAggreg( fh_Y, vw, p, k, x),0,1,'ArrayValued',true);
            Zk(:,:,k) = mat_Z;
        end

        Kstar = sum(Zk,3)*mat_G(1:(n-p-delta+1),1:(n-p-delta+1))/((n-p-delta+1)^2);

        [~,EigValK] = eig(Kstar);
        mEigVal(jj,:) = diag(EigValK(1:10,1:10))';        
    end
    % média dos autovalores estimados nas réplicas
    mEigValDim2 = mean(mEigVal,1);

end

