% Código usado para gerar o gráfico que mostra a convergência dos
% autovalores estimados sem agregaçao (metodo do Bathia) e com agregaçao.
% Nos usamos os autovalores gerados na simalacao do arquivo
% Simulacao_autovalores.m e armazenados nos arquivos
% file_autovalores_agreg.mat e file_autovalores_Bathia.mat
% No final geramos um grafico com os autovalores para diferentes dimensoes
% nas colunas e diferentes metodos (com ou sem agregacao) nas linhas

% Resultados da simulação de autovalores
EigValRes_agreg = matfile('file_autovalores_agreg.mat');
EigValRes_Bathia = matfile('file_autovalores_Bathia.mat');

vN = EigValRes_agreg.vN;

% lag máximo utilizado
p = 5;
vw = [.1,.3,.5]'; % vetor de pesos
delta = length(vw); % número de pesos usados


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% dimensão verdadeira
d = 2;

vPhi = (((-1).^(1:d)).*(.9 - (1:d)./(2*d)))';
mSig = zeros(d,p);
vKeigval = zeros(p,1);
for jj=1:d
    for k=1:p
        % autovalor verdadeiro calculado
        mSig(jj,k) = 1.5*(vPhi(jj)^k)/(1 - vPhi(jj)^2);
    end
    % autovalor do operador usado na estimação
    vKeigval(jj) = sum(mSig(jj,:).^2);
end
vKeigvalAgreg = zeros(p,1);
mAlpha = zeros(d,p-2*delta+2);
for jj=1:d
    for k=delta:(p-delta+1)
        % autovalor verdadeiro calculado
        for ss = 0:(delta - 1)
            for ll = 0:(delta - 1)
                mAlpha(jj,k-delta+1) = mAlpha(jj,k-delta+1) + vw(delta-ss)*vw(delta-ll)*mSig(jj,ll-ss+k);
            end
        end
    end
    % autovalor do operador usado na estimação
    vKeigvalAgreg(jj) = sum(mAlpha(jj,:).^2);
end
vKeigvalAgreg = sort(vKeigvalAgreg,'descend');

%%%%%%%%%%%%%%%%

mEigVal_agreg = EigValRes_agreg.mEigValDim2;
mEigVal_Bathia = EigValRes_Bathia.mEigValDim2;

subplot(2,3,1)
hold on
plot(vN,log(mEigVal_agreg(:,1)),'-o','color','k','LineWidth',1.5); xlabel('n');
plot(vN,log(mEigVal_agreg(:,2)),'-+','color','b','LineWidth',1.5)
xlim([0 700])
hline = refline([0 log(vKeigvalAgreg(1))]);hline.Color = 'k';hline.LineStyle = '-';
hline = refline([0 log(vKeigvalAgreg(2))]);hline.Color = 'b';hline.LineStyle = '-';

subplot(2,3,4)
hold on
plot(vN,log(mEigVal_Bathia(:,1)),'-o','color','k','LineWidth',1.5); xlabel('n');
plot(vN,log(mEigVal_Bathia(:,2)),'-+','color','b','LineWidth',1.5)
xlim([0 700])
hline = refline([0 log(vKeigval(1))]);hline.Color = 'k';hline.LineStyle = '-';
hline = refline([0 log(vKeigval(2))]);hline.Color = 'b';hline.LineStyle = '-';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% dimensão verdadeira
d = 4;

vPhi = (((-1).^(1:d)).*(.9 - (1:d)./(2*d)))';
mSig = zeros(d,p);
vKeigval = zeros(p,1);
for jj=1:d
    for k=1:p
        % autovalor verdadeiro calculado
        mSig(jj,k) = 1.5*(vPhi(jj)^k)/(1 - vPhi(jj)^2);
    end
    % autovalor do operador usado na estimação
    vKeigval(jj) = sum(mSig(jj,:).^2);
end
vKeigvalAgreg = zeros(p,1);
mAlpha = zeros(d,p-2*delta+2);
for jj=1:d
    for k=delta:(p-delta+1)
        % autovalor verdadeiro calculado
        for ss = 0:(delta - 1)
            for ll = 0:(delta - 1)
                mAlpha(jj,k-delta+1) = mAlpha(jj,k-delta+1) + vw(delta-ss)*vw(delta-ll)*mSig(jj,ll-ss+k);
            end
        end
    end
    % autovalor do operador usado na estimação
    vKeigvalAgreg(jj) = sum(mAlpha(jj,:).^2);
end
vKeigvalAgreg = sort(vKeigvalAgreg,'descend');

%%%%%%%%%%%%%%%%

mEigVal_agreg = EigValRes_agreg.mEigValDim4;
mEigVal_Bathia = EigValRes_Bathia.mEigValDim4;

subplot(2,3,2)
hold on
plot(vN,log(mEigVal_agreg(:,1)),'-o','color','k','LineWidth',1.5); xlabel('n');
plot(vN,log(mEigVal_agreg(:,2)),'-+','color','b','LineWidth',1.5)
 plot(vN,log(mEigVal_agreg(:,3)),'-*','color','r','LineWidth',1.5)
 plot(vN,log(mEigVal_agreg(:,4)),'-x','color','g','LineWidth',1.5)
xlim([0 700])
hline = refline([0 log(vKeigvalAgreg(1))]);hline.Color = 'k';hline.LineStyle = '-';
hline = refline([0 log(vKeigvalAgreg(2))]);hline.Color = 'b';hline.LineStyle = '-';
 hline = refline([0 log(vKeigvalAgreg(3))]);hline.Color = 'r';hline.LineStyle = '-';
 hline = refline([0 log(vKeigvalAgreg(4))]);hline.Color = 'g';hline.LineStyle = '-';

subplot(2,3,5)
hold on
plot(vN,log(mEigVal_Bathia(:,1)),'-o','color','k','LineWidth',1.5); xlabel('n');
plot(vN,log(mEigVal_Bathia(:,2)),'-+','color','b','LineWidth',1.5)
 plot(vN,log(mEigVal_Bathia(:,3)),'-*','color','r','LineWidth',1.5)
 plot(vN,log(mEigVal_Bathia(:,4)),'-x','color','g','LineWidth',1.5)
xlim([0 700])
hline = refline([0 log(vKeigval(1))]);hline.Color = 'k';hline.LineStyle = '-';
hline = refline([0 log(vKeigval(2))]);hline.Color = 'b';hline.LineStyle = '-';
 hline = refline([0 log(vKeigval(3))]);hline.Color = 'r';hline.LineStyle = '-';
 hline = refline([0 log(vKeigval(4))]);hline.Color = 'g';hline.LineStyle = '-';

text(2.5, 11.5,'Method with data aggregation', 'FontSize', 13)
text(2.5, 4.7,'Method without data aggregation', 'FontSize', 13)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% dimensão verdadeira
d = 6;

vPhi = (((-1).^(1:d)).*(.9 - (1:d)./(2*d)))';
mSig = zeros(d,p);
vKeigval = zeros(p,1);
for jj=1:d
    for k=1:p
        % autovalor verdadeiro calculado
        mSig(jj,k) = 1.5*(vPhi(jj)^k)/(1 - vPhi(jj)^2);
    end
    % autovalor do operador usado na estimação
    vKeigval(jj) = sum(mSig(jj,:).^2);
end
vKeigvalAgreg = zeros(p,1);
mAlpha = zeros(d,p-2*delta+2);
for jj=1:d
    for k=delta:(p-delta+1)
        % autovalor verdadeiro calculado
        for ss = 0:(delta - 1)
            for ll = 0:(delta - 1)
                mAlpha(jj,k-delta+1) = mAlpha(jj,k-delta+1) + vw(delta-ss)*vw(delta-ll)*mSig(jj,ll-ss+k);
            end
        end
    end
    % autovalor do operador usado na estimação
    vKeigvalAgreg(jj) = sum(mAlpha(jj,:).^2);
end
vKeigvalAgreg = sort(vKeigvalAgreg,'descend');

%%%%%%%%%%%%%%%%

mEigVal_agreg = EigValRes_agreg.mEigValDim6;
mEigVal_Bathia = EigValRes_Bathia.mEigValDim6;

subplot(2,3,3)
hold on
plot(vN,log(mEigVal_agreg(:,1)),'-o','color','k','LineWidth',1.5); xlabel('n');
plot(vN,log(mEigVal_agreg(:,2)),'-+','color','b','LineWidth',1.5)
 plot(vN,log(mEigVal_agreg(:,3)),'-*','color','r','LineWidth',1.5)
 plot(vN,log(mEigVal_agreg(:,4)),'-x','color','g','LineWidth',1.5)
 plot(vN,log(mEigVal_agreg(:,5)),'-s','color','y','LineWidth',1.5)
 plot(vN,log(mEigVal_agreg(:,6)),'-d','color','c','LineWidth',1.5)
xlim([0 700])
hline = refline([0 log(vKeigvalAgreg(1))]);hline.Color = 'k';hline.LineStyle = '-';
hline = refline([0 log(vKeigvalAgreg(2))]);hline.Color = 'b';hline.LineStyle = '-';
 hline = refline([0 log(vKeigvalAgreg(3))]);hline.Color = 'r';hline.LineStyle = '-';
 hline = refline([0 log(vKeigvalAgreg(4))]);hline.Color = 'g';hline.LineStyle = '-';
 hline = refline([0 log(vKeigvalAgreg(5))]);hline.Color = 'y';hline.LineStyle = '-';
 hline = refline([0 log(vKeigvalAgreg(6))]);hline.Color = 'c';hline.LineStyle = '-';

subplot(2,3,6)
hold on
plot(vN,log(mEigVal_Bathia(:,1)),'-o','color','k','LineWidth',1.5); xlabel('n');
plot(vN,log(mEigVal_Bathia(:,2)),'-+','color','b','LineWidth',1.5)
 plot(vN,log(mEigVal_Bathia(:,3)),'-*','color','r','LineWidth',1.5)
 plot(vN,log(mEigVal_Bathia(:,4)),'-x','color','g','LineWidth',1.5)
 plot(vN,log(mEigVal_Bathia(:,5)),'-s','color','y','LineWidth',1.5)
 plot(vN,log(mEigVal_Bathia(:,6)),'-d','color','c','LineWidth',1.5)
xlim([0 700])
hline = refline([0 log(vKeigval(1))]);hline.Color = 'k';hline.LineStyle = '-';
hline = refline([0 log(vKeigval(2))]);hline.Color = 'b';hline.LineStyle = '-';
 hline = refline([0 log(vKeigval(3))]);hline.Color = 'r';hline.LineStyle = '-';
 hline = refline([0 log(vKeigval(4))]);hline.Color = 'g';hline.LineStyle = '-';
 hline = refline([0 log(vKeigval(5))]);hline.Color = 'y';hline.LineStyle = '-';
 hline = refline([0 log(vKeigval(6))]);hline.Color = 'c';hline.LineStyle = '-';

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Construct a Legend with the data from the sub-plots
hL = legend('color',['k';'b';'r';'g';'y';'c'],{'\theta_1','\theta_2','\theta_3','\theta_4','\theta_5','\theta_6'},'Orientation','horizontal','fontsize',14);
legend('boxoff')
% Programatically move the Legend
newPosition = [0.4 -0.065 0.2 0.17];
newUnits = 'normalized';
set(hL,'Position', newPosition,'Units', newUnits);


