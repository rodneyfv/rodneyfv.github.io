% Código para avaliar quais são os autovalores verdadeiros usados na
% simulação do artigo, com e sem agregação de dados.

% lag máximo utilizado
p = 5;
% dimensão verdadeira
d = 2;
% vetor de coeficientes usado com d na simulação
vPhi = (((-1).^(1:d)).*(.9 - (1:d)./(2*d)))';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% matriz para armazenar os autovalores da função de covariância nas
% linhas para cada lag k específico em uma coluna
mSig = zeros(d,p);
% autovalores da função usada na estimação da dimensão
vKeigval = zeros(p,1);

for jj=1:d
    for k=1:p
        % autovalor verdadeiro calculado
        mSig(jj,k) = 1.5*(vPhi(jj)^k)/(1 - vPhi(jj)^2);
    end
    % autovalor do operador usado na estimação
    vKeigval(jj) = sum(mSig(jj,:).^2);
end

% resultados
%mSig
%vKeigval

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vw = [.1,.3,.5]'; % vetor de pesos
%vw = vw/norm(vw);
delta = length(vw); % número de pesos usados
% autovalores da função usada na estimação da dimensão aplicando agregação
% de dados
vKeigvalAgreg = zeros(p,1);
% matriz para armazenar os autovalores da função de covariância nas
% linhas para cada lag k específico em uma coluna, quando aplicamos
% agregação de dados
mAlpha = zeros(d,p-2*delta+2);


for jj=1:d
    for k=delta:(p-delta+1)
        % autovalor verdadeiro calculado
        for ss = 0:(delta - 1)
            for ll = 0:(delta - 1)
                mAlpha(jj,k-delta+1) = mAlpha(jj,k-delta+1) + vw(delta-ss)*vw(delta-ll)*mSig(jj,ll-ss+k);
            end
        end
    end
    % autovalor do operador usado na estimação
    vKeigvalAgreg(jj) = sum(mAlpha(jj,:).^2);
end

% resultados
%mAlpha
vKeigvalAgreg = sort(vKeigvalAgreg,'descend');
%vKeigvalAgreg'
%vKeigval'

% % versão matricial do loop anterior
% mAagreg = zeros(delta,delta);
% j_ind = 1;
% k_ind = delta;
% for ii=0:(delta-1)
%     mAagreg((ii+1),:) = mSig(j_ind,((k_ind-ii):(k_ind + delta-1-ii)));
% end
% mAagreg
% vw'*mAagreg*vw





