
% Código para avaliar os autovalores estimados com o método para dados
% agregados. É tirado a média dos autovalores estimados em diferentes
% réplicas, para diferentes tamanhos de amostra e dimensão.
% Sao utilizadas funçoes que ja geram o funcional e estimam, estimam a
% matriz e calculam os autovalores, sendo estes ultimos retornados pelas
% funçoes. Essas funçoes estao presentes na pasta Simulacao_autovalores e
% sao as seguintes: Func_Simulacao_autovalores_d2,
% Func_Simulacao_autovalores_d4 e Func_Simulacao_autovalores_d6
% Ao final do processo, armazenamos os autovalores em um arquivo chamado
% file_autovalores_Bathia.mat quando nao temos agregaçao de dados e
% file_autovalores_agreg.mat quando temos agregaçao

% número de réplicas
NREP = 1000;
% vetor com tamanhos amostrais avaliados
vN = [100,300,600];
% matrizes para armazenar os autovalores
mEigValDim2 = zeros(3,10);
mEigValDim4 = zeros(3,10);
mEigValDim6 = zeros(3,10);
% matriz que armazena os autovalores estimados nas réplicas
mEigVal = zeros(NREP,10);

p = 5; % lag máximo usado
vw = [1]'; % vetor de pesos
%vw = [.1,.3,.5]'; % vetor de pesos
delta = length(vw); % número de pesos usados

% adicionando caminho para chamar as funções da pasta
% Simulacao_autovalores, que vão ser usadas no parfor
addpath(genpath('Simulacao_autovalores'))
% adicionando caminho para chamar as funções da pasta
addpath(genpath('Funcoes'))

%%%%%%%%%%%%%%%
% Caso com d=2


% loop para passar nos diferentes tamanhos amostrais, identificado no
% primeiro argumento da funçao
tic;
parfor ll=1:3
    % usando uma função que simula as réplicas e permite usar o parfor
     mEigValDim2(ll,:) = Func_Simulacao_autovalores_d2(vN(ll),NREP, p, vw);
end
toc;

%%%%%%%%%%%%%%%
% Caso com d=4

% loop para passar nos diferentes tamanhos amostrais, identificado no
% primeiro argumento da funçao
tic;
parfor ll=1:3
    mEigValDim4(ll,:) = Func_Simulacao_autovalores_d4(vN(ll),NREP, p, vw);
end
toc;

%%%%%%%%%%%%%%%
% Caso com d=6

% loop para passar nos diferentes tamanhos amostrais, identificado no
% primeiro argumento da funçao
tic;
parfor ll=1:3
    mEigValDim6(ll,:) = Func_Simulacao_autovalores_d6(vN(ll),NREP, p, vw);
end
toc;

%%%%%%%%%%%%

mEigValDim2
mEigValDim4
mEigValDim6

% salvando as matrizes
%save('file_autovalores_agreg.mat','mEigValDim2','mEigValDim4','mEigValDim6','NREP','vN','p','vw');  
save('file_autovalores_Bathia.mat','mEigValDim2','mEigValDim4','mEigValDim6','NREP','vN','p','vw');  


subplot(3,1,1)
plot(mEigValDim2','LineWidth',2)
legend('100','300','600','Location','northeast')
legend('boxoff')
subplot(3,1,2)
plot(mEigValDim4','LineWidth',2)
legend('100','300','600','Location','northeast')
legend('boxoff')
subplot(3,1,3)
plot(mEigValDim6','LineWidth',2)
legend('100','300','600','Location','northeast')
legend('boxoff')

