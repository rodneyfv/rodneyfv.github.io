
A pasta Funcoes contém funções variadas usadas para estimar a dimensão de
séries temporais de curvas

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Simulacao_autovalores.m

% Código para avaliar os autovalores estimados com o método para dados
% agregados. É tirado a média dos autovalores estimados em diferentes
% réplicas, para diferentes tamanhos de amostra e dimensão.
% Sao utilizadas funçoes que ja geram o funcional e estimam, estimam a
% matriz e calculam os autovalores, sendo estes ultimos retornados pelas
% funçoes. Essas funçoes estao presentes na pasta Simulacao_autovalores e
% sao as seguintes: Func_Simulacao_autovalores_d2,
% Func_Simulacao_autovalores_d4 e Func_Simulacao_autovalores_d6
% Ao final do processo, armazenamos os autovalores em um arquivo chamado
% file_autovalores_Bathia.mat quando nao temos agregaçao de dados e
% file_autovalores_agreg.mat quando temos agregaçao

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Func_Simulacao_autovalores_d2.m

% função para estimar a média dos autovalores estimados com o método de
% Bathia et al para dados agregados. n é o tamanho amostral usado, NREP é
% o número de réplicas usado, p é o lag máximo utilizado e vw é o vetor com
% os pesos de agregação.
% Nessa funçao e simulado um funcional de dimensao dois e depois calculamos
% os autovalores da matriz D obtida

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Func_Simulacao_autovalores_d4.m

% função para estimar a média dos autovalores estimados com o método de
% Bathia et al para dados agregados. n é o tamanho amostral usado e NREP é
% o número de réplicas usado
% Nessa funçao e simulado um funcional de dimensao quatro e depois calculamos
% os autovalores da matriz D obtida


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Func_Simulacao_autovalores_d6.m

% função para estimar a média dos autovalores estimados com o método de
% Bathia et al para dados agregados. n é o tamanho amostral usado e NREP é
% o número de réplicas usado
% Nessa funçao e simulado um funcional de dimensao seis e depois calculamos
% os autovalores da matriz D obtida

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

graficos_autovalores_verdadeiros.m

% Código usado para gerar o gráfico que mostra a convergência dos
% autovalores estimados sem agregaçao (metodo do Bathia) e com agregaçao.
% Nos usamos os autovalores gerados na simalacao do arquivo
% Simulacao_autovalores.m e armazenados nos arquivos
% file_autovalores_agreg.mat e file_autovalores_Bathia.mat
% No final geramos um grafico com os autovalores para diferentes dimensoes
% nas colunas e diferentes metodos (com ou sem agregacao) nas linhas


