%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sim_DimEstWav.m
arquivo na pasta wavestrap_sem_limiar

% Estudo de simulação da dimensão do processo de séries temporais de curvas
% usando ondaletas. Nesse código é utilizada a função func_Sim_DimEstWav e
% cálculos em paralelo. As dimensões utilizadas variam em d=2,4,6 e os
% tamanhos amostrais usados são n=100,300,600. Ao final da simulação temos
% um arquivo para cada dimensão, com os dados gerados para cada cada valor
% de n.
% A técnica utilizada foi ondaletas sem thresholding, aplicando o
% procedimento bootstrap de Bathia.
% Na simulaçao obtemos para cada replica os oito maiores autovalores
% gerados, valores-p obtidos, dimensoes estimadas
% os resultados sao armazenados nos arquivos file_Sim_wavestrap_d2.mat,
% file_Sim_wavestrap_d4.mat e file_Sim_wavestrap_d6.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

func_Sim_DimEstWav.m
arquivo na pasta wavestrap_sem_limiar

% Essa função é utilizada para simular a estimação da dimensão de uma série
% temporal de curvas seguindo como fizeram Bathia et al (2010). As entradas
% são o tamanho amostral (número de curvas observadas) n, a dimensão do
% processo d, o número de réplicas da simulação NREP, o número de réplicas
% bootstrap Nboot no teste da dimensão.
% A matriz D e obtida sem usar limiarizacao nem nos funcionais estimados
% nem nos residuos usados nos testes bootstrap.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Results_DimEstWav.m
arquivo na pasta wavestrap_sem_limiar

% Arquivo para ler e analisar os dados simulados com o arquivo
% Sim_DimEstWav.m. Nesse codigo obtemos a proporcao que cada valor e
% estimado para diferentes tamanhos amostrais e dimensoes verdadeiras.
% Tambem sao feitos boxplots dos valores-p dos d-esimos e (d+1)-esimos
% autovalores quando a dimensao verdadeira e d.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DimEst_wavestrap.m
arquivo na pasta wavestrap_sem_limiar

% Nessa função é realizado o procedimento bootstrap para estimar a 
% dimensão do processo, mas diferentemente do que é feito em DimEst_boot.m,
% aqui aproveitamos as decomposições obtidas para realizar a reamostragem
% nos termos formados com os coeficientes, o que deixa o código mais rápido.
% A é a matriz de coeficientes de ondaletas dos funcionais observados, 
% nas colunas, para diferentes dias, nas linhas.
% NREP é o número de réplicas bootstrap. p é lag máximo.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sim_limiar_antes_DimEstWav.m
arquivo na pasta wavestrap_limiar_antes

% Estudo de simulação da dimensão do processo de séries temporais de curvas
% usando ondaletas. Nesse código é utilizada a função func_Sim_limiar_antes_DimEstWav e
% cálculos em paralelo. As dimensões utilizadas variam em d=2,4,6 e os
% tamanhos amostrais usados são n=100,300,600. Ao final da simulação temos
% um arquivo para cada dimensão, com os dados gerados para cada cada valor
% de n. A técnica utilizada foi ondaletas sem thresholding, aplicando o
% procedimento bootstrap de Bathia.
% A técnica utilizada foi ondaletas com thresholding nos funcionais 
% observados, aplicando depois o procedimento bootstrap de Bathia.
% Na simulaçao obtemos para cada replica os oito maiores autovalores
% gerados, valores-p obtidos, dimensoes estimadas
% os resultados sao armazenados nos arquivos file_Sim_limiar_antes_wavestrap_d2.mat,
% file_Sim_limiar_antes_wavestrap_d4.mat e file_Sim_limiar_antes_wavestrap_d6.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Results_limiar_antes.m
arquivo na pasta wavestrap_limiar_antes

% Arquivo para ler e analisar os dados simulados com o arquivo
% Sim_limiar_antes_DimEstWav.m. Nesse codigo obtemos a proporcao que cada valor e
% estimado para diferentes tamanhos amostrais e dimensoes verdadeiras.
% Tambem sao feitos boxplots dos valores-p dos d-esimos e (d+1)-esimos
% autovalores quando a dimensao verdadeira e d.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

func_Sim_limiar_antes_DimEstWav.m
arquivo na pasta wavestrap_limiar_antes

% Essa função é utilizada para simular a estimação da dimensão de uma série
% temporal de curvas seguindo como fizeram Bathia et al (2010). As entradas
% são o tamanho amostral (número de curvas observadas) n, a dimensão do
% processo d, o número de réplicas da simulação NREP, o número de réplicas
% bootstrap Nboot no teste da dimensão.
% A matriz D e obtida usando limiarizacao nos funcionais estimados antes de
% obter a matriz D para realizar os testes bootstrap.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sim_DimEstWav_thresh.m
arquivo na pasta wavestrap_thresh

% Estudo de simulação da dimensão do processo de séries temporais de curvas
% usando ondaletas. Nesse código é utilizada a função func_Sim_DimEstWav_thresh e
% cálculos em paralelo. As dimensões utilizadas variam em d=2,4,6 e os
% tamanhos amostrais usados são n=100,300,600. Ao final da simulação temos
% um arquivo para cada dimensão, com os dados gerados para cada cada valor
% de n. A técnica utilizada foi ondaletas sem thresholding, aplicando o
% procedimento bootstrap de Bathia.
% A técnica utilizada aplica thresholding em residuos para formar um residuo 
% diferente daquele proposto por Bathia. Na simulaçao obtemos para cada 
% replica os oito maiores autovalores gerados, valores-p obtidos, dimensoes
% estimadas.
% Os resultados sao armazenados nos arquivos file_Sim_wavestrap_thresh_d2.mat,
% file_Sim_wavestrap_thresh_d4.mat e file_Sim_wavestrap_thresh_d6.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

func_Sim_DimEstWav_thresh.m
arquivo na pasta wavestrap_thresh

% Essa função é utilizada para simular a estimação da dimensão de uma série
% temporal de curvas seguindo como fizeram Bathia et al (2010). As entradas
% são o tamanho amostral (número de curvas observadas) n, a dimensão do
% processo d, o número de réplicas da simulação NREP, o número de réplicas
% bootstrap Nboot no teste da dimensão.
% A matriz D e obtida usando um residuo formado depois de aplicar uma
% limiarizacao nas autofuncoes e na funcao media.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DimEst_wavestrap_thresh.m
arquivo na pasta wavestrap_thresh

% Nessa função é realizado o procedimento bootstrap para estimar a 
% dimensão do processo, as decomposições obtidas são aproveitadas na
% reamostragem, que teoricamente é feita sobre o resíduo obtido após ser 
% feita uma limiarização sobre os coeficientes das decomposições da média
% do processo e das autofunções.
% A é a matriz de coeficientes de ondaletas dos funcionais observados, 
% nas colunas, para diferentes dias, nas linhas.
% NREP é o número de réplicas bootstrap. p é lag máximo. 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Results_wavestrap_thresh.m
arquivo na pasta wavestrap_thresh

% Arquivo para ler e analisar os dados simulados com o arquivo
% Sim_DimEstWav_thresh.m. Nesse codigo obtemos a proporcao que cada valor e
% estimado para diferentes tamanhos amostrais e dimensoes verdadeiras.
% Tambem sao feitos boxplots dos valores-p dos d-esimos e (d+1)-esimos
% autovalores quando a dimensao verdadeira e d.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Sim_PSD2000.m
arquivo na pasta wavestrap_PSD2000

% Estudo de simulação da dimensão do processo de séries temporais de curvas
% usando ondaletas. Nesse código é utilizada a função func_Sim_PSD2000 e
% cálculos em paralelo. As dimensões utilizadas variam em d=2,4,6 e os
% tamanhos amostrais usados são n=100,300,600. Ao final da simulação temos
% um arquivo para cada dimensão, com os dados gerados para cada cada valor
% de n.
% A técnica utilizada foi ondaletas aplicando o bootstrap de Bathia com um
% residuo formado com a tecnica de wavestrap de Persival, Sardy e Davidson
% (2000).
% A técnica utilizada foi ondaletas com thresholding nos funcionais 
% observados, aplicando depois o procedimento bootstrap de Bathia.
% Na simulaçao obtemos para cada replica os oito maiores autovalores
% gerados, valores-p obtidos, dimensoes estimadas
% os resultados sao armazenados nos arquivos file_Sim_PSD2000_d2.mat,
% file_Sim_PSD2000_d4.mat e file_Sim_PSD2000_d6.mat

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

func_Sim_PSD2000.m
arquivo na pasta wavestrap_PSD2000

% Essa função é utilizada para simular a estimação da dimensão de uma série
% temporal de curvas seguindo como fizeram Bathia et al (2010). As entradas
% são o tamanho amostral (número de curvas observadas) n, a dimensão do
% processo d, o número de réplicas da simulação NREP, o número de réplicas
% bootstrap Nboot no teste da dimensão.
% A matriz D e obtida usando residuos bootstrap formados usando a tecnica
% de wavestrap de Persival, Sardy e Davidson (2000) nos seus coeficientes
% de ondaletas. Em seguida, tais residuos sao usados nos testes bootstrap.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

DimEst_wavestrap_PSD2000.m
arquivo na pasta wavestrap_PSD2000

% Nessa função é realizado o procedimento bootstrap para estimar a 
% dimensão do processo, de maneira similar ao que é feito em
% DimEst_wavestrap.m, mas utilizando também a técnica de wavestrap proposta
% por Persival, Sardy e Davidson (2000).
% A é a matriz de coeficientes de ondaletas dos funcionais observados, 
% nas colunas, para diferentes dias, nas linhas.
% NREP é o número de réplicas bootstrap. p é lag máximo. Lw é o vetor
% retornado pela função wavedec, contendo o número de coeficientes em cada
% nível da decomposição.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Results_PSD2000.m
arquivo na pasta wavestrap_PSD2000

% Arquivo para ler e analisar os dados simulados com o arquivo
% Sim_PSD2000.m. Nesse codigo obtemos a proporcao que cada valor e
% estimado para diferentes tamanhos amostrais e dimensoes verdadeiras.
% Tambem sao feitos boxplots dos valores-p dos d-esimos e (d+1)-esimos
% autovalores quando a dimensao verdadeira e d.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

