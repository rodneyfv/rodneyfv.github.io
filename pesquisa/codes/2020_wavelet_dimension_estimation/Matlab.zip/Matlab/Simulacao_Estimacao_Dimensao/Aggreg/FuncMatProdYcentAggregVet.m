function [ y ] = FuncMatProdYcentAggregVet( C, w, p, k)
% A função retorna uma matriz de dimensão (n-p-delta+1)x(n-p-delta+1) com o
% produto dos funcionais observados centrados pela média e armazenados em
% C e multiplicados pelos pesos no vetor w. Aqui, o produto e feito
% conforme deve ser feito no caso em que se utiliza agregaçao.
% O lag máximo do processo é dado em p e o lag usado com os
% funcionais ponderados são armazenados em k.

% tamanho da amostra n e numero nt de pontos usados na discretizaçao
[nt,n] = size(C);
% número de pesos no vetor w
delta = length(w);

% matriz para armazenar os delta blocos de delta funçoes consecutivas
% avaliadas nos nt pontos
mY = zeros(delta,delta,nt);
% matriz para armazenar as n-p-delta+1 funçoes da forma quadratica entre
% do vetor de pesos e os blocos de delta funçoes centradas.
mZ = zeros(n-p-delta+1,nt);
for jj = 1:(n-p-delta+1)
    % blocos de delta funçoes centradas
    for ii = 0:(delta-1)
        mY(ii+1,:,:) = C(:,(jj+k-ii):(jj+k+delta-1-ii))';
        %for ll=0:(delta-1)
        %    mY(ii+1,ll+1,:) = C(:,jj+k+ll-ii);
        %end
    end
    % bloco de delta funçoes centradas pre e pos-multiplicados pelo vetor
    % de pesos
    if delta==1
        mZ(jj,:) = (w^2)*mY(1,1,:);
    else
            for ii = 1:nt
                mZ(jj,ii) = w'*mY(:,:,ii)*w;
            end
    end
end

% matriz com produto interno das funçoes armazenadas em mZ. Para aproximar
% o produto interno da versao funcional basta multiplicar pela distancia de
% duas observaçoes consecutivas usadas na discretizaçao.
y = mZ*mZ';

end

