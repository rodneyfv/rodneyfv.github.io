
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%% Functions #############################
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


# Function to perform the dimension estimation of the log-returns densities

#   Inputs
# ret: a list whose elements are vectors with log-returns observed for different
# days
# n: is the sample size used to estimate the outputs. Hence, we analyse the
# log-returns of the first n elements of ret
# vSupp: common support considered for the observed densities
# m: number of points used in the discretization of the observed density
# p: see Bathia, Yao, Ziegelmann; page 5
# N: level used in the wavedec function
# wname: wavelet basis used in the decompositions. Needs the package wavelets
# to be used
# NREP: number of bootstrap replications
# alpha: significance level of the bootstrap test

#   Outputs
# mEstDens: estimated densities for each day in the columns
# dhat: estimated dimension of the densities
# vEstimMu: estimated mean function obtained from its wavelets coefficients
# mEigFunc: Eigenfunctions related to the dhat largest eigenvalues
# mLoadings: matrix whose vectors have loadings related to the dhat eigenfunctions above

func_WavDensDimEstim <- function( ret, n, vSupp, m, p, N, wname, NREP=100, alpha=0.05,
                                  dhat = NULL){
  # Initialization parameters
  # We use the common support vSupp for all estimated desities
  b = vSupp[2];
  a = vSupp[1];
  
  # Discretization and evaluation points
  # Discrete grid of points where the densities are evaluated
  vu = seq(a,b,length=m)
  # interval length
  du = vu[2] - vu[1]
  
  # Creating an (m x n) matrix which represents the observed densities. 
  # mY(j,t) is the density at date t evaluated at vu[j]
  mY = matrix(0,m,n)
  for(ii in 1:n){
    bwRT = 1.06*sd(ret[[ii]])*length(ret[[ii]])^(-1/5)
    mY[,ii] = func_RectDensEst( ret[[ii]], vu, 3*bwRT/2);
  }
  # (m x n) matrix with the square root of the observed densities. 
  mRootY = sqrt(mY);
  
  # number of coefficients for the the wavelet basis used (it changes with
  # for different values of m)
  J = m
  # RootYdec(j,t) has the j-th wavelet coefficient of the decomposition of
  # the t-th column vector of mRootY
  mRootYdec = matrix(0,J,n)
  
  # decomposition of each curve along the n days
  for(ii in 1:n){
    # Wavelet decomposition of the curves. We apply the same decomposition
    # for each day
    # Lw has the number of coefficients in decomposition level, and its
    # last element is the total number of wavelet coefficients
    
    # version without thresholding
    lWdec = fWavedec(mRootY[,ii],N,wname)
    #lWdec = fWavedec(mRootY[,ii],N,wname,thresh = 'hard')
    mRootYdec[,ii] = lWdec$vdec
    Lw = lWdec$vLw
  }
  
  # wavelet coefficients of the densities' mean curve
  mu_dec = apply(mRootYdec,1,mean)
  
  # Matrix with the centered wavelet coefficients
  mC = mRootYdec - mu_dec%*%matrix(1,1,n)
  
  # Computing the matrix used in the dimension esimation. 
  # It is obatined from products of the centered wavelet coefficients
  mC1 = mC[,1:(n-p)]
  mD1 = matrix(0,n-p,n-p)
  for(k in 1:p){
    mD1 = mD1 + t(mC[,(k+1):(n-p+k)])%*%mC[,(k+1):(n-p+k)]
  }
  mD = mC1%*%mD1%*%t(mC1)/((n-p)^2)
  
  # After obtaining mD, we compute its eigenvectors and eigenvalues.
  # The colums of mB are eigenvectors of mB, which are the wavelet
  # coefficiente of the eigenfunctions associated to the eigenvalues on the
  # diagonal entries of mL
  eigD = eigen(mD)
  mB = eigD$vectors
  mL = eigD$values
  
  # checking if some specific dimension might be used, otherwise a bootstrap
  # test will be perform to estimate the dimension of the process (default)
  if(is.null(dhat)){
    # Dimension estimation with bootstrap test
    d0 = 1 # dimension under the null hypothesis
    mPvalues = rep(1,10) # p-values of the largest eigenvalues
    
    while(d0<=10){
      d_boot = fDimEst_wavestrap( mRootYdec, NREP, mB[,1:d0], p);
      mPvalues[d0] = sum(d_boot>mL[d0+1])/NREP;
      if(mPvalues[d0]>alpha){
        vDimSel = d0;
        d0 = 10;
      }
      d0 = d0 + 1;
    }
    # estimated dimension
    dhat <- vDimSel
  }
  
  # Matrix with the loadings. mEta(t,j) has the loading of the j-th
  # eigenfunction and t-th day
  mEta = t(mC)%*%mB[,1:dhat]
  
  # matrix to store the wavelet coefficients of the estimated density square root
  mEstimRootYdec = matrix(0,J,n);
  # matrix to store the estimated density square root
  mEstimRootY = matrix(0,m,n)
  for(ii in 1:n){
    # wavelet coefficient of the estimated density square root of day ii
    mEstimRootYdec[,ii] = mu_dec
    
    for(jj in 1:dhat){
      mEstimRootYdec[,ii] = mEstimRootYdec[,ii] + mEta[ii,jj]*mB[,jj]
    }
    # squared L2-norm of the density square root
    NormConst = sum(mEstimRootYdec[,ii]^2)*du;
    # estimated density obtained from the re-scaled coefficients
    mEstimRootY[,ii] = fWaverec(mEstimRootYdec[,ii]/sqrt(NormConst),Lw,wname);
  }
  
  # checking if the integral of Y_t du is one
  mEstimY = mEstimRootY^2;
  # estimated mean function obtained from its wavelets coefficients after
  # re-scaling them in order to the density integrate one
  vEstimMu = fWaverec(mu_dec,Lw,wname)
  # Eigenfunctions related to the largest two eigenvalues
  # the function are obtained from their wavelet coefficients
  mEigFunc = matrix(0,m,dhat)
  for(ii in 1:dhat) mEigFunc[,ii] = fWaverec(mB[,ii],Lw,wname)
  
  
  return(list(mEstDens = mEstimY, vEstimMu = vEstimMu, mEigFunc = mEigFunc,
              mLoadings = mEta, dhat = dhat))
}

# rectangular kernel density estimation of Silverman
# (Density Estimation, p. 12). The argument vx ist the data whose density
# we want to estimate, vpts are the points to evaluate the estimated
# density and bw is the bandwidth used.
func_RectDensEst <- function( vx, vpts, bw ){
  
  # sample size
  n = length(vx);
  # number of points evaluated
  m = length(vpts);
  # vector to store the estimated density evaluated at vpts
  vDens = matrix(0,m,1);
  for(ii in 1:m){
    vDens[ii] = sum((vx<vpts[ii]+bw)*(vx>vpts[ii]-bw))/(2*bw*n)
  }
  return(vDens)
}


# Nessa função é realizado o procedimento bootstrap para estimar a 
# dimensão do processo, mas diferentemente do que é feito em DimEst_boot.m,
# aqui aproveitamos as decomposições obtidas para realizar a reamostragem
# nos termos formados com os coeficientes, o que deixa o código mais rápido.
# A é a matriz de coeficientes de ondaletas dos funcionais observados, 
# nas colunas, para diferentes dias, nas linhas.
# NREP é o número de réplicas bootstrap. p é lag máximo. 
fDimEst_wavestrap = function( A, NREP, B, p){
J = dim(as.matrix(B))[1];
d0 = dim(as.matrix(B))[2];
n = dim(as.matrix(A))[2];
vd0p1_boot = matrix(0,NREP,1);
Aboot = matrix(0,J,n);

mu_A = apply(A,1,mean);
C = A - mu_A%*%matrix(1,1,n)
# matriz de etas (as v.a.) para cada autofunção, nas colunas, para
# diferentes dias, nas linhas
mEta = t(C)%*%B;

for(jj in 1:NREP){
  # obtendo diretamente os coeficientes do funcional observado bootstrap
  for(ii in 1:n){
    ts = ceiling(n*runif(1));
    Aboot[,ii] = A[,ts] + B%*%as.matrix(mEta[ii,] - mEta[ts,])
  }
  
  mu_Aboot = apply(Aboot,1,mean);
  C = Aboot - mu_Aboot%*%matrix(1,1,n);
  
  C1 = C[,1:(n-p)];
  D1 = matrix(0,n-p,n-p);
  for(k in 1:p){
    D1 = D1 + t(C[,(k+1):(n-p+k)])%*%C[,(k+1):(n-p+k)];
  }
  Dboot = C1%*%D1%*%t(C1)/((n-p)^2);
  
  Lboot = eigen(Dboot)$values;
  vd0p1_boot[jj] = Lboot[d0+1];
}
return(vd0p1_boot)
}


# function to perform discrete wavelet decomposition
# Inputs
# vx: vector of data to decompose. It must have a length power of 2.
# N: number of levels of the decomposition
# dfilter: wavelet filter used, obtained from the wt.filter function of the
# wavelets package
# Outputs
# vdec: wavelet decomposition vector, starting with the first detail
# coefficients and ending with the approximation coefficients
# vLw: vector with the number of coefficients in each decomposition level
fWavedec <- function(vx,N,dfilter,thresh='none'){
  # list to keep the one-level wavelet decompositions obtained from the
  # dwt.forward function of the waavelets packages
  ldec <- list()
  # vector to store the wavelet decomposition coefficients
  vdec <- rep(0,length(vx))
  # vector to keep the number of coefficients in each decomposition level
  vLw <- rep(0,N+2)
  vLw[N+2] <- length(vx)
  # getting the first detail and approximation coefficients
  ldec[[1]] <- dwt.forward(vx,dfilter)
  vLw[1] <- length(ldec[[1]]$W)
  vdec[1:vLw[1]] <- ldec[[1]]$W
  # getting the approximation coefficients of other levels
  for(i in 2:N){
    # here we perform a decomposition of the approximation coefficients of
    # the subsequent level to obtain the coefficients of the current level
    ldec[[i]] <- dwt.forward(ldec[[i-1]]$V,dfilter)
    vLw[i] <- length(ldec[[i]]$W)
    vdec[(sum(vLw[1:(i-1)])+1):sum(vLw[1:i])] <- ldec[[i]]$W
  }
  # getting the last approximation coefficients vecotr and storing its
  # length in the last element of vLw
  vLw[N+1] <- length(ldec[[N]]$V)
  vdec[(sum(vLw[1:N])+1):sum(vLw[1:(N+1)])] <- ldec[[N]]$V
  
  if(thresh=='hard'){
    lambUni = sqrt(2*log(length(vx)))*mad(ldec[[1]]$W)
    vd <- vdec[1:sum(vLw[1:N])]
    vdec[1:sum(vLw[1:N])] <- vd*(abs(vd)>lambUni)
  }else{
    if(thresh=='soft'){
      lambUni = sqrt(2*log(length(vx)))*mad(ldec[[1]]$W)
      vd <- vdec[1:sum(vLw[1:N])]
      vdec[1:sum(vLw[1:N])] <- (vd - sign(vd)*lambUni)*(abs(vd)>lambUni)
    }
  }
  return(list(vdec=vdec, vLw=vLw))
}


# function to perform reconstruction discrete wavelet coefficients
# Inputs
# vdec: wavelet and approximation coefficients obtained from the fWavedec function
# vLw: number of coefficients in each decomposition level
# dfilter: wavelet filter used, obtained from the wt.filter function of the
# wavelets package
# Outputs
# vrec: reconstructed vector out of the wavelet coefficients
fWaverec <- function(vdec,vLw,dfilter){
# number of levels of the decomposition
N <- length(vLw) - 2
# vector to store the reconstructed signal
vrec <- rep(0,vLw[N+2])
# getting the approximation coefficients from decomposition level N-1
vrec <- dwt.backward(vdec[(sum(vLw[1:(N-1)])+1):sum(vLw[1:N])],
vdec[(sum(vLw[1:N])+1):sum(vLw[1:(N+1)])],dfilter)
for(i in 2:N){
# here we get the approximation coefficients from subsequent decomposition
# levels, and in the last round of the loop the reconstructed signal is
# returned to vrec
vrec <- dwt.backward(vdec[(sum(head(vLw,(N-i)))+1):sum(vLw[1:(N-i+1)])],
vrec,dfilter)
}

return(vrec)
}

