
###########################
## LOAD THE FUNCTIONS IN THE PART BELLOW OF THIS CODE
###########################

require(wavelets)
source('source_WaveletReturnData.r')

# Importing the data
data = read.table("data.csv",header=TRUE,sep=";")

# Configuring date/time format
data$Time = as.POSIXct(paste(data$Data, data$Hora), format="%d/%m/%Y %H:%M")

# Creating the list 'prices'; prices[[t]](j) is the j-th price on day t
prices = split(data[, c('Time','Fech')], format(data$Time, format = "%Y%m%d"))
# Sample size
n = length(prices)

# Creating the list 'returns'; returns[[t]](j) is the j-th return on day t
# 5-minute returns
ret = lapply(1:n,
             function(t) {m = length(prices[[t]]$Fech);
             sapply(1:(m-1), function(j) log(prices[[t]]$Fech[j+1]) - log(prices[[t]]$Fech[j]))})

vNt = rep(0,305)
for(i in 1:305){
  vNt[i] = length(ret[[i]])
}

# We use the common support [a,b]=[-b,b] for all estimated desities
b = .06;
a = -b;

# Discretization
# Evaluation points
m = 2^10 # number of grid points
# Discrete grid of points where the densities are evaluated
vu = seq(a,b,length=m)
# interval length
du = vu[2] - vu[1]

t = 1
# Silverman's rule of thumb bandwidth for day t (Density Estimation, p.45)
bwRT = 1.06*sd(ret[[t]])*length(ret[[t]])^(-1/5)
# estimated density of day t using a Gaussian kernel
vKernDens <- density(ret[[t]], bw = bwRT, kernel = 'gaussian', from = a, to = b, n = m)$y
plot(vu,vKernDens, type = 'l', xlim = c(-.0075,.0075))
# estimated density of day t using a rectangular kernel
vRectDens = func_RectDensEst( ret[[t]], vu, 3*bwRT/2)
lines(vu,vRectDens, type = 'l', xlim = c(-.0075,.0075),col=2)


# Creating an (m x n) matrix which represents the observed densities. 
# mY(j,t) is the density at date t evaluated at vu[j]
mY = matrix(0,m,305)
for(ii in 1:305){
  bwRT = 1.06*sd(ret[[ii]])*length(ret[[ii]])^(-1/5)
  #mY[,ii] = func_RectDensEst( ret[[ii]], vu, 3*bwRT/2)
  mY[,ii] = density(ret[[ii]], bw = bwRT, kernel = 'gaussian', from = a, to = b, n = m)$y
}
# (m x n) matrix with the square root of the observed densities. 
mRootY = sqrt(mY);


p = 6;  # [See Bathia, Yao, Ziegelmann; page 5)
N = 6;  # level used in the fWavedec function
#require(wavelets)
wname <- wt.filter(filter="d8", modwt=FALSE, level=1)
# number of coefficients for the the wavelet basis used (it changes with
# for different values of m)
J = m
# RootYdec(j,t) has the j-th wavelet coefficient of the decomposition of
# the t-th column vector of mRootY
mRootYdec = matrix(0,J,n)

# decomposition of each curve along the n days
for(ii in 1:n){
  # Wavelet decomposition of the curves. We apply the same decomposition
  # for each day
  # Lw has the number of coefficients in decomposition level, and its
  # last element is the total number of wavelet coefficients
  
  # version without thresholding
  lWdec = fWavedec(mRootY[,ii],N,wname)
  #lWdec = fWavedec(mRootY[,ii],N,wname,thresh = 'hard')
  mRootYdec[,ii] = lWdec$vdec
  Lw = lWdec$vLw
}

# wavelet coefficients of the densities' mean curve
mu_dec = apply(mRootYdec,1,mean)

# Matrix with the centered wavelet coefficients
mC = mRootYdec - mu_dec%*%matrix(1,1,n)

# Computing the matrix used in the dimension esimation. 
# It is obatined from products of the centered wavelet coefficients
mC1 = mC[,1:(n-p)]
mD1 = matrix(0,n-p,n-p)
for(k in 1:p){
  mD1 = mD1 + t(mC[,(k+1):(n-p+k)])%*%mC[,(k+1):(n-p+k)]
}
mD = mC1%*%mD1%*%t(mC1)/((n-p)^2)

# After obtaining mD, we compute its eigenvectors and eigenvalues.
# The colums of mB are eigenvectors of mB, which are the wavelet
# coefficiente of the eigenfunctions associated to the eigenvalues on the
# diagonal entries of mL
eigD = eigen(mD)
mB = eigD$vectors
mL = eigD$values

plot(mL[1:10])
mL[1:10]

# Dimension estimation with bootstrap test
NREP = 100 # number of bootstrap replications
alpha = .05 # significance level of the bootstrap test
d0 = 1 # dimension under the null hypothesis. Starts at d0=1.
d0_max = 8
mPvalues = rep(1,8) # p-values of the largest eigenvalues
set.seed(2018)

while(d0 < d0_max){
  d_boot = fDimEst_wavestrap( mRootYdec, NREP, mB[,1:d0], p);
  mPvalues[d0] = sum(d_boot>mL[d0+1])/NREP;
  if(mPvalues[d0]>alpha){
    vDimSel = d0;
    d0 = 8;
  }
  d0 = d0 + 1;
}

vDimSel
mPvalues

# estimated mean function obtained from its wavelets coefficients
vEstimMu = fWaverec(mu_dec,Lw,wname)
plot(vu,vEstimMu, type = 'l', xlim = c(-.0075,.0075),col=2,
     ylab=expression(mu(x)),xlab='x')

# Eigenfunctions related to the largest two eigenvalues
# the function are obtained from their wavelet coefficients on the columns
# of mB
vEigFunc1RootY = fWaverec(mB[,1],Lw,wname)
vEigFunc2RootY = fWaverec(mB[,2],Lw,wname)
plot(vu,vEigFunc1RootY, type = 'l')
plot(vu,vEigFunc2RootY, type = 'l')

# plot of the mean function and the eigenfunctions above
# eigenfunctions are multiplied by 100 for better visualization
plot(vu,vEstimMu, type = 'l', xlim = c(-.0075,.0075),col=1, ylim=c(-20, 20))
lines(vu,100*vEigFunc1RootY, type = 'l', col=2)
lines(vu,100*vEigFunc2RootY, type = 'l', col=3)


# Matrix with the loadings. mEta(t,j) has the loading of the j-th
# eigenfunction and t-th day
mEta = t(mC)%*%mB
# Estimated loadings related to the two largest eigenvalues
plot(1:60,mEta[1:60,1], type = 'l')
plot(1:60,mEta[1:60,2], type = 'l')


# Ljung-Box test of the first three loading vectors. If the first output is
# 0 we do not reject the null that loadings are not autocorrelated, and we
# reject the null if it is 1
Box.test(mEta[,1])
Box.test(mEta[,2])
Box.test(mEta[,3])


# estimated density square root using a two-dimensional process
mEstimRootY = matrix(0,m,n)
for(ii in 1:n){
  mEstimRootY[,ii] = vEstimMu + mEta[ii,1]*vEigFunc1RootY + mEta[ii,2]*vEigFunc2RootY;
}
# estimated density
vEstimY = mEstimRootY^2
# checking if the integral of Y_t du is one
sum(vEstimY[,1]*du)  # does not integrate one yet


# matrix to store the wavelet coefficients of the estimated density square root
mEstimRootYdec = matrix(0,J,n);
# matrix to store the estimated density square root
mEstimRootY = matrix(0,m,n);
for(ii in 1:n){
  # waavelet coefficient of the estimated density square root of day ii
  mEstimRootYdec[,ii] = mu_dec + mEta[ii,1]*mB[,1] + mEta[ii,2]*mB[,2];
  # squared L2-norm of the density square root
  NormConst = sum(mEstimRootYdec[,ii]^2)*du;
  
  # re-scaling the coefficients so that L2-norm of the density square
  # root becomes one, i.e., the estimated density integrates one
  #mEstimRootYdec(:,ii) = mEstimRootYdec(:,ii)/sqrt(NormConst);
  mu_dec = mu_dec/sqrt(NormConst)
  mEig1_dec = mB[,1]/sqrt(NormConst);
  mEig2_dec = mB[,2]/sqrt(NormConst);
  mEstimRootYdec[,ii] = mu_dec + mEta[ii,1]*mEig1_dec + mEta[ii,2]*mEig2_dec;
  # estimated density obtained from the re-scaled coefficients
  mEstimRootY[,ii] = fWaverec(mEstimRootYdec[,ii],Lw,wname);
}

# checking if the integral of Y_t du is one
mEstimY = mEstimRootY^2;
sum(mEstimY[,1]*du)

# estimated mean function obtained from its wavelets coefficients after
# re-scaling them in order to the density integrate one
vEstimMu = fWaverec(mu_dec,Lw,wname);

# Eigenfunctions related to the largest two eigenvalues
# the function are obtained from their wavelet coefficients after
# re-scaling them  in order to the density integrate one
vEigFunc1RootY = fWaverec(mEig1_dec,Lw,wname);
vEigFunc2RootY = fWaverec(mEig2_dec,Lw,wname);
plot(vu,vEigFunc1RootY,type = 'l')
plot(vu,vEigFunc2RootY,type = 'l')

par(mfrow=c(2,1), mar=c(5,5,1,1))
plot(vu,vEstimMu,xlim=c(-.02,.02),type='l',ylab=expression(mu(x)),xlab='x',lwd=2)
plot(vu,vEigFunc1RootY, type = 'l',
     ylab='',xlab='x',xlim=c(-.03,.03),ylim=c(-.2,.2),lwd=2)
lines(vu,vEigFunc2RootY, type = 'l',lwd=2,col=2)
legend('topright',c(expression(h[1](x)),expression(h[2](x))),fill=c(1,2),bty='n')


# Plot of some estimated densities
par(mfrow=c(2,2), mar=c(5,5,1,1))
plot(vu,mY[,1],main='t=1', type = 'l', xlim = c(-.0075,.0075))
lines(vu,mEstimY[,1], type = 'l', xlim = c(-.0075,.0075),lty=2)
plot(vu,mY[,2],main='t=2', type = 'l', xlim = c(-.0075,.0075))
lines(vu,mEstimY[,2], type = 'l', xlim = c(-.0075,.0075),lty=2)
plot(vu,mY[,3],main='t=3', type = 'l', xlim = c(-.0075,.0075))
lines(vu,mEstimY[,3], type = 'l', xlim = c(-.0075,.0075),lty=2)
plot(vu,mY[,4],main='t=4', type = 'l', xlim = c(-.0075,.0075))
lines(vu,mEstimY[,4], type = 'l', xlim = c(-.0075,.0075),lty=2)

par(mfrow=c(2,1), mar=c(5,5,1,1))
plot(vu,mY[,1],main='t=1', type = 'l', xlim = c(-.005,.005),
     ylab='',xlab='',lwd=1.5)
lines(vu,mEstimY[,1], type = 'l', xlim = c(-.005,.005),col=2,lwd=1.5)
plot(vu,mY[,2],main='t=2', type = 'l', xlim = c(-.005,.005),
     ylab='',xlab='',lwd=1.5)
lines(vu,mEstimY[,2], type = 'l', xlim = c(-.005,.005),col=2,lwd=1.5)


