# Neste programa ser�o considerados alguns valores de par�metros
# para simular dados para testa o modelo de regress�o BSR bayesiano,
# utilizando diferentes priores para os par�metros.
# Os modelos ajustados ser�o comparados atrav�s do LPML e do pseudo
# valor de bayes
# 


require(ssym)
require(fBasics)
require(coda)
require(MASS)
require(R2OpenBUGS)

# Enable Just In Time compilation in R
R_COMPILE_PKGS=TRUE
R_ENABLE_JIT=3
library(compiler)
enableJIT(3) 


setwd('C:/Users/Rodney/Desktop/biaxial - An�lise/diag-perform')
source("Comandos BSR.R")


#####################################################

set.seed(2015)
# Par�metros verdadeiros
beta0 = -.5; beta1 = -1.7
delta = 5;
x = runif(50)	# covari�vel

# gerando a amostra
mu = exp(beta0 + beta1*x)
truehist(mu)
y = sapply(mu,function(m,d)rRBS(1,m,delta))
ind.pert = sample.int(50,1)

x[ind.pert] = runif(1,4,5)


################################################################
################################################################
# Modelo BSR cl�ssico

mod.class = regRBS(y,x,n.it=100)
mod.class$beta
mod.class$delta

B = t(mod.class$Mat.Pert)%*%ginv((-1)*mod.class$Mat.Hes)%*%mod.class$Mat.Pert
# Ci vs. �ndice - Escobar e Meeker(1992)
Ci = 2*abs(diag(B))
plot(1:length(y),Ci,ylim=c(0,3),type="h",
ylab=expression(paste(d[max])),xlab="Valores Ordenados")
abline(h=2*mean(Ci),lty=3)
Ci[ind.pert]>2*mean(Ci)



################################################################
################################################################
# Modelo BSR bayesiano

# Observa��es
N = length(y)
data = list("N","x","y")
# palpites iniciais
beta_init = mod.class$beta
delta_init = mod.class$delta

# par�metros do modelo
parameters = c("beta","delta","tau")

###################
# Modelo 2 com priori Normal para beta com priori gama para a precis�o

# valores iniciais no modelo com priori gama para precis�o
inits = list(list(delta = delta_init,beta = beta_init, tau = 1))
# par�metros do modelo
parameters = c("beta","delta","tau")
i = Sys.time()
# Modelo no OpenBUGs
mod.bayes = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS2.odc", n.chains = 1, n.iter = 3000,n.thin=2,
	n.burnin = 300)
f = Sys.time()
f-i
# Resultados
round(mod.bayes$summary[,c(1,2,3,5,7)],4)
p2 = dim(mod.bayes$sims.matrix)[2] - 2		# n�mero de par�metros

diag2 = BayesDiagBSR(mod.bayes$sims.matrix[,1:p2],y,x)
mcmc_m2 = mcmc(mod.bayes$sims.matrix[,1:(p2+1)])
par(mfrow=c(3,2)); traceplot(mcmc_m2)
autocorr.plot(mcmc_m2)

# Kullback-Leibler divergence
x11()
plot(1:N, diag2$kl.divergence, type = "h", xlab = "�ndice da observa��o", ylab = "K-L")
abline(h=.14,lty=3)
identify(1:N,diag.modbayes3$kl.divergence,n=6)



################################

NP = 5 # n�mero de observa��es modificadas

class.count = rep(0,5)
bayes.count = rep(0,5)

i.time = Sys.time()
for(i in 1:5){
x = runif(50)	# covari�vel
mu = exp(beta0 + beta1*x)	# gerando as m�dias
y = sapply(mu,function(m,d)rRBS(1,m,delta))	# gerando a amostra
ind.pert = sample.int(50,NP)	# sorteando obs. para modificar

x[ind.pert] = runif(NP,4,5)

mod.class = regRBS_influence(y,x,n.it=100)	#ajustando o modelo

# Ci vs. �ndice - Escobar e Meeker(1992)
B = t(mod.class$Mat.Pert)%*%ginv((-1)*mod.class$Mat.Hes)%*%mod.class$Mat.Pert
Ci = 2*abs(diag(B))
# Checando se os pontos modificados s�o detectados como influentes
class.count[i] = sum( Ci[ind.pert]>2*mean(Ci) )

# valores iniciais no modelo com priori gama para precis�o
inits = list(list(delta = mod.class$delta,beta = mod.class$beta, tau = 1))
# Modelo no OpenBUGs
mod.bayes = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS2.odc", n.chains = 1, n.iter = 3000,n.thin=2,
	n.burnin = 300)
diag2 = BayesDiagBSR_influence(mod.bayes$sims.matrix[,1:3],y,x)
bayes.count[i] = sum( diag2$kl.divergence[ind.pert] > .14 ) 

}
f.time = Sys.time()
f.time - i.time

mean(class.count)/NP
mean(bayes.count)/NP







###########################################################################
# Modelos de regress�o Birnbaum-Saunders pr�prio para an�lise de influ�ncia

regRBS_influence = function(y,Xev,n.it=20){

# Fun��o de liga��o logar�tmica
 g = function(x) log(x); dg = function(x) 1/x; gi = function(x) exp(x); d2g = function(x) -1/(x^2)
# Valores iniciais para beta
beta = lm(g(y)~Xev)$coef
# Valores iniciais para delta
delta = mleRBS(y)$delta
# Vetor de par�metros
theta = c(beta, delta)
# Matriz de modelo
X = cbind(rep(1,dim(as.matrix(Xev))[1]),as.matrix(Xev))
# Matriz de modelo aumentada
Xt = rbind(
cbind(X,rep(0,dim(X)[1])),
cbind(t(rep(0,dim(X)[2])),1)
)


# Itere��o de estima��o
for(i in 1:n.it){

# Vetor da m�dia
mu = gi(X%*%beta)

###############
z = -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1))
###############
b = delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2)
Db = diag(as.vector(b))
###############
a = 1/dg(mu)
Da = diag(as.vector(a))
###############
RIdt = sapply(mu, function(x) Idt(x,delta))
###############
v = delta/(2*(mu*dg(mu))^2) + (RIdt*delta^2)/(((delta+1)*dg(mu))^2)
Dv = diag(as.vector(v))
###############
s = 1/(2*mu*(delta+1)) + delta*mu*RIdt/(delta+1)^3
###############
u = (delta^2 + 3*delta + 1)/(2*(delta*(delta+1))^2) + (mu^2)*RIdt/(delta+1)^4
Du = diag(as.vector(u))
###############
Dab = rbind(
  cbind(Da,rep(0,dim(Da)[2])),
  cbind(t(rep(0,dim(Da)[1])),sum(diag(Db)))
)

# Matriz de pesos aumentada
W = rbind(
  cbind(Dv, Da%*%s),
  cbind(t(s)%*%Da, sum(diag(Du)))
)

###### Estima��o

# Vari�vel dependente
Z = Xt%*%theta + ginv(W)%*%Dab%*%rbind(z,1)
theta.n = ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%W%*%Z

# theta.n = theta + ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%Dab%*%rbind(z,1)
beta = theta.n[1:length(theta)-1]
delta = theta.n[length(theta)]
if(sum(abs((theta-theta.n)/theta))<.00001){break}
theta = theta.n 

}

###############
dmu2 = (1/(2*mu^2) - (delta^2)/(delta*y+y+delta*mu)^2 - y*(delta+1)/(2*mu^3))
cv = dmu2*(a^2) + z*a
Dc = diag(as.vector(cv))
###############
m = y/(delta*y+y+delta*mu)^2 + y/(4*mu^2) - delta*(delta+2)/(4*y*(delta+1)^2)
###############
d = 1/(2*(delta+1)^2) - ((y+mu)^2)/(delta*y+y+delta*mu)^2 - mu/(2*y*(delta+1)^3)
Dd = diag(as.vector(d))

# Matriz hessiana
L = rbind(
  cbind(t(X)%*%Dc%*%X, t(X)%*%Da%*%m),
  cbind(t(m)%*%Da%*%X, sum(diag(Dd)))
)


# Matriz de pertuba��o (pondera��o de casos)
Mat.Pert = rbind(
  t(X)%*%Da%*%diag(as.vector(z)),
  t(b)
)

return(list(beta = beta,delta = delta, Mat.Pert = Mat.Pert, Mat.Hes = L))

}

###############################################################################
###############################################################################
# Diagn�stico bayesiano pr�prio para o MRBS para an�lise de influ�ncia

# Fun��o para calcular a m�dia estimada
mu.estim = function(beta,x) exp(beta%*%x)
# Fun��o para calcular a rec�proca da densidade
recip.dens = function(x,m,d) 1/dRBS(x,m,d)

# A fun��o tem como argumentos uma matriz contendo as amostras de MCMC
# dos par�metros, um vetor da va repostas e um vetor da va explicativa

BayesDiagBSR_influence = function(mPar, y, x){
p = dim(mPar)[2]		# n�mero de par�metros
#matriz para guardar inversos das probabilidades
sim.inv = matrix(NA,dim(mPar)[1],N)	
# X = cbind(rep(1,dim(x)[1]),x)		#matriz de modelo
X = cbind(rep(1,length(x)),x)		#matriz de modelo quando x � vetor
n = length(y)		#tamanho da amostra
for(j in 1:n){
	mu.est = mu.estim(mPar[,1:(p-1)],X[j,])
	sim.inv[,j] = mapply(recip.dens,
	y[j],mu.est,mPar[,p])
}
cpo = 1/apply(sim.inv, 2, mean)
kl.divergence = -log(cpo) + colMeans(log(1/sim.inv))
return(list(kl.divergence=kl.divergence))
}




