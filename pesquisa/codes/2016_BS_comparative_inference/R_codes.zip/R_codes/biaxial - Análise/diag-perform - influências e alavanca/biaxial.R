require(ssym)
require(fBasics)
require(coda)
require(MASS)
require(R2OpenBUGS)

# Enable Just In Time compilation in R
R_COMPILE_PKGS=TRUE
R_ENABLE_JIT=3
library(compiler)
enableJIT(3) 

setwd('C:/Users/Rodney/Desktop/biaxial - An�lise/diag-perform2')
source("Comandos BSR.R")


#####################################################

# Par�metros verdadeiros
beta0 = -.5; beta1 = -1.7
delta = 5;

################################################################
# Dados para a simula��o

set.seed(2015)	# definindo a semente
N = 150	# tamanho da amostra
NP = 1 # n�mero de observa��es modificadas
NREP = 5 # n�mero de r�plicas
cfail = 0	# contador de n�o-converg�ncias do modelo cl�ssico

# matrizes para guardar os valores obtidos nas an�lises de influ�ncia
ind.pert = matrix(0,NREP,NP)
mKL = matrix(0,NREP,N)
mCi.p = matrix(0,NREP,N)
mCi.r = matrix(0,NREP,N)
mCi.c = matrix(0,NREP,N)
mGL = matrix(0,NREP,N)

# dados para o modelo bayesiano
data = list("N","x","y")	
parameters = c("beta","delta","tau")	# par�metros do modelo
x0 = runif(N)	# covari�vel
sigma5_x0 = 5*sd(x0)
mu = exp(beta0 + beta1*x0)	# gerando as m�dias
gl.cut = 2*3/N		# ponto de corte na alavanca

#contadores da detec��o de pontos influentes ou de alavanca
mCount = matrix(0,NREP,5)	

i=1
i.time = Sys.time()
for(i in 1:NREP){
y = sapply(mu,function(m,d)rRBS(1,m,delta))	# gerando a amostra
ind.pert[i,] = sample.int(50,NP)	# sorteando obs. para modificar
x = x0
x[ind.pert[i,]] = x[ind.pert[i,]] + sigma5_x0
# y[ind.pert[i,]] = y[ind.pert[i,]] + 5*sd(y)

# Modelo BSR cl�ssico
mod.class = regRBS_influence(y,x)	#ajustando o modelo
if(mod.class$conv == 0){i=i-1; cfail=cfail+1; next;}
Li = ginv((-1)*mod.class$Mat.Hes)	# matriz hessiana

# Ci vs. �ndice - Escobar e Meeker(1992)

# Pondera��o de casos
B = t(mod.class$Delta.ponder)%*%Li%*%mod.class$Delta.ponder
mCi.p[i,] = 2*abs(diag(B))
# Checando se os pontos modificados s�o detectados como influentes
mCount[i,1] = sum( mCi.p[i,ind.pert[i,]]>2*mean(mCi.p[i,]) )

# Perturba��o na vari�vel resposta
B = t(mod.class$Delta.resp)%*%Li%*%mod.class$Delta.resp
mCi.r[i,] = 2*abs(diag(B))
# Checando se os pontos modificados s�o detectados como influentes
mCount[i,2] = sum( mCi.r[i,ind.pert[i,]]>2*mean(mCi.r[i,]) )

# Perturba��o na vari�vel explicativa
B = t(mod.class$Delta.covariavel)%*%Li%*%mod.class$Delta.covariavel
mCi.c[i,] = 2*abs(diag(B))
# Checando se os pontos modificados s�o detectados como influentes
mCount[i,3] = sum( mCi.c[i,ind.pert[i,]]>2*mean(mCi.c[i,]) )

# Alavanca Generalizada usando 2*p/N como ponto de corte
mGL[i,] = diag(mod.class$GL)
mCount[i,4] = sum(mGL[i,ind.pert[i,]] > gl.cut)

# Modelo BSR bayesiano
# valores iniciais no modelo com priori gama para precis�o
inits = list(list(delta = mod.class$delta,beta = mod.class$beta, tau = 1))
# Modelo no OpenBUGs
mod.bayes = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS2.odc", n.chains = 1, n.iter = 3000,n.thin=2,
	n.burnin = 300)
# mcmc_m2 = mcmc(mod.bayes$sims.matrix[,1:4])
# par(mfrow=c(3,2)); traceplot(mcmc_m2)
# autocorr.plot(mcmc_m2)

mKL[i,] = BayesDiagBSR_influence(mod.bayes$sims.matrix[,1:3],y,x)$kl.divergence
mCount[i,5] = sum( mKL[i,ind.pert[i,]] > .14 )

}
f.time = Sys.time()
f.time - i.time

# taxas de detec��es corretas
colMeans(mCount)/NP
cfail

write.table(ind.pert,file="indpert-NP 3-x.txt",row.names=FALSE,col.names=FALSE)
write.table(mCi.p,file="mCi-pond-NP 3-x.txt",row.names=FALSE,col.names=FALSE)
write.table(mCi.r,file="mCi-resp-NP 3-x.txt",row.names=FALSE,col.names=FALSE)
write.table(mCi.c,file="mCi-cov-NP 3-x.txt",row.names=FALSE,col.names=FALSE)
write.table(mGL,file="mGL-NP 3-x.txt",row.names=FALSE,col.names=FALSE)
write.table(mKL,file="mKL-NP 3-x.txt",row.names=FALSE,col.names=FALSE)


###########################################################################
###########################################################################
# As seguintes fun��es foram modificadas para otimizar a simula��o
# calculando apenas quantidades usadas na an�lise de influ�ncia

###########################################################################
# Modelos de regress�o Birnbaum-Saunders pr�prio para an�lise de influ�ncia

regRBS_influence = function(y,Xev,n.it=1000,influence_x=1){

# Fun��o de liga��o logar�tmica
 g = function(x) log(x); dg = function(x) 1/x; gi = function(x) exp(x); d2g = function(x) -1/(x^2)
# Valores iniciais para beta
beta = lm(g(y)~Xev)$coef
# Valores iniciais para delta
delta = mleRBS(y)$delta
# Vetor de par�metros
theta = c(beta, delta)
# Matriz de modelo
X = cbind(rep(1,dim(as.matrix(Xev))[1]),as.matrix(Xev))
# N�mero de par�metros dos regressores do modelo
p = length(beta)
# Tamanho da amostra
n = length(y)
# Matriz de modelo aumentada
Xt = rbind(
cbind(X,rep(0,dim(X)[1])),
cbind(t(rep(0,dim(X)[2])),1)
)


# Itere��o de estima��o
for(i in 1:n.it){

# Vetor da m�dia
mu = gi(X%*%beta)

###############
z = -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1))
###############
b = delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2)
Db = diag(as.vector(b))
###############
a = 1/dg(mu)
Da = diag(as.vector(a))
###############
RIdt = sapply(mu, function(x) Idt(x,delta))
###############
v = delta/(2*(mu*dg(mu))^2) + (RIdt*delta^2)/(((delta+1)*dg(mu))^2)
Dv = diag(as.vector(v))
###############
s = 1/(2*mu*(delta+1)) + delta*mu*RIdt/(delta+1)^3
###############
u = (delta^2 + 3*delta + 1)/(2*(delta*(delta+1))^2) + (mu^2)*RIdt/(delta+1)^4
Du = diag(as.vector(u))
###############
Dab = rbind(
  cbind(Da,rep(0,dim(Da)[2])),
  cbind(t(rep(0,dim(Da)[1])),sum(diag(Db)))
)

# Matriz de pesos aumentada
W = rbind(
  cbind(Dv, Da%*%s),
  cbind(t(s)%*%Da, sum(diag(Du)))
)

###### Estima��o

# Vari�vel dependente
Z = Xt%*%theta + ginv(W)%*%Dab%*%rbind(z,1)
theta.n = ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%W%*%Z

# theta.n = theta + ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%Dab%*%rbind(z,1)
beta = theta.n[1:p]
delta = theta.n[p+1]
if(sum(abs((theta-theta.n)/theta))<.00001){break}
theta = theta.n 

}

if(i>=n.it){
return(list(conv=0))
}

###############
# Atualizando algumas quantidades
beta = theta[1:p]
delta = theta[p+1]
mu = gi(X%*%beta)
a = 1/dg(mu)
Da = diag(as.vector(a))

delta1 = delta + 1
delta2 = delta + 2
y_delta_mu = delta*y+y+delta*mu

###############
dmu2 = (1/(2*mu^2) - (delta^2)/y_delta_mu^2 - y*(delta1)/(2*mu^3))
cv = dmu2*(a^2) + z*a
Dc = diag(as.vector(cv))
###############
m = y/y_delta_mu^2 + y/(4*mu^2) - delta*(delta2)/(4*y*(delta1)^2)
###############
d = 1/(2*(delta1)^2) - ((y+mu)^2)/y_delta_mu^2 - mu/(2*y*(delta1)^3)
Dd = diag(as.vector(d))

###############
# Matriz hessiana
L = rbind(
  cbind(t(X)%*%Dc%*%X, t(X)%*%Da%*%m),
  cbind(t(m)%*%Da%*%X, sum(diag(Dd)))
)

###############
# Matriz de pertuba��o (pondera��o de casos)
Delta.ponder = rbind(
  t(X)%*%Da%*%diag(as.vector(z)),
  t(b)
)

###############
# Matriz de pertuba��o (perturba��o na vari�vel resposta)
psi = -delta*delta1/y_delta_mu^2 + .25*delta1/(mu^2) + 
	.25*(delta^2)/(delta1*y^2)
vartheta = mu*sqrt(2*delta + 5)/(delta1)
tau = -mu/y_delta_mu^2 - .25/mu + 
	.25*delta*(delta2)*mu/(y*(delta1))^2

Delta.resp = rbind(
	t(X)%*%diag(as.vector(a*psi*vartheta)), 
	t(tau*vartheta)
)

###############
# Matriz de pertuba��o (perturba��o na vari�vel explicativa)
s_x = sd(X[,influence_x + 1])
beta_t = beta[influence_x + 1]
qv = delta/y_delta_mu + .25*(delta1)*y/mu^2 -
	.25*(delta^2)/((delta1)*y) - .5/mu
tv = .5/mu^2 - (delta/y_delta_mu)^2 - .5*(delta1)*y/mu^3
zeta = beta_t*a*(y/y_delta_mu^2 + .25*y/mu^2 - 
	.25*delta*(delta2)/(y*(delta1)^2) )

Delta.covariavel = rbind(
s_x*beta_t*t(X)%*%( diag(as.vector(-qv/(dg(mu)^2))) + diag(as.vector(a*a*tv))) + 
	s_x*cbind(diag((a*qv)[1:p]), matrix(0,p,n-p) ),
t(zeta)
)

###############
# Matriz de alavanca generalizada
lambda = -mu/y_delta_mu^2 - .25/mu + .25*delta*delta2*mu/(delta1*y)^2
vv = -delta*delta1/y_delta_mu^2 + .25*delta1/mu^2 + .25*delta*delta/(delta1*y*y)
Davv = diag(as.vector(a*vv))
Dav = Da%*%diag(as.vector(vv))

M = t(X)%*%Dc%*%X
A = ginv(M)%*%t(X)%*%Da%*%m
E = sum(d) - t(m)%*%Da%*%X%*%A

GL_beta = Da%*%X%*%ginv(M)%*%t(X)%*%Davv
B = t(lambda)%*%ginv(Davv) - t(X%*%A)
GL = Da%*%X%*%A%*%B%*%Davv/(E[1,1]) - GL_beta


return(list(beta = beta,delta = delta, Delta.ponder = Delta.ponder, 
	Mat.Hes = L, Delta.resp=Delta.resp, Delta.covariavel=Delta.covariavel,
	GL = GL, conv = 1))

}

###############################################################################
# Diagn�stico bayesiano pr�prio para o MRBS para an�lise de influ�ncia

# Fun��o para calcular a m�dia estimada
mu.estim = function(beta,x) exp(beta%*%x)
# Fun��o para calcular a rec�proca da densidade
recip.dens = function(x,m,d) 1/dRBS(x,m,d)

# A fun��o tem como argumentos uma matriz contendo as amostras de MCMC
# dos par�metros, um vetor da va repostas e um vetor da va explicativa

BayesDiagBSR_influence = function(mPar, y, x){
p = dim(mPar)[2]		# n�mero de par�metros
#matriz para guardar inversos das probabilidades
sim.inv = matrix(NA,dim(mPar)[1],N)	
# X = cbind(rep(1,dim(x)[1]),x)		#matriz de modelo
X = cbind(rep(1,length(x)),x)		#matriz de modelo quando x � vetor
n = length(y)		#tamanho da amostra
for(j in 1:n){
	mu.est = mu.estim(mPar[,1:(p-1)],X[j,])
	sim.inv[,j] = mapply(recip.dens,
	y[j],mu.est,mPar[,p])
}
cpo = 1/apply(sim.inv, 2, mean)
kl.divergence = -log(cpo) + colMeans(log(1/sim.inv))
return(list(kl.divergence=kl.divergence))
}




