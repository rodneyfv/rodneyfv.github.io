require(ssym)
require(fBasics)

setwd('C:/Users/Rodney/Documents/Pesquisa/Regress�o BS/Aplica��es/biaxial')
source("Comandos BSR.R")



#####################################################

data(Biaxial)
attach(Biaxial)
pairs(Biaxial)
?Biaxial

################################

# An�lise descritiva

basicStats(Life)
basicStats(Work)

# Modelo BSR

l.W = log(Work)
mod.BSR = regRBS(Life, l.W,n.it=50)
aux = regRBS(Life, Work,n.it=50)



# Ajuste do MRBS
mod.BSR = regRBS(Life,l.W,n.it=40)
names(mod.BSR)

# Par�metros estimados e matriz de covari�ncia
mod.BSR$beta; mod.BSR$delta
sqrt(diag(mod.BSR$vcov))
cbind(c(mod.BSR$beta, mod.BSR$delta),sqrt(diag(mod.BSR$vcov)))

mod.BSR$AIC		# crit�rio de informa��o de Akaike
mod.BSR$BIC		# crit�rio de informa��o Bayesiano

# intervalo com dois desvios para os par�metros
round(cbind(c(mod.BSR$beta, mod.BSR$delta)-2*sqrt(diag(mod.BSR$vcov)),
c(mod.BSR$beta, mod.BSR$delta),
c(mod.BSR$beta, mod.BSR$delta)+2*sqrt(diag(mod.BSR$vcov))),4)


# Res�duos vs. Valores ajustados
plot(mod.BSR$ajustados, mod.BSR$resid,ylim=c(-3,3.5),
xlab="Ajustados",ylab="Res�duos")
abline(h=c(-2,2),lty=c(3,3))
identify(mod.BSR$ajustados, mod.BSR$resid,n=3)

# Valores ajustados vs. Valores observados
plot(Life, mod.BSR$ajustados,ylab="Ajustados")
identify(Life, mod.BSR$ajustados,n=2)
lines(c(0,200),c(0,200))

# An�lise de influ�ncia local (pondera��o de casos)

B = t(mod.BSR$Mat.Pert)%*%ginv((-1)*mod.BSR$Mat.Hes)%*%mod.BSR$Mat.Pert
Cmax = eigen(B)$val[1]
dmax = abs(eigen(B)$vec[,1])

# dmax vs. �ndice
plot(1:length(Life),dmax,ylim=c(0,1),type="h",
ylab=expression(paste(d[max])),xlab="�ndice")
abline(h=2*mean(dmax),lty=3)
identify(1:length(Life),dmax,n=5)

# dmax vs. ajustados
plot(mod.BSR$ajustados,dmax,ylim=c(0,1),type="p",
ylab=expression(paste(d[max])),xlab="Ajustados")
abline(h=2*mean(dmax),lty=3)
identify(mod.BSR$ajustados,dmax,n=5)

# Ci vs. �ndice - Escobar e Meeker(1992)
Ci = 2*abs(diag(B))
plot(1:length(Life),Ci,ylim=c(0,1),type="h",
ylab=expression(paste(d[max])),xlab="Valores Ordenados")
abline(h=2*mean(Ci),lty=3)
identify(1:length(Life),Ci,n=5)

# Envelope simulado

envelope.MRBS(Life,l.W,mod.BSR)


par(mfrow=c(1,2))
plot(mod.BSR$ajustados, mod.BSR$resid,ylim=c(-3,3.5),
xlab="Adjusted",ylab="Standardized residuals")
abline(h=c(-2,2),lty=c(3,3))
identify(mod.BSR$ajustados, mod.BSR$resid,n=1)
envelope.MRBS(Life,l.W,mod.BSR)


################################



# Modelo BSR bayesiano

# Pacote para utilizar o OpenBUGs com o R
library(R2OpenBUGS)

# Observa��es
y = Life; x = l.W
N = length(y)
data = list("N","x","y")
# valores iniciais
inits = list(list(delta = 11.87709,beta = c(12.360573, -1.670769)))
# par�metros do modelo
parameters = c("beta","delta")

# Modelo no OpenBUGs
modbayes = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS-biaxial.odc", n.chains = 1, n.iter = 10000,n.burnin = 1000)

# Resultados
modbayes$summary
round(modbayes$summary[,c(1,2,3,5,7)],4)

names(modbayes)

dim(modbayes$sims.matrix)
head(modbayes$sims.matrix)
p = dim(modbayes$sims.matrix)[2] - 1		# n�mero de par�metros

# C�lculo do CPO

# matriz para guardar as amostras dos par�metros
sim.par.modbayes = modbayes$sims.matrix[,1:p]
dim(sim.par.modbayes)

# Fun��o para calcular a m�dia estimada
mu.estim = function(beta,x) exp(beta%*%x)

#matriz para guardar inversos das probabilidades
sim.inv.modbayes = matrix(NA,dim(sim.par.modbayes)[1],N)	
X = cbind(rep(1,length(l.W)),l.W)		#matriz de modelo
for(j in 1:N){
sim.inv.modbayes[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
y[j],mu.estim(sim.par.modbayes[,1:(p-1)],X[j,]),sim.par.modbayes[,p])
}
dim(sim.inv.modbayes)

# c�lculo da m�dia harm�nica para obter o CPO
cpo.modbayes <- 1/apply(sim.inv.modbayes, 2, mean)

# Gr�fico: CPO x �ndice (verifica qualidade de ajuste de cada observa��es)
plot(1:N, cpo.modbayes, type = "h", xlab = "index", ylab = "CPO")

# LPML
lpml.modbayes <- sum(log(cpo.modbayes))
lpml.modbayes

# Kullback-Leibler divergence
KL.modbayes = -log(cpo.modbayes) + colMeans(log(1/sim.inv.modbayes))
plot(1:N, KL.modbayes, type = "h", xlab = "�ndice da observa��o", ylab = "K-L")
identify(1:N,KL.modbayes,n=6)

# Calibra��o
calib.modbayes = .5*(1+sqrt( 1-exp(-2*KL.modbayes) ))
plot(1:N, calib.modbayes, type = "h", xlab = "Index", ylab = "Calibration")
identify(1:N, calib.modbayes,n=6)


#####################################
# Compara��o das an�lises de influ�ncia sob
# os aspectos cl�ssico e bayesiano

dmax.norm = (dmax - min(dmax))/(max(dmax)-min(dmax))
KL.modbayes.norm = (KL.modbayes - min(KL.modbayes))/(max(KL.modbayes)-min(KL.modbayes))
Ci.norm = (Ci - min(Ci))/(max(Ci)-min(Ci))

cor(dmax.norm,KL.modbayes.norm)
cor(dmax.norm,Ci.norm)
cor(Ci.norm,KL.modbayes.norm)


par(mfrow=c(1,3))
plot(1:N,dmax.norm,ylim=c(0,1),type="h",
ylab=expression(d[max]),sub="(a)")
identify(1:N,dmax.norm,n=4)
plot(1:N,KL.modbayes.norm,ylim=c(0,1),type="h",
ylab=expression(K-L),sub="(b)")
identify(1:N,KL.modbayes.norm,n=4)
plot(1:N,Ci.norm,ylim=c(0,1),type="h",
ylab=expression(paste(Ci)),sub="(c)")
identify(1:N,Ci.norm,n=4)


################################









