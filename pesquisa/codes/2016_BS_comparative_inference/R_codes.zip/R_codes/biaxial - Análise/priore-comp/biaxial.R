# Neste programa ser�o considerados alguns valores de par�metros
# para simular dados para testa o modelo de regress�o BSR bayesiano,
# utilizando diferentes priores para os par�metros.
# Os modelos ajustados ser�o comparados atrav�s do LPML e do pseudo
# valor de bayes
# 


require(ssym)
require(fBasics)
require(coda)
require(MASS)
require(R2OpenBUGS)

# Enable Just In Time compilation in R
R_COMPILE_PKGS=TRUE
R_ENABLE_JIT=3
library(compiler)
enableJIT(3) 


setwd('C:/Users/Rodney/Desktop/biaxial - An�lise/priore-comp')
source("Comandos BSR.R")


#####################################################

# Par�metros verdadeiros
# cen�rio 1
beta0 = 2; beta1 = -1.5; delta = 3;
# cen�rio 2
beta0 = -2.5; beta1 = 2; delta = 3;
# cen�rio 3
beta0 = -.5; beta1 = -1.7; delta = 5;
# cen�rio 4
beta0 = 1.3; beta1 = 2.2; delta = 1;


# Simulando os dados
set.seed(2015)
x = runif(50)	# covari�vel
mu = exp(beta0 + beta1*x)	# gerando as m�dias
y = sapply(mu,function(m,d)rRBS(1,m,delta))	# gerando a amostra


# palpites iniciais
modclass = regRBS(y,x)
beta_init = modclass$beta
delta_init = modclass$delta


################################################################
################################################################
# Modelo BSR bayesiano

# Observa��es
N = length(y)
data = list("N","x","y")

###################
# Modelo 1 com priori Normal para beta e priori vaga

# valores iniciais
inits = list(list(delta = delta_init,beta = beta_init))
# par�metros do modelo
parameters = c("beta","delta")

# Modelo no OpenBUGs
modbayes = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS1.odc", n.chains = 1, n.iter = 10000,n.thin=5,
	n.burnin = 1000)

# Resultados
# round(modbayes$summary[,c(1,2,3,5,7)],4)
p1 = dim(modbayes$sims.matrix)[2] - 1		# n�mero de par�metros

diag1 = BayesDiagBSR(modbayes$sims.matrix[,1:p1],y,x)
# mcmc_m1 = mcmc(modbayes$sims.matrix[,1:p1])
# par(mfrow=c(2,2)); traceplot(mcmc_m1)
# autocorr.plot(mcmc_m1)

###################
# Modelo 2 com priori Normal para beta com priori gama para a precis�o

# valores iniciais no modelo com priori gama para precis�o
inits = list(list(delta = delta_init,beta = beta_init, tau = 1))
# par�metros do modelo
parameters = c("beta","delta","tau")

# Modelo no OpenBUGs
modbayes2 = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS2.odc", n.chains = 1, n.iter = 10000,n.thin=5,
	n.burnin = 1000)

# Resultados
# round(modbayes2$summary[,c(1,2,3,5,7)],4)
p2 = dim(modbayes2$sims.matrix)[2] - 2		# n�mero de par�metros

diag2 = BayesDiagBSR(modbayes2$sims.matrix[,1:p2],y,x)
# mcmc_m2 = mcmc(modbayes2$sims.matrix[,1:(p2+1)])
# par(mfrow=c(3,2)); traceplot(mcmc_m2)
# autocorr.plot(mcmc_m2)

###################
# Modelo 3 com priori Normal para beta com priori t-Student para beta

# valores iniciais com priori t-Student para beta
inits = list(list(delta = delta_init,beta = beta_init, nu = 40, tau = 1))
# par�metros do modelo
parameters = c("beta","delta","nu","tau")

# Modelo no OpenBUGs
modbayes3 = bugs(data = data, inits = inits, parameters.to.save = parameters,
model.file = "MRBS3.odc", n.chains = 1, n.iter = 10000,n.thin=5,
	n.burnin = 1000)

# Resultados
# round(modbayes3$summary[,c(1,2,3,5,7)],4)
p3 = dim(modbayes3$sims.matrix)[2] - 3		# n�mero de par�metros

diag3 = BayesDiagBSR(modbayes3$sims.matrix[,1:p3],y,x)
# mcmc_m3 = mcmc(modbayes3$sims.matrix[,1:(p3+1)])
# par(mfrow=c(3,2)); traceplot(mcmc_m3)
# autocorr.plot(mcmc_m3)



#####################################
# Compara��o das an�lises de influ�ncia sob
# os aspectos cl�ssico e bayesiano


# Comparando os modelos pela LPML
diag1$lpml
diag2$lpml
diag3$lpml

# Comparando os modelos pelo pseudo fator de Bayes
prod(diag1$cpo)/prod(diag2$cpo)
prod(diag1$cpo)/prod(diag3$cpo)
prod(diag2$cpo)/prod(diag3$cpo)



################################









