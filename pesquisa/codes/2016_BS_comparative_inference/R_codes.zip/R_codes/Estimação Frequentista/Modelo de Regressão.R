# Simula��o com a uniforme

x = runif(15,0,1)
X = cbind(rep(1,15),x)

beta_0 = 2
beta_1 = .5
delta_pop = 150
beta_pop = c(beta_0, beta_1)

# Amostra RBS
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))

# Valores iniciais para beta
beta = as.vector(lm(log(y)~x)$coef)

# Valores iniciais para delta
delta = mleRBS(y)$delta

t = y


# Vetor de par�metros
theta = c(beta, delta)

# Fun��o de liga��o logar�tmica
g = function(x) log(x)
dg = function(x) 1/x
gi = function(x) exp(x)


# m�dia
mu = gi(X%*%beta)

# Elementos do vetor escore
###############
z = -1/(2*mu) + delta/(delta*t+t+delta*mu) + (delta+1)*t/(4*mu^2) - (delta^2)/(4*t*(delta+1))
###############
b = delta/(2*(delta+1)) + (t+mu)/(delta*t+t+delta*mu) - t/(4*mu) - mu*delta*(delta+2)/(4*t*(delta+1)^2)
Db = diag(as.vector(b))
###############
a = 1/dg(mu)
Da = diag(as.vector(a))


# Fun��o para calcular integral da matriz de informa��o
Idt=function(m,d){
  f.Idt=function(t){
    exp(d/2)*
      sqrt((1+d)/(16*pi*m))*(t^(-1.5))*
      (t + (d*m)/(d+1))^(-1) *
      exp( -(d/4)*( t*(d+1)/(d*m) + d*m/(t*(d+1)) ) )
  }
  integrate(f.Idt,0,Inf)$value
}

###############
RIdt = sapply(mu, function(x) Idt(x,delta))

###############
v = delta/(2*(mu*dg(mu))^2) + (RIdt*delta^2)/(((delta+1)*dg(mu))^2)
Dv = diag(as.vector(v))

###############
s = 1/(2*mu*(delta+1)) + delta*mu*RIdt/(delta+1)^3

###############
u = (delta^2 + 3*delta + 1)/(2*(delta*(delta+1))^2) + (mu^2)*RIdt/(delta+1)^4
Du = diag(as.vector(u))


# Matriz de pesos aumentada
W = rbind(
  cbind(Dv, Da%*%s),
  cbind(t(s)%*%Da, sum(diag(Du)))
)

# Matriz de modelo aumentada
Xt = rbind(
cbind(X,rep(0,dim(X)[1])),
cbind(t(rep(0,dim(X)[2])),1)
)

######### Estima��o

require(MASS)
Dab = rbind(
  cbind(Da,rep(0,dim(Da)[2])),
  cbind(t(rep(0,dim(Da)[1])),sum(diag(Db)))
)

# Vari�vel dependente
Z = Xt%*%theta + ginv(W)%*%Dab%*%rbind(z,1)
ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%W%*%Z

# Passo antes da vari�vel dependente
theta.n = theta + ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%Dab%*%rbind(z,1)

theta = theta.n
beta = theta[1:2]
delta = theta[3]

#####################

# the definition of the d, p, q, and r functions

dRBS=function(t,mu=1,delta=1){
  if (any(mu <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(delta <= 0)) stop(paste("delta must be positive", "\n", ""))
  fy = exp(delta/2)*
    sqrt((1+delta)/(16*pi*mu))*
    (t^(-.5) + (t^(-1.5)*delta*mu)/(delta+1))*
    exp( -(delta/4)*( (t*(delta+1))/(delta*mu) + (delta*mu)/(t*(delta+1)) ) )
  fy
}

pRBS=function(t,mu=1,delta=1){
  cdf = pnorm( sqrt(delta/2)*( sqrt((t*(delta+1))/(delta*mu))-sqrt((delta*mu)/(t*(delta+1))) ) )
  cdf
}

qRBS=function(q,mu=1,delta=1){
  if (any(mu <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(delta <= 0)) stop(paste("delta must be positive", "\n", ""))
resp[which(q <= 10^(-250))] = 0
resp[which(q > 10^(-250))] = (delta*mu/(delta+1)) * (qnorm(q)/sqrt(2*delta) + sqrt(1+(qnorm(q)/sqrt(2*delta))^2))^2
  resp
}

rRBS=function(t,mu=1,delta=1){
  if (any(mu <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(delta <= 0)) stop(paste("delta must be positive", "\n", ""))
  Z = rnorm(t)
  r = (mu*delta/(delta+1))*(Z/sqrt(2*delta) + sqrt((Z/sqrt(2*delta))^2 + 1))^2
  r
}

