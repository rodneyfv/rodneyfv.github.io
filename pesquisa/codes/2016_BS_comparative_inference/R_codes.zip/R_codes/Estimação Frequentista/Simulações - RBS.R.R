# Simula��o 

#########################

# Estimador pelo m�todo dos momentos

tam = c(10,20,50,100)	# Tamanhos de amostra 
vmu = c(2,4,6)	# valores da m�dia
vdelta = c(2,4,6)	# valores de delta

Mmu = array(NA,c(4,3,1000)) #matriz para guardar valores estimados de mu
for(j in 1:1000){
for(i in 1:4){
Mmu[i,1,j] = mmeRBS(rRBS(tam[i],2,5))$mu
Mmu[i,2,j] = mmeRBS(rRBS(tam[i],4,5))$mu
Mmu[i,3,j] = mmeRBS(rRBS(tam[i],6,5))$mu
}
}

Mdelta = array(NA,c(4,3,1000)) #matriz para guardar valores estimados de delta
for(j in 1:1000){
for(i in 1:4){
Mdelta[i,1,j] = mmeRBS(rRBS(tam[i],2,2))$delta
Mdelta[i,2,j] = mmeRBS(rRBS(tam[i],2,4))$delta
Mdelta[i,3,j] = mmeRBS(rRBS(tam[i],2,6))$delta
}
}

# matriz com dados das estimativas de mu
Emu = array(NA,c(4,3,3))
for(i in 1:3){
for(j in 1:4){
Emu[j,,i] = c(mean(Mmu[j,i,]), sd(Mmu[j,i,]), var(Mmu[j,i,])+(mean(Mmu[j,i,])-vmu[i])^2)
}
}

# matriz com dados das estimativas de delta
Edelta = array(NA,c(4,3,3))
for(i in 1:3){
for(j in 1:4){
Edelta[j,,i] = c(mean(Mdelta[j,i,]), sd(Mdelta[j,i,]), var(Mdelta[j,i,])+(mean(Mdelta[j,i,])-vdelta[i])^2)
}
}

#########################

# Estimador pelo m�todo dos momentos modificado

tam = c(10,20,50,100)	# Tamanhos de amostra 
vmu = c(2,4,6)	# valores da m�dia
vdelta = c(2,4,6)	# valores de delta

Mmu = array(NA,c(4,3,1000)) #matriz para guardar valores estimados de mu
for(j in 1:1000){
for(i in 1:4){
Mmu[i,1,j] = modmeRBS(rRBS(tam[i],2,5))$mu
Mmu[i,2,j] = modmeRBS(rRBS(tam[i],4,5))$mu
Mmu[i,3,j] = modmeRBS(rRBS(tam[i],6,5))$mu
}
}

Mdelta = array(NA,c(4,3,1000)) #matriz para guardar valores estimados de delta
for(j in 1:1000){
for(i in 1:4){
Mdelta[i,1,j] = modmeRBS(rRBS(tam[i],2,2))$delta
Mdelta[i,2,j] = modmeRBS(rRBS(tam[i],2,4))$delta
Mdelta[i,3,j] = modmeRBS(rRBS(tam[i],2,6))$delta
}
}

# matriz com dados das estimativas de mu
Emu = array(NA,c(4,3,3))
for(i in 1:3){
for(j in 1:4){
Emu[j,,i] = c(mean(Mmu[j,i,]), sd(Mmu[j,i,]), var(Mmu[j,i,])+(mean(Mmu[j,i,])-vmu[i])^2)
}
}

# matriz com dados das estimativas de delta
Edelta = array(NA,c(4,3,3))
for(i in 1:3){
for(j in 1:4){
Edelta[j,,i] = c(mean(Mdelta[j,i,]), sd(Mdelta[j,i,]), var(Mdelta[j,i,])+(mean(Mdelta[j,i,])-vdelta[i])^2)
}
}


#########################

# Estimador de m�xima verossimilhan�a

tam = c(10,20,50,100)	# Tamanhos de amostra 
vmu = c(2,4,6)	# valores da m�dia
vdelta = c(2,4,6)	# valores de delta

Mmu = array(NA,c(4,3,1000)) #matriz para guardar valores estimados de mu
for(j in 1:1000){
for(i in 1:4){
Mmu[i,1,j] = mleRBS(rRBS(tam[i],2,5))$mu
Mmu[i,2,j] = mleRBS(rRBS(tam[i],4,5))$mu
Mmu[i,3,j] = mleRBS(rRBS(tam[i],6,5))$mu
}
}

Mdelta = array(NA,c(4,3,1000)) #matriz para guardar valores estimados de delta
for(j in 1:1000){
for(i in 1:4){
Mdelta[i,1,j] = mleRBS(rRBS(tam[i],2,2))$delta
Mdelta[i,2,j] = mleRBS(rRBS(tam[i],2,4))$delta
Mdelta[i,3,j] = mleRBS(rRBS(tam[i],2,6))$delta
}
}

# matriz com dados das estimativas de mu
Emu = array(NA,c(4,3,3))
for(i in 1:3){
for(j in 1:4){
Emu[j,,i] = c(mean(Mmu[j,i,]), sd(Mmu[j,i,]), var(Mmu[j,i,])+(mean(Mmu[j,i,])-vmu[i])^2)
}
}

# matriz com dados das estimativas de delta
Edelta = array(NA,c(4,3,3))
for(i in 1:3){
for(j in 1:4){
Edelta[j,,i] = c(mean(Mdelta[j,i,]), sd(Mdelta[j,i,]), var(Mdelta[j,i,])+(mean(Mdelta[j,i,])-vdelta[i])^2)
}
}


M[,7:9] = rbind(Edelta[,,1],Edelta[,,2],Edelta[,,3])

M = matrix(NA,12,9)

require(xtable)
install.packages("xtable")

xtable(M)



