############################################################
# Fun��o para gerar valores aleat�rios da rep BS ###########

rRBS=function(t,m=1,d=1){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  Z = rnorm(t)
  r = (m*d/(d+1))*(Z/sqrt(2*d) + sqrt((Z/sqrt(2*d))^2 + 1))^2
  r
}

############################################################
# Fun��o acumulada da dist. Birnbaum-Saunders ##############

pRBS=function(t,m=1,d=1){
  cdf = pnorm( sqrt(d/2)*( sqrt((t*(d+1))/(d*m))-sqrt((d*m)/(t*(d+1))) ) )
  cdf
}

############################################################
# Fun��o densidade da dist. Birnbaum-Saunders ##############

dRBS=function(t,m=1,d=1){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  fy = exp(d/2)*
    sqrt((1+d)/(16*pi*m))*
    (t^(-.5) + (t^(-1.5)*d*m)/(d+1))*
    exp( -(d/4)*( (t*(d+1))/(d*m) + (d*m)/(t*(d+1)) ) )
  fy
}

##########################################################
# Fun��o quantil da dist. Birnbaum-Saunders ##############

qRBS=function(q,m=1,d=1){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  if(q < 10^(-250)){resp = 0}
  else{
    q=(d*m/(d+1)) * (qnorm(q)/sqrt(2*d) + sqrt(1+(qnorm(q)/sqrt(2*d))^2))^2
  }
  q
}

##############################################################
# Fun��o para o Estimador pelo m�todo dos momentos modificados 
# da dist. Birnbaum-Saunders

modmeRBS = function(t){

th = mean(1/t)

mu = mean(t)

delta = 1/(sqrt(mu*th) - 1)
list(mu=mu,delta=delta)
}

# t = rRBS(30,m=10,d=10)
# modmeRBS(t)



##########################################################
# Fun��o para o EMM da dist. Birnbaum-Saunders ###########

mmeRBS = function(t){
mu = mean(t)

n = length(t)
s2 = (n-1)*var(t)/n

delta = ( mu^2 - s2 + sqrt(mu^4 + 3*s2*mu^2) )/s2
list(mu=mu,delta=delta)
}

# t = rRBS(30,m=10,d=10)
# mmeRBS(t)


###########################################################################
# Fun��o para a matriz de informa��o da dist. Birnbaum-Saunders ###########

# Fun��o para calcular integral da matriz de informa��o
Idt=function(m,d){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  f.Idt=function(t){
    exp(d/2)*
      sqrt((1+d)/(16*pi*m))*(t^(-1.5))*
      (t + (d*m)/(d+1))^(-1) *
      exp( -(d/4)*( t*(d+1)/(d*m) + d*m/(t*(d+1)) ) )
  }
  integrate(f.Idt,0,Inf)$value
}
  

##########################################################
# Fun��o para o EMV da dist. Birnbaum-Saunders ###########

mleRBS = function(y, n.iter=10){

# Derivadas da matriz de informa��o
dldm = function(mu,delta,y) sum( -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1)) )
d2ldm2 = function(mu,delta,y) length(y)*( -delta/(2*mu^2) - (delta^2)*Idt(mu,delta)/(delta+1)^2 )
dldd = function(mu,delta,y) sum( delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2) )
d2ldd2 = function(mu,delta,y) length(y)*( -(delta^2 + 3*delta + 1)/(2*(delta+1)^2 * delta^2) - (mu^2)*Idt(mu,delta)/((delta+1)^4) )
d2ldmdd = function(mu,delta,y) length(y)*( -1/(2*mu*(delta+1)) - delta*mu*Idt(mu,delta)/((delta+1)^3) )

# Vetor escore
VetEsc = function(mu,delta,y) c(dldm(mu,delta,y), dldd(mu,delta,y))

# Matriz de informa��o de Fisher
MatInf = function(mu, delta, y) -matrix(
c(d2ldm2(mu,delta,y),d2ldmdd(mu,delta,y),d2ldmdd(mu,delta,y),d2ldd2(mu,delta,y)),2,2)

# Palpite inicial
B0 = c(modmeRBS(y)$mu,modmeRBS(y)$delta) 

for(i in 1:n.iter){
B = B0 + solve(MatInf(B0[1],B0[2],y))%*%VetEsc(B0[1],B0[2],y)
B0 = B
}
list(mu=B0[1],delta=B0[2])
}

# t = rRBS(30,m=1,d=200)
# mleRBS(t,n.iter=20)






