
# Fun��o de liga��o logar�tmica
g = function(x) log(x)
dg = function(x) 1/x
gi = function(x) exp(x)



veross = function(t,X,theta){
delta=theta[length(theta)]
beta=theta[1:length(theta)-1]
mu = gi(X%*%beta)
L = sum( delta/2 - .5*log(16*pi) - .5*log((delta+1)*(t^3)*mu/((delta*t+t+delta*mu)^2)) -
t*(delta+1)/(4*mu) - (delta^2)*mu/(4*(delta+1)*t)
)
L
}




# Simula��o com a uniforme

x = runif(15,0,1)
X = cbind(rep(1,15),x)

beta_0 = 2
beta_1 = .5
delta_pop = 150
beta_pop = c(beta_0, beta_1)

# Amostra RBS
t = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))

for(i in 1:15){
t[i] = rRBS(1,exp(X[i,]%*%beta_pop),delta_pop)
}

# Valores iniciais para beta
beta = as.vector(lm(log(t)~x)$coef)

# Valores iniciais para delta
delta = mleRBS(t)$delta

# Vetor de par�metros
theta = c(beta, delta)

veross(y,X,theta)

aux = optim(par=theta,veross,t=t,X=X,method="BFGS")
names(aux)


