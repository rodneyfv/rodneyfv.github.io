# Simula��o 


beta_0 = 2
beta_1 = 1.5
beta_2 = .5
delta_pop = 10
beta_pop = c(beta_0, beta_1, beta_2)
theta = c(beta_pop, delta_pop)

#########################
# Tamanho de amostra n=15

x1 = runif(15,0,1)
x2 = rnorm(15,0,1)
X = cbind(rep(1,15),x1,x2)
Xc = X[,-1]

M15 = matrix(NA,1000,4)

for(i in 1:1000){
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
aux = regRBS(y,Xc)
M15[i,] = c(aux$beta,aux$delta)
}

#########################
# Tamanho de amostra n=30

x1 = runif(30,0,1)
x2 = rnorm(30,0,1)
X = cbind(rep(1,30),x1,x2)
Xc = X[,-1]

M30 = matrix(NA,1000,4)

for(i in 1:1000){
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
aux = regRBS(y,Xc)
M30[i,] = c(aux$beta,aux$delta)
}

#########################
# Tamanho de amostra n=50

x1 = runif(50,0,1)
x2 = rnorm(50,0,1)
X = cbind(rep(1,50),x1,x2)
Xc = X[,-1]

M50 = matrix(NA,1000,4)

for(i in 1:1000){
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
aux = regRBS(y,Xc)
M50[i,] = c(aux$beta,aux$delta)
}


#########################
# Estimativas para os diferentes casos	

# Matriz com estimativas dos par�metros po linha
E = matrix(NA, 12, 3)

E[1:4,] = cbind(apply(M15,2,mean),
apply(M15,2,sd), apply(M15,2,var) + (apply(M15,2,mean)-theta)^2)
E[5:8,] = cbind(apply(M30,2,mean),
apply(M30,2,sd), apply(M30,2,var) + (apply(M30,2,mean)-theta)^2)
E[9:12,] = cbind(apply(M50,2,mean),
apply(M50,2,sd), apply(M50,2,var) + (apply(M50,2,mean)-theta)^2)


# Matriz com estimativas dos tamnhos de amostra por linha
Est = E
k=1
for(i in 0:3){
Est[k:(k+2),] = E[c(1,5,9)+i,]
k = k+3
}
Est


require(xtable)
xtable(Est)























