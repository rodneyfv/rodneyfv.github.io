
regRBS = function(y,Xev){

# Fun��o de liga��o logar�tmica
g = function(x) log(x)
dg = function(x) 1/x
gi = function(x) exp(x)

# Pacote necess�rio para o ginv
require(MASS)

# Valores iniciais para beta
beta = lm(g(y)~Xev)$coef

# Valores iniciais para delta
delta = mleRBS(y)$delta

# Vetor de par�metros
theta = c(beta, delta)

# Matriz de modelo
X = cbind(rep(1,dim(as.matrix(Xev))[1]),as.matrix(Xev))

# Matriz de modelo aumentada
Xt = rbind(
cbind(X,rep(0,dim(X)[1])),
cbind(t(rep(0,dim(X)[2])),1)
)


# Itere��o de estima��o
for(i in 1:10){

# Vetor da m�dia
mu = gi(X%*%beta)

###############
z = -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1))
###############
b = delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2)
Db = diag(as.vector(b))
###############
a = 1/dg(mu)
Da = diag(as.vector(a))
###############
RIdt = sapply(mu, function(x) Idt(x,delta))
###############
v = delta/(2*(mu*dg(mu))^2) + (RIdt*delta^2)/(((delta+1)*dg(mu))^2)
Dv = diag(as.vector(v))
###############
s = 1/(2*mu*(delta+1)) + delta*mu*RIdt/(delta+1)^3
###############
u = (delta^2 + 3*delta + 1)/(2*(delta*(delta+1))^2) + (mu^2)*RIdt/(delta+1)^4
Du = diag(as.vector(u))
###############
Dab = rbind(
  cbind(Da,rep(0,dim(Da)[2])),
  cbind(t(rep(0,dim(Da)[1])),sum(diag(Db)))
)

# Matriz de pesos aumentada
W = rbind(
  cbind(Dv, Da%*%s),
  cbind(t(s)%*%Da, sum(diag(Du)))
)

###### Estima��o

# Vari�vel dependente
Z = Xt%*%theta + ginv(W)%*%Dab%*%rbind(z,1)
theta.n = ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%W%*%Z

# theta.n = theta + ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%Dab%*%rbind(z,1)
beta = theta.n[1:length(theta)-1]
delta = theta.n[length(theta)]
theta = theta.n 

}

list(beta = beta, delta = delta)

}

############
# Exemplo 1

x1 = runif(15,0,1)
x2 = runif(15,1,3)
X = cbind(rep(1,15),x1,x2)

beta_0 = 2
beta_1 = .5
beta_2 = 3
delta_pop = 10
beta_pop = c(beta_0, beta_1, beta_2)

# Amostra RBS
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))

Xev = X[,-c(1)]
regRBS(y,Xev)

###########

beta_0 = 2
beta_1 = .5
delta_pop = 150
beta_pop = c(beta_0, beta_1)

# Exemplo 2
x = runif(15,0,1)
X = cbind(rep(1,15),x)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
regRBS(y,x)


###########
# Exemplo 3
x = rexp(15,10)
X = cbind(rep(1,15),x)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
regRBS(y,x)


###########
# Exemplo 4
x = rnorm(15,0,4/5)
X = cbind(rep(1,15),x)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
regRBS(y,x)


###########

beta_0 = 2
beta_1 = 1.5
beta_2 = .5
beta_3 = .1
delta_pop = 150
beta_pop = c(beta_0, beta_1, beta_2, beta_3)

# Exemplo 5
x1 = runif(15,0,1)
x2 = rexp(15,10)
x3 = rnorm(15,0,4/5)
X = cbind(rep(1,15),x1,x2,x3)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
regRBS(y,X[,-1])


