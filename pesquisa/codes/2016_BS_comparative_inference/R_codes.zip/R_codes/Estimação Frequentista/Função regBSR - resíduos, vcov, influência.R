
regRBS = function(y,Xev){

# Fun��o de liga��o logar�tmica
 g = function(x) log(x); dg = function(x) 1/x; gi = function(x) exp(x); d2g = function(x) -1/(x^2)

# Fun��o de liga��o raiz
# g = function(x) sqrt(x); dg = function(x) 1/(2*sqrt(x)); gi = function(x) x^2

# Fun��o de liga��o inversa
# g = function(x) 1/x; dg = function(x) -1/(x^2); gi = function(x) 1/x


# Pacote necess�rio para o ginv
require(MASS)

# Valores iniciais para beta
beta = lm(g(y)~Xev)$coef

# Valores iniciais para delta
delta = mleRBS(y)$delta

# Vetor de par�metros
theta = c(beta, delta)

# Matriz de modelo
X = cbind(rep(1,dim(as.matrix(Xev))[1]),as.matrix(Xev))

# Matriz de modelo aumentada
Xt = rbind(
cbind(X,rep(0,dim(X)[1])),
cbind(t(rep(0,dim(X)[2])),1)
)


# Itere��o de estima��o
for(i in 1:20){

# Vetor da m�dia
mu = gi(X%*%beta)

###############
z = -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1))
###############
b = delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2)
Db = diag(as.vector(b))
###############
a = 1/dg(mu)
Da = diag(as.vector(a))
###############
RIdt = sapply(mu, function(x) Idt(x,delta))
###############
v = delta/(2*(mu*dg(mu))^2) + (RIdt*delta^2)/(((delta+1)*dg(mu))^2)
Dv = diag(as.vector(v))
###############
s = 1/(2*mu*(delta+1)) + delta*mu*RIdt/(delta+1)^3
###############
u = (delta^2 + 3*delta + 1)/(2*(delta*(delta+1))^2) + (mu^2)*RIdt/(delta+1)^4
Du = diag(as.vector(u))
###############
Dab = rbind(
  cbind(Da,rep(0,dim(Da)[2])),
  cbind(t(rep(0,dim(Da)[1])),sum(diag(Db)))
)

# Matriz de pesos aumentada
W = rbind(
  cbind(Dv, Da%*%s),
  cbind(t(s)%*%Da, sum(diag(Du)))
)

###### Estima��o

# Vari�vel dependente
Z = Xt%*%theta + ginv(W)%*%Dab%*%rbind(z,1)
theta.n = ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%W%*%Z

# theta.n = theta + ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%Dab%*%rbind(z,1)
beta = theta.n[1:length(theta)-1]
delta = theta.n[length(theta)]
theta = theta.n 

}

###############
dmu2 = (1/(2*mu^2) - (delta^2)/(delta*y+y+delta*mu)^2 - y*(delta+1)/(2*mu^3))
c = dmu2*(a^2) + z*(-d2g(mu)/(dg(mu)^2))*a
Dc = diag(as.vector(c))
###############
m = y/(delta*y+y+delta*mu)^2 + y/(4*mu^2) - delta*(delta+2)/(4*y*(delta+1)^2)
###############
d = 1/(2*(delta+1)^2) - ((y+mu)^2)/(delta*y+y+delta*mu)^2 - mu/(2*y*(delta+1)^3)
Dd = diag(as.vector(d))

# Matriz hessiana
L = rbind(
  cbind(t(X)%*%Dc%*%X, t(X)%*%Da%*%m),
  cbind(t(m)%*%Da%*%X, sum(diag(Dd)))
)


# Matriz de pertuba��o (pondera��o de casos)
Mat.Pert = rbind(
  t(X)%*%Da%*%diag(as.vector(z)),
  t(b)
)


# Matriz de vari�ncia-covari�ncia
K = ginv(t(Xt)%*%W%*%Xt)

# Res�duo do tipo Pearson padronizado
Vy = (mu^2)*(2*delta+5)/(delta+1)^2
resid = (y-mu)/sqrt(Vy)

return(list(beta = beta,delta = delta, vcov = K,
resid = resid, ajustados = mu, Mat.Hes = L, Mat.Pert = Mat.Pert))

}


###########
# Exemplo
beta_0 = 2
beta_1 = .5
delta_pop = 150
beta_pop = c(beta_0, beta_1)


x = runif(15,0,1)
X = cbind(rep(1,15),x)

# com a fun��o de liga��o logar�tmica
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
aux = regRBS(y,x)
names(aux)

aux$beta; aux$delta
plot(y, aux$resid)
plot(y, aux$ajustados)

# An�lise de influ�ncia (pondera��o de casos)
aux$Mat.Hes
aux$Mat.Pert
B = t(aux$Mat.Pert)%*%aux$Mat.Hes%*%aux$Mat.Pert
Cmax = eigen(B)$val[1]
dmax = abs(eigen(B)$vec[,1])
plot(1:15,dmax,ylim=c(0,1),type="h")


# com a fun��o de liga��o raiz
y = sapply(X%*%beta_pop, function(x) rRBS(1, x^2, delta_pop))
aux = regRBS(y,x)
names(aux)

aux$beta; aux$delta
plot(y, aux$resid)
plot(y, aux$ajustados)



# com a fun��o de liga��o inversa
y = sapply(X%*%beta_pop, function(x) rRBS(1, 1/x, delta_pop))
aux = regRBS(y,x)
names(aux)

aux$beta; aux$delta
plot(y, aux$resid)
plot(y, aux$ajustados)














