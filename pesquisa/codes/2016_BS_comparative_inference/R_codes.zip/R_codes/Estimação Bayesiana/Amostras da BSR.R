# Amostras geradas para simula��o no OpenBUGS

# valores dos par�metros

beta_0 = 2
beta_1 = 1.5
beta_2 = .5
delta_pop = 10
beta_pop = c(beta_0, beta_1, beta_2)

#########################
# Tamanho de amostra n=15

x1 = runif(15,0,1)
x2 = rnorm(15,0,1)
X = cbind(rep(1,15),x1,x2)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))
y

write(y, "", sep = ",")


#########################
# Tamanho de amostra n=30

x1 = runif(30,0,1)
x2 = rnorm(30,0,1)
X = cbind(rep(1,30),x1,x2)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))

write(y, "", sep = ",")


#########################
# Tamanho de amostra n=50

x1 = runif(50,0,1)
x2 = rnorm(50,0,1)
X = cbind(rep(1,50),x1,x2)
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))

write(y, "", sep = ",")













