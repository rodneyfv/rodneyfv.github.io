############################################################
# Fun��o para gerar valores aleat�rios da rep BS ###########
############################################################

rRepBS=function(t,m=1,d=1){
Z = rnorm(t)
(m*d/(d+1))*(Z/sqrt(2*d) + sqrt((Z/sqrt(2*d))^2 + 1))^2
}

############################

setwd("C:/Users/Rodney/Documents/IC/Regress�o BS/Scripts/r2winbugs")
library(R2WinBUGS)

x = round(rRepBS(30,5,5),2)

summary(x)
N = length(x)

data = list("N","x")

inits = list(list(delta = 2,mu = 2))

parameters = c("mu","delta")

file.show("unif(1,1).odc")

result <- bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "unif(1,1).odc", n.chains = 1, n.iter = 1000,
 n.burnin = 200, bugs.directory = "C:/Programas/WinBUGS14",
 debug = FALSE, save.history = FALSE, DIC = FALSE)

result$summary

names(result)
dimnames(result$sims.matrix)
dim(result$sims.matrix)


###### CPO

nomesinv <- paste("inv[", 1:N, "]", sep = "")
simulainv <- result$sims.matrix[, nomesinv]
cpo <- 1/apply(simulainv, 2, mean)

plot(1:N, cpo, type = "h", xlab = "observation index", ylab = "CPO")

fitmed <- sum(log(cpo))
fitmed

###### Pacote BOA

dimnames(result$sims.matrix)
nomespar <- paste("beta[", 1:4, "]", sep = "")
nomespar
simulashort <- result$sims.matrix[, nomespar]
library(boa)
boa.menu()


###### Pacote CODA

library(coda)
resultcoda <- as.mcmc.list(result)
codamenu()








