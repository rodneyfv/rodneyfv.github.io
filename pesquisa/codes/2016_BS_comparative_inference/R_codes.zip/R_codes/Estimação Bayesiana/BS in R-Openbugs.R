############################################################
# Fun��o densidade da dist. Birnbaum-Saunders ##############
############################################################

ft=function(t,m,d){
exp(d/2)*
sqrt((1+d)/(16*pi*m))*
(t^(-.5) + (t^(-1.5)*d*m)/(d+1))*
exp( -(d/4)*( (t*(d+1))/(d*m) + (d*m)/(t*(d+1)) ) )
}


############################################################
# Fun��o para gerar valores aleat�rios da rep BS ###########
############################################################

rRepBS=function(t,m=1,d=1){
Z = rnorm(t)
(m*d/(d+1))*(Z/sqrt(2*d) + sqrt((Z/sqrt(2*d))^2 + 1))^2
}

############################

setwd("C:/Users/Rodney/Documents/IC/Regress�o BS/Scripts/r2winbugs")
library(R2OpenBUGS)

x = round(rRepBS(30,5,5),2)

summary(x)
N = length(x)

data = list("N","x")

inits = list(list(delta = 2,mu = 2))

parameters = c("mu","delta")

file.show("unif(1,1).odc")

result <- bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "unif(1,1).odc", n.chains = 1, n.iter = 10000,
 n.burnin = 2000)

result$summary

names(result)
dimnames(result$sims.matrix)
dim(result$sims.matrix)


###### CPO

sim.par = result$sims.matrix[,1:2]
dim(sim.par)

sim.inv = matrix(NA,dim(sim.par)[1],N)
dim(sim.inv)

for(j in 1:N){
sim.inv[,j] = mapply(function(x,m,d) 1/ft(x,m,d),x[j],sim.par[,1],sim.par[,2])
}

cpo <- 1/apply(sim.inv, 2, mean)

plot(1:N, cpo, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml <- sum(log(cpo))
lpml





