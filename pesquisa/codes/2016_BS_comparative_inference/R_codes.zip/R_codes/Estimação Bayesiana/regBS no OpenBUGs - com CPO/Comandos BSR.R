############################################################
# Fun��o para gerar valores aleat�rios da rep BS ###########

rRBS=function(t,m=1,d=1){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  Z = rnorm(t)
  r = (m*d/(d+1))*(Z/sqrt(2*d) + sqrt((Z/sqrt(2*d))^2 + 1))^2
  r
}

############################################################
# Fun��o acumulada da dist. Birnbaum-Saunders ##############

pRBS=function(t,m=1,d=1){
  cdf = pnorm( sqrt(d/2)*( sqrt((t*(d+1))/(d*m))-sqrt((d*m)/(t*(d+1))) ) )
  cdf
}

############################################################
# Fun��o densidade da dist. Birnbaum-Saunders ##############

dRBS=function(t,m=1,d=1){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  fy = exp(d/2)*
    sqrt((1+d)/(16*pi*m))*
    (t^(-.5) + (t^(-1.5)*d*m)/(d+1))*
    exp( -(d/4)*( (t*(d+1))/(d*m) + (d*m)/(t*(d+1)) ) )
  fy
}

##########################################################
# Fun��o quantil da dist. Birnbaum-Saunders ##############

qRBS=function(q,m=1,d=1){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  if(q < 10^(-250)){resp = 0}
  else{
    q=(d*m/(d+1)) * (qnorm(q)/sqrt(2*d) + sqrt(1+(qnorm(q)/sqrt(2*d))^2))^2
  }
  q
}

##############################################################
# Fun��o para o Estimador pelo m�todo dos momentos modificados 
# da dist. Birnbaum-Saunders

modmeRBS = function(t){

th = mean(1/t)

mu = mean(t)

delta = 1/(sqrt(mu*th) - 1)
list(mu=mu,delta=delta)
}

# t = rRBS(30,m=10,d=10)
# modmeRBS(t)



##########################################################
# Fun��o para o EMM da dist. Birnbaum-Saunders ###########

mmeRBS = function(t){
mu = mean(t)

n = length(t)
s2 = (n-1)*var(t)/n

delta = ( mu^2 - s2 + sqrt(mu^4 + 3*s2*mu^2) )/s2
list(mu=mu,delta=delta)
}

# t = rRBS(30,m=10,d=10)
# mmeRBS(t)


###########################################################################
# Fun��o para a matriz de informa��o da dist. Birnbaum-Saunders ###########

# Fun��o para calcular integral da matriz de informa��o
Idt=function(m,d){
  if (any(m <= 0)) stop(paste("mu must be positive", "\n", ""))
  if (any(d <= 0)) stop(paste("delta must be positive", "\n", ""))
  f.Idt=function(t){
    exp(d/2)*
      sqrt((1+d)/(16*pi*m))*(t^(-1.5))*
      (t + (d*m)/(d+1))^(-1) *
      exp( -(d/4)*( t*(d+1)/(d*m) + d*m/(t*(d+1)) ) )
  }
  integrate(f.Idt,0,Inf)$value
}
  

##########################################################
# Fun��o para o EMV da dist. Birnbaum-Saunders ###########

mleRBS = function(y, n.iter=10){

# Derivadas da matriz de informa��o
dldm = function(mu,delta,y) sum( -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1)) )
d2ldm2 = function(mu,delta,y) length(y)*( -delta/(2*mu^2) - (delta^2)*Idt(mu,delta)/(delta+1)^2 )
dldd = function(mu,delta,y) sum( delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2) )
d2ldd2 = function(mu,delta,y) length(y)*( -(delta^2 + 3*delta + 1)/(2*(delta+1)^2 * delta^2) - (mu^2)*Idt(mu,delta)/((delta+1)^4) )
d2ldmdd = function(mu,delta,y) length(y)*( -1/(2*mu*(delta+1)) - delta*mu*Idt(mu,delta)/((delta+1)^3) )

# Vetor escore
VetEsc = function(mu,delta,y) c(dldm(mu,delta,y), dldd(mu,delta,y))

# Matriz de informa��o de Fisher
MatInf = function(mu, delta, y) -matrix(
c(d2ldm2(mu,delta,y),d2ldmdd(mu,delta,y),d2ldmdd(mu,delta,y),d2ldd2(mu,delta,y)),2,2)

# Palpite inicial
B0 = c(modmeRBS(y)$mu,modmeRBS(y)$delta) 

for(i in 1:n.iter){
B = B0 + solve(MatInf(B0[1],B0[2],y))%*%VetEsc(B0[1],B0[2],y)
B0 = B
}
list(mu=B0[1],delta=B0[2])
}

# t = rRBS(30,m=1,d=200)
# mleRBS(t,n.iter=20)




####################################################
# Modelos de regress�o Birnbaum-Saunders ###########


regRBS = function(y,Xev,n.it=20){

# Fun��o de liga��o logar�tmica
 g = function(x) log(x); dg = function(x) 1/x; gi = function(x) exp(x); d2g = function(x) -1/(x^2)

# Fun��o de liga��o raiz
# g = function(x) sqrt(x); dg = function(x) 1/(2*sqrt(x)); gi = function(x) x^2

# Fun��o de liga��o inversa
# g = function(x) 1/x; dg = function(x) -1/(x^2); gi = function(x) 1/x


# Pacote necess�rio para o ginv
require(MASS)

# Valores iniciais para beta
beta = lm(g(y)~Xev)$coef

# Valores iniciais para delta
delta = mleRBS(y)$delta

# Vetor de par�metros
theta = c(beta, delta)

# Matriz de modelo
X = cbind(rep(1,dim(as.matrix(Xev))[1]),as.matrix(Xev))

# Matriz de modelo aumentada
Xt = rbind(
cbind(X,rep(0,dim(X)[1])),
cbind(t(rep(0,dim(X)[2])),1)
)


# Itere��o de estima��o
for(i in 1:n.it){

# Vetor da m�dia
mu = gi(X%*%beta)

###############
z = -1/(2*mu) + delta/(delta*y+y+delta*mu) + (delta+1)*y/(4*mu^2) - (delta^2)/(4*y*(delta+1))
###############
b = delta/(2*(delta+1)) + (y+mu)/(delta*y+y+delta*mu) - y/(4*mu) - mu*delta*(delta+2)/(4*y*(delta+1)^2)
Db = diag(as.vector(b))
###############
a = 1/dg(mu)
Da = diag(as.vector(a))
###############
RIdt = sapply(mu, function(x) Idt(x,delta))
###############
v = delta/(2*(mu*dg(mu))^2) + (RIdt*delta^2)/(((delta+1)*dg(mu))^2)
Dv = diag(as.vector(v))
###############
s = 1/(2*mu*(delta+1)) + delta*mu*RIdt/(delta+1)^3
###############
u = (delta^2 + 3*delta + 1)/(2*(delta*(delta+1))^2) + (mu^2)*RIdt/(delta+1)^4
Du = diag(as.vector(u))
###############
Dab = rbind(
  cbind(Da,rep(0,dim(Da)[2])),
  cbind(t(rep(0,dim(Da)[1])),sum(diag(Db)))
)

# Matriz de pesos aumentada
W = rbind(
  cbind(Dv, Da%*%s),
  cbind(t(s)%*%Da, sum(diag(Du)))
)

###### Estima��o

# Vari�vel dependente
Z = Xt%*%theta + ginv(W)%*%Dab%*%rbind(z,1)
theta.n = ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%W%*%Z

# theta.n = theta + ginv(t(Xt)%*%W%*%Xt)%*%t(Xt)%*%Dab%*%rbind(z,1)
beta = theta.n[1:length(theta)-1]
delta = theta.n[length(theta)]
theta = theta.n 

}

###############
dmu2 = (1/(2*mu^2) - (delta^2)/(delta*y+y+delta*mu)^2 - y*(delta+1)/(2*mu^3))
cv = dmu2*(a^2) + z*a
Dc = diag(as.vector(cv))
###############
m = y/(delta*y+y+delta*mu)^2 + y/(4*mu^2) - delta*(delta+2)/(4*y*(delta+1)^2)
###############
d = 1/(2*(delta+1)^2) - ((y+mu)^2)/(delta*y+y+delta*mu)^2 - mu/(2*y*(delta+1)^3)
Dd = diag(as.vector(d))

# Matriz hessiana
L = rbind(
  cbind(t(X)%*%Dc%*%X, t(X)%*%Da%*%m),
  cbind(t(m)%*%Da%*%X, sum(diag(Dd)))
)


# Matriz de pertuba��o (pondera��o de casos)
Mat.Pert = rbind(
  t(X)%*%Da%*%diag(as.vector(z)),
  t(b)
)


# Matriz de vari�ncia-covari�ncia
K = ginv(t(Xt)%*%W%*%Xt)

# Res�duo do tipo Pearson padronizado
Vy = (mu^2)*(2*delta+5)/(delta+1)^2
resid = (y-mu)/sqrt(Vy)

return(list(beta = beta,delta = delta, vcov = K,
resid = resid, ajustados = mu, Mat.Hes = L, Mat.Pert = Mat.Pert))

}




