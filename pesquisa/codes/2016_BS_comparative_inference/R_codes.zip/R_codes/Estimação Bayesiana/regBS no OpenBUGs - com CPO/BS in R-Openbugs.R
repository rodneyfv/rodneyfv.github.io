############################################################
# Comandos da dist. Birnbaum-Saunders ##############
############################################################

source("Comandos BSR.R")

###########
# Exemplo
beta_1 = 2
beta_2 = 1.5
beta_3 = .5
delta_pop = 10
beta_pop = c(beta_1, beta_2, beta_3)

x1 = runif(30,0,1)
x2 = runif(30,1,3)
X = cbind(rep(1,30),x1,x2)

# Amostra RBS
y = sapply(X%*%beta_pop, function(x) rRBS(1, exp(x), delta_pop))

############################

setwd("C:/Users/Rodney/Documents/Pesquisa/Regress�o BS/Scripts/Estima��o Bayesiana/regBS no OpenBUGs - com CPO")
install.packages("R2OpenBUGS")
library(R2OpenBUGS)

N = length(y)
data = list("N","x1","x2","y")
inits = list(list(delta = 1,beta = c(1,1,1)))
parameters = c("beta","delta")



####	Gamma

result.gam = bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "MRBS.odc", n.chains = 1, n.iter = 10000,
 n.burnin = 1000)

result.gam$summary
names(result.gam)
dim(result.gam$sims.matrix)
head(result.gam$sims.matrix)

# CPO
sim.par.gam = result.gam$sims.matrix[,1:4]
dim(sim.par.gam)

sim.inv.gam = matrix(NA,dim(sim.par.gam)[1],N)
dim(sim.inv.gam)

# Fun��o para calcular a m�dia estimada
mu.estim = function(beta,x) exp(beta%*%x)

for(j in 1:N){
sim.inv.gam[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
y[j],mu.estim(sim.par.gam[,1:3],X[j,]),sim.par.gam[,4])
}

cpo.gam <- 1/apply(sim.inv.gam, 2, mean)

plot(1:N, cpo.gam, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml.gam <- sum(log(cpo.gam))
lpml.gam

# Kullback-Leibler divergence
KL.gam = -log(cpo.gam) + colMeans(log(1/sim.inv.gam))
plot(1:N, KL.gam, type = "h", xlab = "�ndice da observa��o", ylab = "K-L")
identify(1:N, KL.gam, n=6)

calib.gam = .5*(1+sqrt( 1-exp(-2*KL.gam) ))
plot(1:N, calib.gam, type = "h", xlab = "�ndice da observa��o", ylab = "calibra��o")

cbind(KL.gam,calib.gam)[c(4,10,13,15,22,23),]

################
####	Log-Normal

result.lnorm = bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "MRBS-lnorm.odc", n.chains = 1, n.iter = 10000,
 n.burnin = 1000)

result.lnorm$summary
names(result.lnorm)
dim(result.lnorm$sims.matrix)
head(result.lnorm$sims.matrix)

# CPO
sim.par.lnorm = result.lnorm$sims.matrix[,1:4]
dim(sim.par.lnorm)

sim.inv.lnorm = matrix(NA,dim(sim.par.lnorm)[1],N)
dim(sim.inv.lnorm)

# Fun��o para calcular a m�dia estimada
mu.estim = function(beta,x) exp(beta%*%x)

for(j in 1:N){
sim.inv.lnorm[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
y[j],mu.estim(sim.par.lnorm[,1:3],X[j,]),sim.par.lnorm[,4])
}
dim(sim.inv.lnorm)

cpo.lnorm <- 1/apply(sim.inv.lnorm, 2, mean)

# Gr�fico: CPO x �ndice (verifica qualidade de ajuste de cada observa��es)
plot(1:N, cpo.lnorm, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml.lnorm <- sum(log(cpo.lnorm))
lpml.lnorm

# Kullback-Leibler divergence
KL.lnorm = -log(cpo.lnorm) + colMeans(log(1/sim.inv.lnorm))
plot(1:N, KL.lnorm, type = "h", xlab = "�ndice da observa��o", ylab = "K-L")
identify(1:N, KL.lnorm, n=6)

calib.lnorm = .5*(1+sqrt( 1-exp(-2*KL.lnorm) ))
plot(1:N, calib.lnorm, type = "h", xlab = "�ndice da observa��o", ylab = "calibra��o")

cbind(KL.lnorm,calib.lnorm)[c(4,10,13,15,22,23),]



#############################################
# Models comparison using pseudo-Bayes factor

# Gamma vs. Log-Normal
prod(cpo.gam)/prod(cpo.lnorm)		#indica que modelo teve o melhor ajuste

prod(cpo.gam)/prod(cpo.lnorm)

log(prod(cpo.gam)/prod(cpo.lnorm))
lpml.gam - lpml.lnorm

# Gr�fico para verificar qual modelo ajustou melhor cada observa��es
plot(1:N, log(cpo.gam/cpo.lnorm),
type = "h", xlab = "�ndice da observa��o", ylab = "log(cpo.gam/cpo.lnorm)")



