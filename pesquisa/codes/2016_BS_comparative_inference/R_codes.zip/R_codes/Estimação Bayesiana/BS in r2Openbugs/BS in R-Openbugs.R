
############################
setwd("C:/Users/Rodney/Documents/Pesquisa/Regress�o BS/Scripts/Estima��o Bayesiana/BS in r2Openbugs")
install.packages("R2OpenBUGS")
library(R2OpenBUGS)

x = round(rRBS(30,1,1),2)

N = length(x)
data = list("N","x")
inits = list(list(delta = 2,mu = 2))
parameters = c("mu","delta")


####	Uniform

result.unif = bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "unif.odc", n.chains = 1, n.iter = 10000,
 n.burnin = 1000)

result.unif$summary

# CPO
sim.par.unif = result.unif$sims.matrix[,1:2]
dim(sim.par.unif)

sim.inv.unif = matrix(NA,dim(sim.par.unif)[1],N)
dim(sim.inv.unif)

for(j in 1:N){
sim.inv.unif[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
x[j],sim.par.unif[,1],sim.par.unif[,2])
}

cpo.unif <- 1/apply(sim.inv.unif, 2, mean)

plot(1:N, cpo.unif, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml.unif <- sum(log(cpo.unif))
lpml.unif


####	Gamma

result.gam = bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "gamma.odc", n.chains = 1, n.iter = 10000,
 n.burnin = 1000)

result.gam$summary

# CPO
sim.par.gam = result.gam$sims.matrix[,1:2]
dim(sim.par.gam)

sim.inv.gam = matrix(NA,dim(sim.par.gam)[1],N)
dim(sim.inv.gam)

for(j in 1:N){
sim.inv.gam[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
x[j],sim.par.gam[,1],sim.par.gam[,2])
}

cpo.gam <- 1/apply(sim.inv.gam, 2, mean)

plot(1:N, cpo.gam, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml.gam <- sum(log(cpo.gam))
lpml.gam


####	Gamma and Inverse-Gamma

result.invgam = bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "gam-invgam.odc", n.chains = 1, n.iter = 5000,
 n.burnin = 1000)

result.invgam$summary

# CPO
sim.par.invgam = result.invgam$sims.matrix[,1:2]
dim(sim.par.invgam)

sim.inv.invgam = matrix(NA,dim(sim.par.invgam)[1],N)
dim(sim.inv.invgam)

for(j in 1:N){
sim.inv.invgam[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
x[j],sim.par.invgam[,1],sim.par.invgam[,2])
}

cpo.invgam <- 1/apply(sim.inv.invgam, 2, mean)

plot(1:N, cpo.invgam, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml.invgam <- sum(log(cpo.invgam))
lpml.invgam


####	Log-Normal

result.lnorm = bugs(data = data, inits = inits, parameters.to.save = parameters,
 model.file = "lnorm.odc", n.chains = 1, n.iter = 10000,
 n.burnin = 1000)

result.lnorm$summary

# CPO
sim.par.lnorm = result.lnorm$sims.matrix[,1:2]
dim(sim.par.lnorm)

sim.inv.lnorm = matrix(NA,dim(sim.par.lnorm)[1],N)
dim(sim.inv.lnorm)

for(j in 1:N){
sim.inv.lnorm[,j] = mapply(function(x,m,d) 1/dRBS(x,m,d),
x[j],sim.par.lnorm[,1],sim.par.lnorm[,2])
}

cpo.lnorm <- 1/apply(sim.inv.lnorm, 2, mean)

plot(1:N, cpo.lnorm, type = "h", xlab = "�ndice da observa��o", ylab = "CPO")

lpml.lnorm <- sum(log(cpo.lnorm))
lpml.lnorm


# Models comparison using pseudo-Bayes factor

# Uniform vs. Gamma
prod(cpo.unif)/prod(cpo.gam)
log(prod(cpo.unif)/prod(cpo.gam))
lpml.unif/lpml.gam

# Uniform vs. Gamma and Inv-gamma
prod(cpo.unif)/prod(cpo.invgam)

# Uniform vs. Log-Normal
prod(cpo.unif)/prod(cpo.lnorm)
log(prod(cpo.unif)/prod(cpo.lnorm))
lpml.unif/lpml.lnorm

# Gamma vs. Log-Normal
prod(cpo.gam)/prod(cpo.lnorm)
log(prod(cpo.gam)/prod(cpo.lnorm))
lpml.gam/lpml.lnorm

require(xtable)
xtable(result.lnorm$summary)
xtable()



