##########################################################################
##########################################################################

# As seguintes funções são permitem ajustar um modelo ACS-BS a um conjunto
# de dados de durações, além de fornecer funções para cálculos de estatísticas
# descritivas, análise de resíduos, etc.

##########################################################################
# Funções para o BS-ACD(1,1)

# install.packages("numDeriv")
require(numDeriv)
require(maxLik)

# gerador de ocorrências aleatórias da BS
rbs = function(n,kap,sig){
  z = rnorm(n,0,1)
  t = sig*(.5*kap*z + sqrt((.5*kap*z)^2 + 1))^2
  return(t)
}

# fun??o de distribui??o BS
pbs = function(x,kap,sig){
  z = pnorm((sqrt(x/sig) - sqrt(sig/x))/kap)
  return(z)
}

# fun??o de distribui??o BS
dbs = function(x,kap,sig){
  t = (sqrt(x/sig) - sqrt(sig/x))/kap
  d = ((sig/x)^.5 + (sig/x)^1.5)*exp(-.5*(t^2))/
    (2*kap*sig*sqrt(2*pi))
  return(d)
}

# gerador de ocorrências de um modelo BS-ACD(1,1)
rbs.acd11 = function(n,a,b1,g1,kap){
  sig = x = rep(1,n+1)
  epsilon = rbs(n+1,kap,1)
  
  sig[1] = exp(a)
  x[1] = sig[1]*epsilon[1]
  for(i in 2:(n+1)){
    sig[i] = exp(a + b1*log(sig[i-1]) + g1*x[i-1]/sig[i-1])
    x[i] = sig[i]*epsilon[i]
  }
  return(x[2:(n+1)])
}

# Função de log-verossimilhança para estimação de um modelo BS-ACD(1,1)
# os dados precisam ser armazenados em um vetor chamado data
l1_bs.acd11 = function(theta){
  # parâmetros do modelo
  a = theta[1]
  b = theta[2]
  g = theta[3]
  kap = theta[4]
  # tamanho amostral
  n = length(data)
  l = sig = rep(1,n)
  # obtendo recursivamente as medianas
  sig[1] = exp(a)
  for(i in 2:n){
    sig[i] = exp(a + b*log(sig[i-1]) + g*data[i-1]/sig[i-1])
  }
  # Função de verossimilhança
  L = -log(2*sqrt(2*pi)) - log(kap) - log(sig) + 
    log((sig/data)^.5 + (sig/data)^1.5) - 
    (1/(2*kap^2))*(data/sig + sig/data - 2)
  # função de log-verossimilhança
  l = sum(L[2:n])
  return(l)
}
# essa função fornece a função de log-verossimilhança com sinal trocado
# para ser usada com a função optim
l2_bs.acd11 = function(theta){-l1_bs.acd11(theta)}

# função que retorna as durações medianas estimadas
# o argumento theta deve ter os valores dos parametros ACD:a,b e g
sig_acd11 = function(x,theta){
  a = theta[1]
  b = theta[2]
  g = theta[3]
  
  n = length(x)
  sig = rep(1,n)
  
  sig[1] = exp(a)
  for(i in 2:n){
    sig[i] = exp(a + b*log(sig[i-1]) + g*x[i-1]/sig[i-1])
  }
  return(sig)
}

# Fun??o para calcular os res?duos GCS
cs.resid_bs.acd11 = function(x,theta){
  n = length(x)
  ecs = rep(1,n-1)
  kap = theta[4]
  sig_hat = sig_acd11(x,theta)
  # gerando os res?duos com a fun??o de sobreviv?ncia estimada
  for(i in 2:n) ecs[i-1] = -log(1-pbs(x[i],kap,sig_hat[i]))
  return(ecs)
}

# função que calcula estatísticas descritivas das estimativas obtidas
# true.par é o verdadeiro valor do parâmetro estimado
mc_stats = function(x,true.par){
  n = length(x)
  # média
  m1 = mean(x)
  # assimetria
  m3 = mean((x - m1)^3)*sqrt(n*(n-1))/((n-2)*mean((x - m1)^2)^1.5)
  # curtose
  m4 = mean((x - m1)^4)/mean((x - m1)^2)^2
  # viés
  B = mean(x-true.par)
  # erro quadrático médio
  MSE = var(x) + B^2
  # quantis 1% e 99%
  q01 = quantile(x,.01)
  q99 = quantile(x,.99)
  return(list(m1=m1,m3=m3,m4=m4,B=B,MSE=MSE,
              q01=q01,q99=q99))
}


# função que calcula estatísticas descritivas das durações
duration_stats = function(x){
  n = length(x)
  # média
  m1 = mean(x)
  # assimetria
  m3 = mean((x - m1)^3)*sqrt(n*(n-1))/((n-2)*mean((x - m1)^2)^1.5)
  # curtose
  m4 = mean((x - m1)^4)/mean((x - m1)^2)^2
  # mínimo
  Min = min(x)
  # máximo
  Max = max(x)
  # mediana
  Med = median(x)
  # desvio padrão
  DP = sd(x)
  # coeficiente de variação
  CV = DP/m1
  return(list(n=n,min=Min,med=Med,m1=m1,max=Max,dp=DP,cv=CV,
              m3=m3,m4=m4))
}

# função que retorna valores da transformada pela função distribuição,
# para análise de performance de previsão fora da amostra
# x representa a amostra completa, em que as k primeiras observações
# foram utilizadas para ajustar o modelo parametrizado por theta
forecast_bs.acd11 = function(x,k,theta){
  a = theta[1]
  b = theta[2]
  g = theta[3]
  kap = theta[4]
  
  n = length(x)
  sig = rep(1,n)
  z = rep(0,n-k)
  # obtendo as medianas condicionais da amostra de treino(k primeiras observações)
  sig[1] = exp(a)
  for(i in 2:k){
    sig[i] = exp(a + b*log(sig[i-1]) + g*x[i-1]/sig[i-1])
  }
  # obtendo os valores da transformada pela função distribuição
  # e as medianas condicionais da amostra de teste
  for(i in (k+1):n){
    z[i - k] = pbs(x[i-1],kap,sig[i-1])
    sig[i] = exp(a + b*log(sig[i-1]) + g*x[i-1]/sig[i-1])
  }
  
  return(list(z=z, sig=sig))
}


##########################################################################
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
##########################################################################
# Funcoes para o GBS2-ACD(1,1)
##########################################################################


# Gerador de ocorrencias aleatorias do modelo GBS2(a,b,nu)
rgbs2 = function(n,a=1,b=1,nu=1){
  z = rnorm(n)
  t = b*((.5*a*z) + sqrt((.5*a*z)^2 + 1))^(1/nu)
  return(t)
}

# funcao densidade do modelo GBS2(a,b,nu)
dgbs2 = function(t,a=1,b=1,nu=1){
  nu*((t/b)^nu + (b/t)^nu)*exp(-.5*((t/b)^(2*nu) + (b/t)^(2*nu) - 2)/(a^2))/
    (t*a*sqrt(2*pi))
}

# funcao distribuicao do modelo GBS2(a,b,nu)
pgbs2 = function(t,a=1,b=1,nu=1){
  pnorm(((t/b)^nu - (b/t)^nu)/a)
}

#funcao taxa de falha da distribuicao GBS2
hrgbs2 = function(t,a=1,b=1,nu=1){
  dgbs2(t,a,b,nu)/(1 - pgbs2(t,a,b,nu))
}

# gerador de ocorrencias de um modelo GBS2-ACD(1,1)
rgbs2.acd11 = function(n,a,b,g,kap,nu){
  sig = x = rep(1,n+1)
  epsilon = rgbs2(n+1,kap,1,nu)
  
  sig[1] = exp(a)
  x[1] = sig[1]*epsilon[1]
  for(i in 2:(n+1)){
    sig[i] = exp(a + b*log(sig[i-1]) + g*x[i-1]/sig[i-1])
    x[i] = sig[i]*epsilon[i]
  }
  return(x[2:(n+1)])
}

# Funcao de log-verossimilhanca para estimacao de um modelo GBS2-ACD(1,1)
# os dados precisam ser armazenados em um vetor chamado data
l1_gbs2.acd11 = function(theta){
  # parametros do modelo
  a = theta[1]
  b = theta[2]
  g = theta[3]
  kap = theta[4]
  nu = theta[5]
  # tamanho amostral
  n = length(data)
  l = sig = rep(1,n)
  # obtendo recursivamente as medianas
  sig[1] = exp(a)
  for(i in 2:n){
    sig[i] = exp(a + b*log(sig[i-1]) + g*data[i-1]/sig[i-1])
  }
  # Funcao de verossimilhanca
  L = log(nu) - log(data) - log(kap) + log((data/sig)^nu + (sig/data)^nu) -
    (.5/(kap^2))*((data/sig)^(2*nu) + (sig/data)^(2*nu) - 2) -
    log(sqrt(2*pi))
  # funcao de log-verossimilhanca
  l = sum(L[2:n])
  return(l)
}
# essa funcao fornece a funcao de log-verossimilhanca com sinal trocado
# para ser usada com a funcao optim
l2_gbs2.acd11 = function(theta){-l1_gbs2.acd11(theta)}

# Funcao para calcular os residuos GCS no modelo GBS2-ACD(1,1)
cs.resid_gbs2.acd11 = function(x,theta){
  n = length(x)
  ecs = rep(1,n-1)
  kap = theta[4]
  nu = theta[5]
  sig_hat = sig_acd11(x,theta)
  # gerando os residuos com a funcao de sobrevivencia estimada
  for(i in 2:n) ecs[i-1] = -log(1-pgbs2(x[i],kap,sig_hat[i],nu))
  return(ecs)
}

# função que retorna valores da transformada pela função distribuição,
# para análise de performance de previsão fora da amostra
# x representa a amostra completa, em que as k primeiras observações
# foram utilizadas para ajustar o modelo parametrizado por theta
forecast_gbs2.acd11 = function(x,k,theta){
  a = theta[1]
  b = theta[2]
  g = theta[3]
  kap = theta[4]
  nu = theta[5]
  
  n = length(x)
  sig = rep(1,n)
  z = rep(0,n-k)
  # obtendo as medianas condicionais da amostra de treino(k primeiras observações)
  sig[1] = exp(a)
  for(i in 2:k){
    sig[i] = exp(a + b*log(sig[i-1]) + g*x[i-1]/sig[i-1])
  }
  # obtendo os valores da transformada pela funcao distribuicao
  # e as medianas condicionais da amostra de teste
  for(i in (k+1):n){
    z[i - k] = pgbs2(x[i-1],kap,sig[i-1],nu)
    sig[i] = exp(a + b*log(sig[i-1]) + g*x[i-1]/sig[i-1])
  }
  
  return(list(z=z, sig=sig))
}