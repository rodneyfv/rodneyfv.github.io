##########################################################################


library(foreign)
require(ACDm)
require(ADGofTest)
source("Funcoes ACD-GBS2.R")
source("GBS2 GAS functions.R")
source("BS GAS functions.R")


slb_data <- read.dbf("slb_trades.dbf")
head(slb_data)

slb_dur = slb_data$X
slb_dur[1:10]
slb_dur2 = slb_dur[(slb_dur = slb_data$hour>=10)&(slb_dur = slb_data$hour<=15)]
slb_dur2[1:10]
length(slb_dur2)

# serie das duracoes
plot(slb_dur2,type='l')
# histograma
hist(slb_dur2)
# autocorrelacao da serie original das duracoes
acf(slb_dur2)

# estatisticas descritivas das duracoes originais
duration_stats(slb_dur2)

######################
# Retirando a tedencia diaria das duracoes como indicado por Bhatti(2010)

# duracoes
slb_dur = slb_data$X
length(slb_dur)
# indicadores espacados em 30min do horario das transacoes 
vt = c(9, 10.1, 10.2, 11.1, 11.2, 12.1, 12.2, 13.1, 13.2, 14.1, 14.2, 15.1, 15.2)
# variavel criada com os indicadores espacados em 30min do horario das transacoes
time_ind = rep(0,length(slb_dur))
for(i in 1:length(slb_dur)){
  # o indice do termo de "vt" igual a "slb_data$half[i]" e armazenado em j,
  # por exemplo, pra "slb_data$half[i]=9", j sera igual a 1
  j = which(slb_data$half[i]==vt)
  # armazenando o inficador do horario em que a transacao foi realizada
  time_ind[i] = j-1
}

# variavel com o log das duracoes
slb_logdur = log(slb_dur)
# modelo nao-parmatrico para capturar as tedencias diarias usando como
# variavel resposta o log das duracoes e usando indicadores dos horarios
# das duracoes
mod = smooth.spline(time_ind,slb_logdur, spar=0)

# Valor ajustado(previsto) das log-duracoes
pred = predict(mod,time_ind)

# obtendo as duracoes ajustadas dividindo as duracoes pela exponencial
# do componente de sazonalidade estimado
slb_dur_aj = slb_dur/exp(pred$y)
# obtendo somente as transacoes realizadas entre 10:00 e 16:00hrs
slb_dur_aj = slb_dur_aj[(slb_dur = slb_data$hour>=10)&(slb_dur = slb_data$hour<=15)]
#write.table(slb_dur_aj,"slb_dur_aj.mat",row.names = FALSE, col.names = FALSE, sep = ",")
# estatistica descritiva das duracoes ajustadas
duration_stats(slb_dur_aj)

plot(slb_dur_aj,type="l")
hist(slb_dur_aj)
acf(slb_dur_aj,ylim=c(-.05,.1))

#####################################################
## Estimando o modelo GBS2 GAS(1,1)
#####################################################

length(slb_dur_aj)
N = length(slb_dur_aj)
GASdata = slb_dur_aj[1:N]
p = 1; q = 1
p.fixed = c(1); q.fixed = c(1); m = max(max(p.fixed),max(q.fixed))
beta0 = median(slb_dur_aj)
#sqrt(2*(mean(slb_dur_aj)/median(slb_dur_aj) - 1))
theta0 = c(0.0001718646,0.0212007343,0.9905844804,1.5535913368,0.6345437272)

grad_gbs2gas(theta0,p,q,beta0,p.fixed,q.fixed)
loglik_gbs2gas(theta0,p,q,beta0)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0

mod_gbs2_gas = optim(theta0,loglik_gbs2gas_optim,grad_gbs2gas_optim,method="BFGS")
mod_gbs2_gas$convergence
mod_gbs2_gas$par
# estimates already obtained with mod_gbs2_gas
theta_gbs2_gas = c(0.0001785956, 0.0212006790, 0.9905844766, 1.5535910980, 0.6345445327)

H_gbs2_gas = hessian_gbs2gas(theta_gbs2_gas,p,q,beta0,p.fixed,q.fixed)
sqrt(-diag(solve(H_gbs2_gas)))
#U_gbs2_gas = grad_gbs2gas(theta_gbs2_gas,p,q,beta0,p.fixed,q.fixed)
#sqrt(diag(solve(H_gbs2_gas)%*%(U_gbs2_gas%*%t(U_gbs2_gas))%*%solve(H_gbs2_gas)))
theta_gbs2_gas

L_gbs2_gas = loglik_gbs2gas(theta_gbs2_gas,p,q,beta0)
-2*L_gbs2_gas + 2*length(theta_gbs2_gas)
-2*L_gbs2_gas + log(length(slb_dur_aj))*length(theta_gbs2_gas)


mod_gbs2_gas.comp = comp_gbs2gas(theta_gbs2_gas,p,q,beta0,p.fixed,q.fixed)
plot(GASdata[(m+1):N],type='l')
lines(mod_gbs2_gas.comp$beta_t[(m+1):N],type='l',col=2)

acf_cs_gbs_gas = acf(mod_gbs2_gas.comp$res.gcs[(m+1):N], lag.max = 60,ylim=c(-.05,.1))
Box.test(mod_gbs2_gas.comp$res.gcs[(m+1):N], lag = 24, type="Ljung-Box")
Box.test((mod_gbs2_gas.comp$res.gcs[(m+1):N])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gbs2_gas.comp$res.gcs[(m+1):N],"pexp")
max(acf_cs_gbs_gas$acf[2:61])
min(acf_cs_gbs_gas$acf[2:61])
mean(acf_cs_gbs_gas$acf[2:16])

#####################################################
## Estimando o modelo BS GAS(1,1)
#####################################################

theta0 = c(0.00008601, 0.02374258, 0.98931132, 1.14831796)

mod_bs_gas = optim(theta0,loglik_bsgas_optim,grad_bsgas_optim,method="BFGS")
mod_bs_gas$convergence
mod_bs_gas$par

# estimates already obtained with mod_gbs2_gas
theta_bs_gas = c(0.00008601, 0.02374258, 0.98931132, 1.14831796)

H_bs_gas = hessian_bsgas(theta_bs_gas,p,q,beta0,p.fixed,q.fixed)
sqrt(-diag(solve(H_bs_gas)))
round(sqrt(-diag(solve(H_bs_gas))),4)
round(theta_bs_gas,3)
#U_bs_gas = grad_bsgas(theta_bs_gas,p,q,beta0,p.fixed,q.fixed)
#sqrt(diag(solve(H_bs_gas)%*%(U_bs_gas%*%t(U_bs_gas))%*%solve(H_bs_gas)))

L_bs_gas = loglik_bsgas(theta_bs_gas,p,q,beta0); -L_bs_gas
-2*L_bs_gas + 2*length(theta_bs_gas)
-2*L_bs_gas + log(length(slb_dur_aj))*length(theta_bs_gas)


mod_bs_gas.comp = comp_bsgas(theta_bs_gas,p,q,beta0,p.fixed,q.fixed)
plot(GASdata[(m+1):N],type='l')
lines(mod_bs_gas.comp$beta_t[(m+1):N],type='l',col=2)

# GCS residuals autocorrelations up to lag 60
acf_cs_bs_gas = acf(mod_bs_gas.comp$res.gcs[(m+1):N], lag.max = 60,ylim=c(-.05,.1))
Box.test(mod_bs_gas.comp$res.gcs[(m+1):N], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gcs[(m+1):N])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gcs[(m+1):N],"pexp")
# Mean, max and min of the autocorrelations
round(max(acf_cs_bs_gas$acf[2:61]),3)
round(min(acf_cs_bs_gas$acf[2:61]),3)
round(mean(abs(acf_cs_bs_gas$acf[2:16])),3)

#####################################################
## Estimando o modelo BS-ACD(1,1)
#####################################################

# storing  the slb data in the data variable
data = slb_dur_aj
# valores iniciais
#theta0 = c(-.02, .97, .01, sqrt(2*(mean(slb_dur_aj)/median(slb_dur_aj) - 1)))
theta0 = c(-0.020635, 0.97946, 0.012596, 1.1484)

# impondo restrição para kap>0
A = matrix(c(0,0,0,1),1,4)
B = 0
mod_bs_acd = maxLik(l1_bs.acd11, start=theta0,
                    constraints=list(ineqA=A,ineqB=B))
mod_bs_acd
summary(mod_bs_acd)
mod_bs_acd$estimate
#theta_bs = mod_bs_slb$estimate
theta_bs_acd = c(-0.020635, 0.97946, 0.012596, 1.1484)

# obtendo erros-padrao para as estimativas numericamente
names(mod_bs_acd)
H_bs_acd = mod_bs_acd$hessian
sqrt(diag(solve(-H_bs_acd)))
round(theta_bs_acd,3)
round(sqrt(diag(solve(-H_bs_acd))),4)
#U_bs_acd = mod_bs_acd$gradient
# Erros-padrao pela matriz de covariancia robusta
#WC = solve(H_bs_acd)%*%(U_bs_acd%*%t(U_bs_acd))%*%solve(H_bs_acd)
#sqrt(diag(WC))

# obtendo os psi's estimados
psi_hat_bs_acd = sig_acd11(slb_dur_aj,theta_bs_acd)
# residuos estimados e grafico de autocorrelacao
epsilon_hat_bs_acd = slb_dur_aj/psi_hat_bs_acd
acf(epsilon_hat_bs_acd,ylim=c(-.05,.1))
# grafico dos residuos padronizados
plot(epsilon_hat_bs_acd,type='l')

# obtendo os residuos de Cox-Snell generalizados
ecs_bs_acd = cs.resid_bs.acd11(slb_dur_aj,theta_bs_acd)
mean(ecs_bs_acd)  # media deve ser proxima de 1
# grafico dos residuos em funcao do tempo
plot(ecs_bs_acd,type='h')
abline(h=qexp(.95,1),col=2)
sum(ecs_bs_acd>qexp(.95,1))/length(ecs_bs_acd)
# espera-se que aprox. 5% dos residuos estejam acima do quantil
# 0.95 da Exp(1)

# autocorrelacoes ate o lag 60 dos residuos ecs
acf_cs_bs_acd = acf(ecs_bs_acd, lag.max = 60,ylim=c(-.05,.1))
# comparando os quantis dos residuos ecs com os da Exponencial(1)
round(quantile(ecs_bs_acd, c(.01,.05,.1,.25,.5,.75,.9,.95,.99)),3)
round(qexp(c(.01,.05,.1,.25,.5,.75,.9,.95,.99)),3)
# testando independencia das duracoes dessazonalizadas ate lag 15
Box.test(slb_dur_aj, lag = 15, type = "Ljung",fitdf = 3)
# testando independencia dos residuos ajustados ate lag 15
Box.test(epsilon_hat_bs_acd, lag = 15, type = "Ljung",fitdf = 3)
# testando independencia dos residuos ecs ate lag 15
Box.test(ecs_bs_acd, lag = 15, type = "Ljung",fitdf = 3)
round(max(acf_cs_bs_acd$acf[2:61]),3)
round(min(acf_cs_bs_acd$acf[2:61]),3)
round(mean(abs(acf_cs_bs_acd$acf[2:16])),3)
# AIC
-2*l1_bs.acd11(theta_bs_acd) + 2*length(theta_bs_acd)
# BIC
-2*l1_bs.acd11(theta_bs_acd) + log(length(slb_dur_aj))*length(theta_bs_acd)


