# Código para analisar modelos estimados no Ox

###################
source("GBS2 GAS functions.R")
source("BS GAS functions.R")
source("Gama GAS functions.R")
require(tseries)
require(WeightedPortTest)

###################
# Streamflow data

#dados0 = read.table("paraibuna.txt",dec=",")
dados0 = read.table("paraibunaONS.txt",dec=",")
dim(dados0)
dados0vec = matrix(t(as.matrix(dados0[,2:13])),ncol=1,nrow=34*12)
dados0vec.ts = ts(dados0vec,start=c(1976,1),frequency=12)

hist(dados0vec,prob=TRUE,n=20)
boxplot(dados0[,2:13],c(1:12))

#write.table(dados0vec,file="paraibunaONS.mat",sep=",",dec=".",row.names = FALSE,col.names = FALSE)
#length(dados0vec)
dadosTreino = dados0vec[1:(32*12-5)]
dadosTeste = dados0vec[(32*12-5+1):(34*12-5)]
plot(c(dadosTreino,dadosTeste),type='l')
abline(v=(32*12-5),lty=2,col=3)
acf(dadosTreino)

###################################################
#     Fitting a GBS2-GAS(p,q)
###################################################

# best up to now: p.fixed = c(1,12) and q.fixed = c(1,6,11)
GASdata = dadosTreino
p = 3; q = 5
p.fixed = c(1,3,13);q.fixed = c(1,2,3,11,12);m=max(max(p.fixed),max(q.fixed))
theta_hat_gbs2 = c(-0.21071,      0.56929,      0.23270,     -0.31613,      0.36349,     -0.33948,      0.18628,      0.17977,
                   0.65995,    0.0033195,    0.0065231)

beta0 = c(103, 105,  92,  76,  59,  55,  46,  42 , 47,  50,  56 , 71, 103, 105)


H_gbs_gas = hessian_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed)
U_gbs_gas = grad_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed)
round(theta_hat_gbs2,4)
round(sqrt(diag(solve(-H_gbs_gas))),4)

L_gbs_gas = loglik_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed)
-2*L_gbs_gas+2*length(theta_hat_gbs2)
-2*L_gbs_gas+log(length(GASdata))*length(theta_hat_gbs2)


mod_gbs_gas.comp = comp_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_gbs_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_gbs_gas.comp$res.quant[m:379])
Box.test(mod_gbs_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_gbs_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_gbs_gas.comp$res.gcs[m:379])
Box.test(mod_gbs_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gbs_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gbs_gas.comp$res.gcs[m:379],"pexp")
# GBS2 residuals
acf(mod_gbs_gas.comp$res.gbs[m:379])
Box.test(mod_gbs_gas.comp$res.gbs[m:379], lag = 25, type="Ljung-Box")
Box.test((mod_gbs_gas.comp$res.gbs[m:379])^2, lag = 25, type="Ljung-Box")
ks.test(mod_gbs_gas.comp$res.gbs[m:379],"pnorm")

# Performing the Ljung-Box test
Q_LB = Weighted.Box.test(mod_gbs_gas.comp$res.gbs[m:379], lag=25, type="Ljung",weighted = FALSE)
Q_LB$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))
# Performing the Monti test
Q_M = Weighted.Box.test(mod_gbs_gas.comp$res.gbs[m:379], lag=25, type="Monti",weighted = FALSE)
Q_M$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))

set.seed(2017)
########
# predictions for the test set 24 steps ahead (out of sample)
GASdata = c(dadosTreino)
mod_gbs_gas.comp = comp_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed)
prev24_gbs_gas = forecast_gbs2gas(theta_hat_gbs2,p,q,p.fixed,q.fixed,
                        GASdata[360:379],mod_gbs_gas.comp$beta_t[360:379],
                        n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev24_gbs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev24_gbs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev24_gbs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev24_gbs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev24_gbs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev24_gbs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev24_gbs_gas$ypred.median)/(dadosTeste + prev24_gbs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev24_gbs_gas$ypred.median)^2
# MAPE
100*mean(abs(dadosTeste - prev24_gbs_gas$ypred.median)/(prev24_gbs_gas$ypred.median))

########
# predictions for the test set 24 steps ahead (out of sample)
# using the forecast2_gbs2gas function
# In this function, the predictions are
# obtained through parametric bootstrap method and using the method 
# proposed by Blasques et al (2016) to take considering both parameter
# and innovation uncertainty of the GAS parameters.
GASdata = c(dadosTreino)
mod_gbs_gas.comp = comp_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed)
prev2_24_gbs_gas = forecast2_gbs2gas(theta_hat_gbs2,p,q,beta0,p.fixed,q.fixed,
                                  n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev2_24_gbs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev2_24_gbs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev2_24_gbs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev2_24_gbs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev2_24_gbs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median)/(dadosTeste + prev2_24_gbs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev2_24_gbs_gas$ypred.median)^2
# MAPE
100*mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median)/(prev2_24_gbs_gas$ypred.median))


###################################################
#     Fitting a BS-GAS(p,q)
###################################################

# best up to now: p.fixed = c(1,12) and q.fixed = c(1,6,11)
GASdata = dadosTreino
p = 3; q = 5
p.fixed = c(1,3,13);q.fixed = c(1,2,3,11,12);m=max(max(p.fixed),max(q.fixed))
theta_hat_bs = c(-0.20567,0.56283,0.23254,-0.31010,0.36025,-0.33667,0.18415,0.17938,
                 0.66165,0.25732)
beta0 = c(103, 105,  92,  76,  59,  55,  46,  42 , 47,  50,  56 , 71, 103, 105)

H_bs_gas = hessian_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed)
U_bs_gas = grad_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed)
sqrt(diag(solve(H_bs_gas)%*%(U_bs_gas%*%t(U_bs_gas))%*%solve(H_bs_gas)))
sqrt(diag(solve(-H_bs_gas)))
round(theta_hat_bs,4)
round(sqrt(diag(solve(-H_bs_gas))),4)

L_bs_gas = loglik_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed)
-2*L_bs_gas+2*length(theta_hat_bs)
-2*L_bs_gas+log(length(GASdata))*length(theta_hat_bs)
# Hypothesis test of H0:nu=0.5 against H1:nu!=0.5
2*(L_gbs_gas - L_bs_gas)  #test statistic
1 - pchisq(2*(L_gbs_gas - L_bs_gas),1)  # p-value

mod_bs_gas.comp = comp_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_bs_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_bs_gas.comp$res.quant[m:379])
Box.test(mod_bs_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_bs_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_bs_gas.comp$res.gcs[m:379])
Box.test(mod_bs_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gcs[m:379],"pexp")
# GBS residuals
acf(mod_bs_gas.comp$res.gbs[m:379])
Box.test(mod_bs_gas.comp$res.gbs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gbs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gbs[m:379],"pnorm")
jarque.bera.test(mod_bs_gas.comp$res.gbs[m:379])
qqnorm(mod_bs_gas.comp$res.gbs[m:379])
qqline(mod_bs_gas.comp$res.gbs[m:379])

envel_res.gbs = read.table("ResGBSenvel_BSGAS.txt",header=FALSE)
dim(envel_res.gbs)
norm_TheoQuant = qnorm(ppoints(length(mod_bs_gas.comp$res.gbs[(m+1):379])))
plot(norm_TheoQuant,sort(mod_bs_gas.comp$res.gbs[(m+1):379]))
lines(norm_TheoQuant,envel_res.gbs[,2],type='l',lty=2)
lines(norm_TheoQuant,envel_res.gbs[,1],type='l',lty=1,col=1)
lines(norm_TheoQuant,envel_res.gbs[,3],type='l',lty=1,col=1)
cov_envel_res = (sort(mod_bs_gas.comp$res.gbs[(m+1):379])>envel_res.gbs[,1])*(sort(mod_bs_gas.comp$res.gbs[(m+1):379])<envel_res.gbs[,3])
mean(cov_envel_res)

# Performing the Ljung-Box test
Q_LB = Weighted.Box.test(mod_bs_gas.comp$res.gbs[m:379], lag=25, type="Ljung",weighted = FALSE)
Q_LB$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))
# Performing the Monti test
Q_M = Weighted.Box.test(mod_bs_gas.comp$res.gbs[m:379], lag=25, type="Monti",weighted = FALSE)
Q_M$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))


set.seed(2017)
########
# predictions for the test set 24 steps ahead (out of sample)
GASdata = c(dadosTreino)
mod_bs_gas.comp = comp_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed)
prev24_bs_gas = forecast_bsgas(theta_hat_bs,p,q,p.fixed,q.fixed,
                            GASdata[360:379],mod_bs_gas.comp$beta_t[360:379],
                            n.ahead=24,Brep=5000)
plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev24_bs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev24_bs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev24_bs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev24_bs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev24_bs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev24_bs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev24_bs_gas$ypred.median)/(dadosTeste + prev24_bs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev24_bs_gas$ypred.median)^2
# MAPE
100*mean(abs(dadosTeste - prev24_bs_gas$ypred.median)/(prev24_bs_gas$ypred.median))

########
# predictions for the test set 24 steps ahead (out of sample)
# using the forecast2_bsgas function 
GASdata = c(dadosTreino)
mod_bs_gas.comp = comp_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed)
prev2_24_bs_gas = forecast2_bsgas(theta_hat_bs,p,q,beta0,p.fixed,q.fixed,
                                  n.ahead=24,Brep=5000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev2_24_bs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev2_24_bs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev2_24_bs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev2_24_bs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev2_24_bs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev2_24_bs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev2_24_bs_gas$ypred.median)/(dadosTeste + prev2_24_bs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev2_24_bs_gas$ypred.median)^2


###########################

# Preparing plots for the text

postscript(file="vazoes_serie_fac.ps",horizontal=FALSE, width=8.0, height=10.0,
           paper="special")
par(mfrow=c(3,1))
plot(dados0vec,xlab="Time",ylab="",main="",sub="(a)",cex.lab=1.5,
     cex.axis=1.5,cex.sub=1.5,type="l")
axis(2,150,pos=-25,expression(paste(Streamflow~(m^3/s))),cex.lab=1.5,cex.axis=1.5)
acf(dados0vec,ylab="ACF",xlab="Lag",main="",sub="(b)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
hist(dados0vec,prob=TRUE,n=20,xlab=expression(paste(Streamflow~(m^3/s))),
     ylab="Density",main="",sub="(c)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
dev.off()

postscript(file="vazoes_prev_resid.ps",horizontal=FALSE, width=10.0, height=4.0,
           paper="special")
par(mfrow=c(1,3))
#  Forecast bands
plot(dadosTeste,type='l',col=1,lty=1,ylab="",
     ylim=c(19,190),xlab="index",lwd=1.5,sub="(a)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
axis(2,100,pos=-1,expression(paste(Streamflow~(m^3/s))),cex.lab=1.5,cex.axis=1.5)
lines(prev2_24_bs_gas$ypred.median,type='l',lty=2,lwd=1.5,cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
lines(prev2_24_bs_gas$ypred.upp,type='l',lty=3,lwd=1.5,cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
lines(prev2_24_bs_gas$ypred.low,type='l',lty=3,lwd=1.5,cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
# Correlogram
acf(mod_bs_gas.comp$res.gbs[m:379],ylab="ACF",xlab="Lags",main="",sub="(b)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
# QQ plot
#qqnorm(mod_bs_gas.comp$res.gbs[m:379],ylab="Empirical quantiles",
#       xlab="Standard normal quantiles",main="",sub="(c)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
#qqline(mod_bs_gas.comp$res.gbs[m:379])
plot(norm_TheoQuant,sort(mod_bs_gas.comp$res.gbs[(m+1):379]),ylab="Empirical quantiles",
     xlab="Standard normal quantiles",main="",sub="(c)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
lines(norm_TheoQuant,envel_res.gbs[,2],type='l',lty=2)
lines(norm_TheoQuant,envel_res.gbs[,1],type='l',lty=1,col=1)
lines(norm_TheoQuant,envel_res.gbs[,3],type='l',lty=1,col=1)
dev.off()


###################################################
#     Fitting a Gama-GAS(p,q)
###################################################

GASdata = dadosTreino
p = 5; q = 5
p.fixed = c(1,2,3,11,12);q.fixed = c(1,2,3,11,12);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
theta_hat_gama = c(0.15235,0.44010,-0.58095,0.30420,0.065354,-0.14334,1.5828,
                   -0.83454,0.12174,0.38471,-0.29112,15.366)

L_gama_gas = loglik_gamagas(theta_hat_gama,p,q,beta0,p.fixed,q.fixed)
-2*L_gama_gas+2*length(theta_hat_gama)
-2*L_gama_gas+log(length(GASdata))*length(theta_hat_gama)


mod_gama_gas.comp = comp_gamagas(theta_hat_gama,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_gama_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_gama_gas.comp$res.quant[m:379])
Box.test(mod_gama_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_gama_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_gama_gas.comp$res.gcs[m:379])
Box.test(mod_gama_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gama_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gama_gas.comp$res.gcs[m:379],"pexp")

# Performing the Ljung-Box test
Q_LB = Weighted.Box.test(mod_gama_gas.comp$res.quant[m:379], lag=25, type="Ljung",weighted = FALSE)
Q_LB$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))
# Performing the Monti test
Q_M = Weighted.Box.test(mod_gama_gas.comp$res.quant[m:379], lag=25, type="Monti",weighted = FALSE)
Q_M$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))


################

p = 2; q = 3
p.fixed = c(1,12);q.fixed = c(1,6,11);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
theta_hat_gama = c(0.50746,0.48281,-0.15484,0.49562,-0.11819,0.50132,14.377)

L_gama_gas = loglik_gamagas(theta_hat_gama,p,q,beta0,p.fixed,q.fixed)
-2*L_gama_gas+2*length(theta_hat_gama)
-2*L_gama_gas+log(length(GASdata))*length(theta_hat_gama)

mod_gama_gas.comp = comp_gamagas(theta_hat_gama,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_gama_gas.comp$beta_t[m:379],type='l',col=2)

# diagnostic analysis
acf(mod_gama_gas.comp$res.quant[m:379])
Box.test(mod_gama_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_gama_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_gama_gas.comp$res.gcs[m:379])
Box.test(mod_gama_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gama_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gama_gas.comp$res.gcs[m:379],"pexp")

# Performing the Ljung-Box test
Q_LB = Weighted.Box.test(mod_gama_gas.comp$res.quant[m:379], lag=25, type="Ljung",weighted = FALSE)
Q_LB$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))
# Performing the Monti test
Q_M = Weighted.Box.test(mod_gama_gas.comp$res.quant[m:379], lag=25, type="Monti",weighted = FALSE)
Q_M$statistic[[1]]
pchisq(Q_LB$statistic[[1]],df=(25-1-3-5))

