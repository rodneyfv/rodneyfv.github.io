source("GBS2 GAS functions.R")
source("BS GAS functions.R")
require(tseries)

###################
# Streamflow data

#dados0 = read.table("paraibuna.txt",dec=",")
dados0 = read.table("paraibunaONS.txt",dec=",")
dim(dados0)
dados0vec = matrix(t(as.matrix(dados0[,2:13])),ncol=1,nrow=34*12)
dados0vec.ts = ts(dados0vec,start=c(1976,1),frequency=12)

hist(dados0vec,prob=TRUE,n=20)
boxplot(dados0[,2:13],c(1:12))

#write.table(dados0vec,file="paraibunaONS.mat",sep=",",dec=".",row.names = FALSE,col.names = FALSE)
length(dados0vec)
dadosTreino = dados0vec[1:(32*12-5)]
dadosTeste = dados0vec[(32*12-5+1):(34*12-5)]
plot(c(dadosTreino,dadosTeste),type='l')
abline(v=(32*12-5),lty=2,col=3)
acf(dadosTreino)

###################################################
#     Fitting a GBS2-GAS(p,q)
###################################################

# best up to now: p.fixed = c(1,12) and q.fixed = c(1,6,11)
GASdata = dadosTreino
p = 2; q = 3
p.fixed = c(1,12);q.fixed = c(1,6,11);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
#s0 = mean(dadosTreino); r0 = 1/mean(1/dadosTreino)
#sqrt(2*(sqrt(s0/r0) - 1))
theta0 = c(0.404,0.562,-0.224,0.502,-0.106,0.506,0.044,0.085)

loglik_gbs2gas(theta0,p,q,beta0,p.fixed,q.fixed)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0
loglik_gbs2gas_optim(theta0)

#mod = optim(theta0,loglik_gbs2gas_optim,
#            method="BFGS")
mod_gbs_gas = optim(theta0,loglik_gbs2gas_optim,grad_gbs2gas_optim,
            method="BFGS")
mod_gbs_gas$convergence
mod_gbs_gas$par

H_gbs_gas = hessian_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
U_gbs_gas = grad_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
sqrt(diag(solve(H_gbs_gas)%*%(U_gbs_gas%*%t(U_gbs_gas))%*%solve(H_gbs_gas)))
sqrt(diag(solve(-H_gbs_gas)))
round(mod_gbs_gas$par,4)
round(sqrt(diag(solve(-H_gbs_gas))),4)

L_gbs_gas = loglik_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
-2*L_gbs_gas+log(length(GASdata))*length(mod_gbs_gas$par)
-2*L_gbs_gas+2*length(mod_gbs_gas$par)


mod_gbs_gas.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_gbs_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_gbs_gas.comp$res.quant[m:379])
Box.test(mod_gbs_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_gbs_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_gbs_gas.comp$res.gcs[m:379])
Box.test(mod_gbs_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gbs_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gbs_gas.comp$res.gcs[m:379],"pexp")
# GBS2 residuals
acf(mod_gbs_gas.comp$res.gbs[m:379])
Box.test(mod_gbs_gas.comp$res.gbs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gbs_gas.comp$res.gbs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gbs_gas.comp$res.gbs[m:379],"pnorm")
jarque.bera.test(mod_gbs_gas.comp$res.gbs[m:379])

set.seed(2017)
########
# predictions for the test set 24 steps ahead (out of sample)
GASdata = c(dadosTreino)
mod_gbs_gas.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
prev24_gbs_gas = forecast_gbs2gas(mod_gbs_gas$par,p,q,p.fixed,q.fixed,
                        GASdata[360:379],mod_gbs_gas.comp$beta_t[360:379],
                        n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev24_gbs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev24_gbs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev24_gbs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev24_gbs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev24_gbs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev24_gbs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev24_gbs_gas$ypred.median)/(dadosTeste + prev24_gbs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev24_gbs_gas$ypred.median)^2
# MAPE
100*mean(abs(dadosTeste - prev24_gbs_gas$ypred.median)/(prev24_gbs_gas$ypred.median))

########
# predictions for the test set 24 steps ahead (out of sample)
# using the forecast2_gbs2gas function
# In this function, the predictions are
# obtained through parametric bootstrap method and using the method 
# proposed by Blasques et al (2016) to take considering both parameter
# and innovation uncertainty of the GAS parameters.
GASdata = c(dadosTreino)
mod_gbs_gas.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
prev2_24_gbs_gas = forecast2_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed,
                                  n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev2_24_gbs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev2_24_gbs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev2_24_gbs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev2_24_gbs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev2_24_gbs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median)/(dadosTeste + prev2_24_gbs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev2_24_gbs_gas$ypred.median)^2
# MAPE
100*mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median)/(prev2_24_gbs_gas$ypred.median))


##########
# density forecast diagnostic

2*length(dadosTreino)/3
GASdata = dadosTreino[1:253]
DF_mod_gbs_gas = optim(theta0,loglik_gbs2gas_optim,grad_gbs2gas_optim,
                    method="BFGS")
DF_gbs_gas = densForecast_gbs2gas(DF_mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed,
                                  dadosTreino[1:253],dadosTreino[254:379])
hist(DF_gbs_gas,prob=TRUE)
ks.test(DF_gbs_gas,"punif")
acf(DF_gbs_gas)
acf(DF_gbs_gas^2)
Box.test(DF_gbs_gas, lag = 12, type="Ljung-Box")
Box.test((DF_gbs_gas)^2, lag = 12, type="Ljung-Box")


###################################################
#     Fitting a BS-GAS(p,q)
###################################################

# best up to now: p.fixed = c(1,12) and q.fixed = c(1,6,11)
GASdata = dadosTreino
p = 2; q = 3
p.fixed = c(1,12);q.fixed = c(1,6,11);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
theta0 = c(0.419,0.557,-0.219,0.501,-0.107,0.505,0.259)

loglik_bsgas(theta0,p,q,beta0,p.fixed,q.fixed)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0
loglik_bsgas_optim(theta0)

#mod = optim(theta,loglik_gbs2gas_optim,
#            method="BFGS")
mod_bs_gas = optim(theta0,loglik_bsgas_optim,grad_bsgas_optim,
            method="BFGS")
mod_bs_gas$convergence
mod_bs_gas$par

H_bs_gas = hessian_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed)
U_bs_gas = grad_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed)
sqrt(diag(solve(H_bs_gas)%*%(U_bs_gas%*%t(U_bs_gas))%*%solve(H_bs_gas)))
sqrt(diag(solve(-H_bs_gas)))
round(mod_bs_gas$par,3)
round(sqrt(diag(solve(-H_bs_gas))),4)

L_bs_gas = loglik_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed)
-2*L_bs_gas+log(length(GASdata))*length(mod_bs_gas$par)
-2*L_bs_gas+2*length(mod_bs_gas$par)
# Hypothesis test of H0:nu=0.5 against H1:nu!=0.5
1 - pchisq(2*(L_gbs_gas - L_bs_gas),1)

mod_bs_gas.comp = comp_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_bs_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_bs_gas.comp$res.quant[m:379])
Box.test(mod_bs_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_bs_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_bs_gas.comp$res.gcs[m:379])
Box.test(mod_bs_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gcs[m:379],"pexp")
# GBS residuals
acf(mod_bs_gas.comp$res.gbs[m:379])
Box.test(mod_bs_gas.comp$res.gbs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gbs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gbs[m:379],"pnorm")
jarque.bera.test(mod_bs_gas.comp$res.gbs[m:379])
qqnorm(mod_bs_gas.comp$res.gbs[m:379])
qqline(mod_bs_gas.comp$res.gbs[m:379])

set.seed(2017)
########
# predictions for the test set 24 steps ahead (out of sample)
GASdata = c(dadosTreino)
mod_bs_gas.comp = comp_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed)
prev24_bs_gas = forecast_bsgas(mod_bs_gas$par,p,q,p.fixed,q.fixed,
                            GASdata[360:379],mod_bs_gas.comp$beta_t[360:379],
                            n.ahead=24,Brep=5000)
plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev24_bs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev24_bs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev24_bs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev24_bs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev24_bs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev24_bs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev24_bs_gas$ypred.median)/(dadosTeste + prev24_bs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev24_bs_gas$ypred.median)^2
# MAPE
100*mean(abs(dadosTeste - prev24_bs_gas$ypred.median)/(prev24_bs_gas$ypred.median))

########
# predictions for the test set 24 steps ahead (out of sample)
# using the forecast2_bsgas function 
GASdata = c(dadosTreino)
mod_bs_gas.comp = comp_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed)
prev2_24_bs_gas = forecast2_bsgas(mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed,
                                  n.ahead=24,Brep=5000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev2_24_bs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev2_24_bs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev2_24_bs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev2_24_bs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev2_24_bs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev2_24_bs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev2_24_bs_gas$ypred.median)/(dadosTeste + prev2_24_bs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev2_24_bs_gas$ypred.median)^2


##########
# density forecast diagnostic

2*length(dadosTreino)/3
GASdata = dadosTreino[1:253]
DF_mod_bs_gas = optim(theta0,loglik_bsgas_optim,grad_bsgas_optim,
                       method="BFGS")
DF_bs_gas = densForecast_bsgas(DF_mod_bs_gas$par,p,q,beta0,p.fixed,q.fixed,
                                  dadosTreino[1:253],dadosTreino[254:379])
hist(DF_bs_gas,prob=TRUE)
ks.test(DF_bs_gas,"punif")
acf(DF_bs_gas)
acf(DF_bs_gas^2)
Box.test(DF_bs_gas, lag = 12, type="Ljung-Box")
Box.test((DF_bs_gas)^2, lag = 12, type="Ljung-Box")

###########################

# Preparing plots for the text

postscript(file="vazoes_serie_fac.ps",horizontal=FALSE, width=8.0, height=10.0,
           paper="special")
par(mfrow=c(3,1))
plot(dados0vec,xlab="Time",ylab="",main="",sub="(a)",cex.lab=1.5,
     cex.axis=1.5,cex.sub=1.5,type="l")
axis(2,150,pos=-25,expression(paste(Streamflow~(m^3/s))),cex.lab=1.5,cex.axis=1.5)
acf(dados0vec,ylab="ACF",xlab="Lag",main="",sub="(b)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
hist(dados0vec,prob=TRUE,n=20,xlab=expression(paste(Streamflow~(m^3/s))),
     ylab="Density",main="",sub="(c)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
dev.off()

postscript(file="vazoes_prev_resid.ps",horizontal=FALSE, width=10.0, height=4.0,
           paper="special")
par(mfrow=c(1,3))
plot(dadosTeste,type='l',col=1,lty=1,ylab="",
     ylim=c(19,190),xlab="index",lwd=1.5,sub="(a)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
axis(2,100,pos=-1,expression(paste(Streamflow~(m^3/s))),cex.lab=1.5,cex.axis=1.5)
lines(prev2_24_bs_gas$ypred.median,type='l',lty=2,lwd=1.5,cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
lines(prev2_24_bs_gas$ypred.upp,type='l',lty=3,lwd=1.5,cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
lines(prev2_24_bs_gas$ypred.low,type='l',lty=3,lwd=1.5,cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
acf(mod_bs_gas.comp$res.gbs[m:379],ylab="ACF",xlab="Las",main="",sub="(b)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
qqnorm(mod_bs_gas.comp$res.gbs[m:379],ylab="Empirical quantiles",
       xlab="Standard normal quantiles",main="",sub="(c)",cex.lab=1.5,cex.axis=1.5,cex.sub=1.5)
qqline(mod_bs_gas.comp$res.gbs[m:379])
dev.off()


###################################################
#     Fitting a Gama-GAS(p,q)
###################################################

source("Gama GAS functions.R")

GASdata = dadosTreino
p = 5; q = 5
p.fixed = c(1,2,3,11,12);q.fixed = c(1,2,3,11,12);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
theta0 = c(.201,.439,-.511,.245,.091,-0.171,1.49,-.701,.054,.389,-.281,15.454)

loglik_gamagas(theta0,p,q,beta0,p.fixed,q.fixed)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0
loglik_gamagas_optim(theta0)

mod_gama_gas = optim(theta0,loglik_gamagas_optim,
                   method="BFGS",hessian=TRUE)
mod_gama_gas$convergence
mod_gama_gas$par

loglik_gamagas(mod_gama_gas$par,p,q,beta0,p.fixed,q.fixed)

################

p = 2; q = 3
p.fixed = c(1,12);q.fixed = c(1,6,11);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
theta0 = c(0,0,0,0,0,0,1)
theta0 = c(0.56,0.48,-0.15,0.49,-0.12,0.49,14.18)

loglik_gamagas(theta0,p,q,beta0,p.fixed,q.fixed)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0
loglik_gamagas_optim(theta0)

mod_gama_gas = optim(theta0,loglik_gamagas_optim,
                     method="BFGS",hessian=TRUE)
mod_gama_gas$convergence
mod_gama_gas$par
sqrt(diag(solve(mod_gama_gas$hessian*length(GASdata))))

L_gama_gas = loglik_gamagas(mod_gama_gas$par,p,q,beta0,p.fixed,q.fixed)
-2*L_gama_gas+log(length(GASdata))*length(mod_gama_gas$par)
-2*L_gama_gas+2*length(mod_gama_gas$par)

mod_gama_gas.comp = comp_gamagas(mod_gama_gas$par,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_gama_gas.comp$beta_t[m:379],type='l',col=2)

# diagnostic analysis
acf(mod_gama_gas.comp$res.quant[m:379])
Box.test(mod_gama_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_gama_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_gama_gas.comp$res.gcs[m:379])
Box.test(mod_gama_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gama_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gama_gas.comp$res.gcs[m:379],"pexp")

