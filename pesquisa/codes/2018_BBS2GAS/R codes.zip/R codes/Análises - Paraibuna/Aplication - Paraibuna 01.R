source("GBS2 GAS functions.R")
source("BS GAS functions.R")
require(tseries)

###################
# Streamflow data

#dados0 = read.table("paraibuna.txt",dec=",")
dados0 = read.table("paraibunaONS.txt",dec=",")
dim(dados0)
dados0vec = matrix(t(as.matrix(dados0[,2:13])),ncol=1,nrow=34*12)

hist(dados0vec,prob=TRUE,n=20)
boxplot(dados0[,2:13],c(1:12))

dadosTreino = dados0vec[1:(32*12-5)]
dadosTeste = dados0vec[(32*12-5+1):(34*12-5)]
plot(c(dadosTreino,dadosTeste),type='l')
abline(v=(32*12-5),lty=2,col=3)
acf(dadosTreino)

###################################################
#     Fitting a GBS2-GAS(p,q)
###################################################

# best up to now: p.fixed = c(1,12) and q.fixed = c(1,6,11)
GASdata = dadosTreino
p = 2; q = 3
p.fixed = c(1,12);q.fixed = c(1,6,11);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
#s0 = mean(dadosTreino); r0 = 1/mean(1/dadosTreino)
#sqrt(2*(sqrt(s0/r0) - 1))
theta = c(0.404,0.562,-0.224,0.502,-0.106,0.506,0.044,0.085)

loglik_gbs2gas(theta,p,q,beta0,p.fixed,q.fixed)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0
loglik_gbs2gas_optim(theta)

#mod = optim(theta,loglik_gbs2gas_optim,
#            method="BFGS")
mod_gbs_gas = optim(theta,loglik_gbs2gas_optim,grad_gbs2gas_optim,
            method="BFGS")

mod_gbs_gas$convergence
mod_gbs_gas$par

H_gbs_gas = hessian_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
U_gbs_gas = grad_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
sqrt(diag(solve(H_gbs_gas)%*%(U_gbs_gas%*%t(U_gbs_gas))%*%solve(H_gbs_gas)))
sqrt(diag(solve(-H_gbs_gas)))

L_gbs_gas = loglik_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
-2*L_gbs_gas+log(length(GASdata))*length(mod_gbs_gas$par)
-2*L_gbs_gas+2*length(mod_gbs_gas$par)


mod_gbs_gas.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_gbs_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_gbs_gas.comp$res.quant[m:379])
Box.test(mod_gbs_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_gbs_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_gbs_gas.comp$res.gcs[m:379])
Box.test(mod_gbs_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gbs_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gbs_gas.comp$res.gcs[m:379],"pexp")
# GBS2 residuals
acf(mod_gbs_gas.comp$res.gbs[m:379])
Box.test(mod_gbs_gas.comp$res.gbs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_gbs_gas.comp$res.gbs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_gbs_gas.comp$res.gbs[m:379],"pnorm")
jarque.bera.test(mod_gbs_gas.comp$res.gbs[m:379])




########
# predictions for the training set (in sample)
length(dadosTreino)
GASdata = c(dadosTreino)
mod.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)

plot(dadosTreino[13:379],type='l')
lines(mod.comp$beta_t[13:379],type='l',col=2)
# RMSE
sqrt(mean((dadosTreino[13:379] - mod.comp$beta_t[13:379])^2))
# MAE
mean(abs(dadosTreino[13:379] - mod.comp$beta_t[13:379]))
# MASE
(365/366)*sum(abs(dadosTreino[13:379] - mod.comp$beta_t[13:379]))/sum(abs(diff(dadosTreino[13:379])))
# sMAPE
100*mean(abs(dadosTreino[13:379] - mod.comp$beta_t[13:379])/(dadosTreino[13:379] + mod.comp$beta_t[13:379]))
# pseudo R2
cor(dadosTreino[13:379], mod.comp$beta_t[13:379])^2


########
# predictions for the test set 24 steps ahead (out of sample)
GASdata = c(dadosTreino)
mod.comp = comp_gbs2gas(mod$par,p,q,beta0,p.fixed,q.fixed)
prev24_gbs_gas = forecast_gbs2gas(mod$par,p,q,p.fixed,q.fixed,
                        GASdata[360:379],mod.comp$beta_t[360:379],
                        n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev24_gbs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev24_gbs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev24_gbs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev24_gbs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev24_gbs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev24_gbs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev24_gbs_gas$ypred.median)/(dadosTeste + prev24_gbs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev24_gbs_gas$ypred.median)^2

########
# predictions for the test set 24 steps ahead (out of sample)
# using the forecast2_gbs2gas function
GASdata = c(dadosTreino)
mod_gbs_gas.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
prev2_24_gbs_gas = forecast2_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed,
                                  n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev2_24_gbs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev2_24_gbs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev2_24_gbs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev2_24_gbs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev2_24_gbs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev2_24_gbs_gas$ypred.median)/(dadosTeste + prev2_24_gbs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev2_24_gbs_gas$ypred.median)^2


##########
# prediction 1 step ahead(out of sample)
pred1passo = matrix(0,nrow=24,ncol=3)

GASdata = c(dadosTreino)
mod_gbs_gas.comp = comp_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed)
prev = forecast_gbs2gas(mod_gbs_gas$par,p,q,p.fixed,q.fixed,
                        GASdata[360:379],mod_gbs_gas.comp$beta_t[360:379],
                        n.ahead=1,Brep=1000)
pred1passo[1,] = c(prev$ypred.low,
                   prev$ypred.median,
                   prev$ypred.upp)
for(i in 2:24){
  GASdata = c(dadosTreino,dadosTeste[1:(i-1)])
  mod.comp = comp_gbs2gas(mod$par,p,q,beta0,p.fixed,q.fixed)
  prev = forecast_gbs2gas(mod$par,p,q,p.fixed,q.fixed,
                          GASdata[360:(379+i-1)],mod.comp$beta_t[360:(379+i-1)],
                          n.ahead=1,Brep=1000)
  pred1passo[i,] = c(prev$ypred.low,
                     prev$ypred.median,
                     prev$ypred.upp)
}

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(pred1passo[,2],type='l',lty=1,col=2)
lines(pred1passo[,1],type='l',lty=2,col=2)
lines(pred1passo[,3],type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - pred1passo[,2])^2))
# MAE
mean(abs(dadosTeste - pred1passo[,2]))
# MASE
(23/24)*sum(abs(dadosTeste - pred1passo[,2]))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - pred1passo[,2])/(dadosTeste + pred1passo[,2]))
# pseudo R2
cor(dadosTeste, pred1passo[,2])^2

##########
GASdata = c(dadosTreino,dadosTeste)
mod.comp = comp_gbs2gas(mod$par,p,q,beta0,p.fixed,q.fixed)
length(mod.comp$beta_t)

plot(dadosTeste,type='l')
lines(mod.comp$beta_t[380:403],type='l',col=2)
# RMSE
sqrt(mean((dadosTeste - mod.comp$beta_t[380:403])^2))
# MAE
mean(abs(dadosTeste - mod.comp$beta_t[380:403]))
# MASE
(23/24)*sum(abs(dadosTeste - mod.comp$beta_t[380:403]))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - mod.comp$beta_t[380:403])/(dadosTeste + mod.comp$beta_t[380:403]))
# pseudo R2
cor(dadosTeste, mod.comp$beta_t[380:403])^2


##########
# density forecast diagnostic
DF_mod_gbs_gas = densForecast_gbs2gas(mod_gbs_gas$par,p,q,beta0,p.fixed,q.fixed,
                              dadosTreino,dadosTeste)
hist(DF_mod_gbs_gas,prob=TRUE)
ks.test(DF_mod_gbs_gas,"punif")
acf(DF_mod_gbs_gas)
acf(DF_mod_gbs_gas^2)
Box.test(DF_mod_gbs_gas, lag = 12, type="Ljung-Box")
Box.test((DF_mod_gbs_gas)^2, lag = 12, type="Ljung-Box")


###################################################
#     Fitting a BS-GAS(p,q)
###################################################

# best up to now: p.fixed = c(1,12) and q.fixed = c(1,6,11)
GASdata = dadosTreino
p = 2; q = 3
p.fixed = c(1,12);q.fixed = c(1,6,11);m=max(max(p.fixed),max(q.fixed))
beta0 = apply(dados0[1:29,2:13],2,median)
theta = c(.5,.5,-.2,.5,-.1,.5,.5)

loglik_bsgas(theta,p,q,beta0,p.fixed,q.fixed)
loglik_gbs2gas(c(theta,.5),p,q,beta0,p.fixed,q.fixed)

p_optim = p
q_optim = q
p.fixed_optim = p.fixed; q.fixed_optim = q.fixed
beta0_optim = beta0
loglik_bsgas_optim(theta)
loglik_gbs2gas_optim(c(theta,.5))

#mod = optim(theta,loglik_gbs2gas_optim,
#            method="BFGS")
mod_bs = optim(theta,loglik_bsgas_optim,grad_bsgas_optim,
            method="BFGS")
mod_bs$convergence
mod_bs$par

H_bs = hessian_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed)
U_bs = grad_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed)
sqrt(diag(solve(H_bs)%*%(U_bs%*%t(U_bs))%*%solve(H_bs)))
sqrt(diag(solve(-H_bs)))

L_bs_gas = loglik_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed)
-2*L_bs_gas+log(length(GASdata))*length(mod_bs$par)
-2*L_bs_gas+2*length(mod_bs$par)
1 - pchisq(2*(L_gbs_gas - L_bs_gas),1)

mod_bs_gas.comp = comp_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed)
plot(dadosTreino[m:379],type='l')
lines(mod_bs_gas.comp$beta_t[m:379],type='l',col=2)


# diagnostic analysis
acf(mod_bs_gas.comp$res.quant[m:379])
Box.test(mod_bs_gas.comp$res.quant[m:379], lag = 24, type="Ljung-Box")
jarque.bera.test(mod_bs_gas.comp$res.quant[m:379])
# GCS residuals
acf(mod_bs_gas.comp$res.gcs[m:379])
Box.test(mod_bs_gas.comp$res.gcs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gcs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gcs[m:379],"pexp")
# GBS residuals
acf(mod_bs.comp$res.gbs[m:379])
Box.test(mod_bs_gas.comp$res.gbs[m:379], lag = 24, type="Ljung-Box")
Box.test((mod_bs_gas.comp$res.gbs[m:379])^2, lag = 24, type="Ljung-Box")
ks.test(mod_bs_gas.comp$res.gbs[m:379],"pnorm")
jarque.bera.test(mod_bs_gas.comp$res.gbs[m:379])

jarque.bera.test(rnorm(300))



########
# predictions for the test set 24 steps ahead (out of sample)
GASdata = c(dadosTreino)
mod_bs_gas.comp = comp_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed)
prev24_bs_gas = forecast_bsgas(mod_bs$par,p,q,p.fixed,q.fixed,
                            GASdata[360:379],mod_bs_gas.comp$beta_t[360:379],
                            n.ahead=24,Brep=1000)


plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev24_bs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev24_bs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev24_bs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev24_bs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev24_bs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev24_bs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev24_bs_gas$ypred.median)/(dadosTeste + prev24_bs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev24_bs_gas$ypred.median)^2

########
# predictions for the test set 24 steps ahead (out of sample)
# using the forecast2_bsgas function 
GASdata = c(dadosTreino)
mod_bs_gas.comp = comp_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed)
prev2_24_bs_gas = forecast2_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed,
                                  n.ahead=24,Brep=1000)

plot(dadosTeste,type='l',col=1,lty=1,ylim=c(19,190))
lines(prev2_24_bs_gas$ypred.median,type='l',lty=1,col=2)
lines(prev2_24_bs_gas$ypred.upp,type='l',lty=2,col=2)
lines(prev2_24_bs_gas$ypred.low,type='l',lty=2,col=2)
# RMSE
sqrt(mean((dadosTeste - prev2_24_bs_gas$ypred.median)^2))
# MAE
mean(abs(dadosTeste - prev2_24_bs_gas$ypred.median))
# MASE
(23/24)*sum(abs(dadosTeste - prev2_24_bs_gas$ypred.median))/sum(abs(diff(dadosTeste)))
# sMAPE
100*mean(abs(dadosTeste - prev2_24_bs_gas$ypred.median)/(dadosTeste + prev2_24_bs_gas$ypred.median))
# pseudo R2
cor(dadosTeste, prev2_24_bs_gas$ypred.median)^2


##########
# density forecast diagnostic
DF_mod_bs_gas = densForecast_bsgas(mod_bs$par,p,q,beta0,p.fixed,q.fixed,
                              dadosTreino,dadosTeste)
hist(DF_mod_bs_gas,prob=TRUE)
ks.test(DF_mod_bs_gas,"punif")
acf(DF_mod_bs_gas)
acf(DF_mod_bs_gas^2)
Box.test(DF_mod_bs_gas, lag = 12, type="Ljung-Box")
Box.test((DF_mod_bs_gas)^2, lag = 12, type="Ljung-Box")
