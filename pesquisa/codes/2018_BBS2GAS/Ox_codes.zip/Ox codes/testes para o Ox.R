source("GBS2 GAS functions.R")
source("BS GAS functions.R")
source("Gama GAS functions.R")

Ell(.5)
Ell(1)
Ell(1.5)
aux = matrix(rep(0,10),10,1)
for(i in 1:10) aux[i,1] = Ell(i/10)
aux

S_t(.2, .2)
S_t(1.5, .2)
S_t(.5, 1.2)
S_t(1.5, 1.2)

Delta_t(1,1,1.5,.1);
dDelta_db_t(1,1,1.5,.1);
dEll(.1);
dS_t(1,.1);
grad_alpha_gbs2(1,1,1.5,.1);
dDelta_dalpha_t(1,1,2,.1);
grad_nu_gbs2(1,1,1.5,.1);
dDelta_dnu_t(1,1,1.5,.1);

d2Delta_db2_t(1,.5,1.5,.1)
base_vec(5,4)
d2Ell(.5)
d2S_da2_t(1,.1)
d2Delta_dbt_dalpha_t(1,.5,1.5,.1)
d2Delta_dnu2_t(1,.5,1.5,.1)
d2Delta_dbt_dnu_t(1,.5,1.5,.1)
d2Delta_dalpha_dnu_t(1,.5,1.5,.1)

set.seed(10)
y = rgbs2(100,1,1,1)
for(i in 1:100){
  cat(y[i],";")
}
hessian_gbs2(y,1,1,1)

y = rgbs2gas(100000,3,2,c(.1,.1,-.1,.1,-.1,.1,.5,1.5),c(1,6,12),c(1,6))$y_t

m = mean(y);m
sd = sd(y);sd
mean((y-m)^3)/(sd^3)
mean((y-m)^4)/(sd^4)

set.seed(10)
y = rgbs2gas(100,2,2,c(.1,.1,-.1,.1,-.1,.5,.5),c(1,2),c(1,12))$y_t
for(i in 1:100){
  cat(y[i],";")
}
median(y)
GASdata = y
p_fixed = c(1,2)
q_fixed = c(1,12)
loglik_gbs2gas(c(.1,.1,-.1,.1,-.1,.5,.5),length(p_fixed),length(q_fixed),
               rep(median(y),12),p_fixed,q_fixed)
#loglik_gbs2gas(c(.1,.1,.1,.5,.5),1,1,rep(median(y),4),c(1),c(1))

grad_gbs2gas(c(.1,.1,-.1,.1,-.1,.5,.5),length(p_fixed),length(q_fixed),
             rep(median(y),12),p_fixed,q_fixed)
#grad_gbs2gas(c(.1,.1,.1,.5,.5),1,1,rep(median(y),12),1,1)

hessian_gbs2gas(c(.1,.1,-.1,.1,-.1,.5,.5),length(p_fixed),length(q_fixed),
             rep(median(y),12),p_fixed,q_fixed)
#hessian_gbs2gas(c(.1,.1,.1,.5,.5),1,1,rep(median(y),12),1,1)

comp_teste = comp_gbs2gas(c(.1,.1,-.1,.1,-.1,.5,.5),2,2,rep(median(y),12),c(1,2),c(1,2))

length(comp_teste$beta_t)
forecast_gbs2gas(c(.1,.1,-.1,.1,-.1,.5,.5),2,2,c(1,2),c(1,2),GASdata[50:100],
                 comp_teste$beta_t[50:100],12,5000)

set.seed(10)
y = rgbs2gas(500,1,1,c(.1,.1,.1,.5,.5),c(1),c(1))$y_t
GASdata = y
diag(solve(-hessian_gbs2gas(c(.1,.1,.1,.5,.5),1,1,rep(median(y),2),c(1),c(1))))

forecast_gbs2gas(c(.1,.1,.1,.5,.5),1,1,c(1),c(1),GASdata[50:500],
                 comp_teste$beta_t[50:500],12,1000)
forecast2_gbs2gas(c(.1,.1,.1,.5,.5),1,1,rep(median(y),2),c(1),c(1),12,100)


################################################################################################################
################################################################################################################

set.seed(10)
y = rgbs2gas(100,2,2,c(.1,.1,-.1,.1,-.1,.5,.5),c(1,2),c(1,12))$y_t
for(i in 1:100){
  cat(y[i],";")
}
median(y)
GASdata = y
p_fixed = c(1,2)
q_fixed = c(1,12)
loglik_bsgas(c(.1,.1,-.1,.1,-.1,.5),length(p_fixed),length(q_fixed),
               rep(median(y),12),p_fixed,q_fixed)
grad_bsgas(c(.1,.1,-.1,.1,-.1,.5),length(p_fixed),length(q_fixed),
             rep(median(y),12),p_fixed,q_fixed)
round(hessian_bsgas(c(.1,.1,-.1,.1,-.1,.5),length(p_fixed),length(q_fixed),
                rep(median(y),12),p_fixed,q_fixed),4)
comp_teste = comp_bsgas(c(.1,.1,-.1,.1,-.1,.5),length(p_fixed),length(q_fixed),rep(median(y),12),p_fixed,q_fixed)
round(cbind(comp_teste$beta_t,c(comp_teste$f_t,comp_teste$f_t)[1:100],comp_teste$s_t,comp_teste$res.quant,comp_teste$res.gcs,comp_teste$res.gbs),4)

################################################################################################################
################################################################################################################
