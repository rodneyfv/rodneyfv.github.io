require(numDeriv)

#############################################

#############################################

# function to simulate a sample of size N from a BS GAS(p,q) model
# with the fixed parameters theta, where the first p parameters of
# theta correspond to the score lags, the q after these correspond to
# the f_t lags, the (p+q+1)th parameter correspond to alpha and the 
# (p+q+)th correspond to nu and the nonnull GAS parameters 
# must be indicated in p.fixed and q.fixed.
rgamagas = function(N,p,q,theta,p.fixed=NULL,q.fixed=NULL){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  m = max(max(p.fixed),max(q.fixed))
  # An additional of 20% of the sample size will be generated
  # to decrease the influence of the initial values
  adic = round(N*.20)
  
  beta_t = rep(exp(w),N+adic+2*m)
  f_t = rep(w,N+adic+1+2*m)
  y_t = rep(0,N+adic+2*m)
  s_t = rep(0,N+adic+2*m)
  for(t in m:(N+adic+2*m)){
    beta_t[t] = exp(f_t[t])
    y_t[t] = rgamma(1,shape=alpha,scale=beta_t[t]/alpha)
    s_t[t] = y_t[t]/beta_t[t] - 1
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(list(y_t=y_t[(2*m+adic+1):(N+2*m+adic)],beta_t=beta_t[(2*m+adic+1):(N+2*m+adic)]))
}

# conditional loglikelihood of the BS GAS(p,q) model
# the number of GAS parameters  are p and q, and the 
# nonnull parameters must be indicated in p.fixed and q.fixed. 
# a mx1 vector of initial estimates beta_0 must be also provided,
# where m is the maximum lag of p.fixed and q.fixed
loglik_gamagas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(GASdata)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  m = max(max(p.fixed),max(q.fixed))
  y_t = GASdata
  
  beta_t = rep(0,N)
  f_t = rep(0,N+1)
  s_t = rep(0,N)
  ell = rep(0,N)
  
  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in 1:(m-1)){
    beta_t[t] = exp(f_t[t])
    s_t[t] = y_t[t]/beta_t[t] - 1
  }
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    ell[t] = log(dgamma(y_t[t],shape=alpha,scale=beta_t[t]/alpha))
    s_t[t] = y_t[t]/beta_t[t] - 1
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(sum(ell[(m+1):N]))
}
# function to be used with optim
loglik_gamagas_optim = function(theta){
  -loglik_gamagas(theta,p_optim,q_optim,beta0_optim,p.fixed_optim,q.fixed_optim)/length(GASdata)
}

#############################

# components of a fitted BS GAS(p,q) model. The function returns the
# fitted conditional medians, the loglikelihood contribution of each
# observation, the time varying paramaters f_t, the score components,
# the quantile residuals and the generalized cox-snell residuals
comp_gamagas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(GASdata)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  m = max(max(p.fixed),max(q.fixed))
  y_t = GASdata
  
  beta_t = rep(0,N)
  f_t = rep(0,N+1)
  s_t = rep(0,N)
  ell = rep(0,N)
  res.quant = rep(0,N)
  res.gcs = rep(0,N)

  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    ell[t] = log(dgamma(y_t[t],shape=alpha,scale=beta_t[t]/alpha))
    s_t[t] = y_t[t]/beta_t[t] - 1
    # quantile residuals
    res.quant[t] = qnorm(pgamma(y_t[t],shape=alpha,scale=beta_t[t]/alpha))
    # generalized cox-snell residuals
    res.gcs[t] = -log(pgamma(y_t[t],shape=alpha,scale=beta_t[t]/alpha))

    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(list(beta_t=beta_t,ell=ell,f_t=f_t,s_t=s_t,
              res.quant=res.quant,res.gcs=res.gcs))
}

#############################

# function to forecast observations of a fitted BS GAS(p,q) model.
# The forecast horizon must be indicated in n.ahead. The previsions are
# obtained through parametric bootstrap method, and the number of 
# pseudo samples to be used have to be indicated in Brep. Predictions of
# the median variables, and bands of 95% of confidence.
forecast_gamagas = function(theta,p,q,p.fixed=NULL,q.fixed=NULL,
                            datTreino,betaTreino,
                            n.ahead=12,Brep=50){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(datTreino)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  m = max(max(p.fixed),max(q.fixed))
  
  beta_t = rep(0,N+n.ahead)
  beta_t[1:N] = betaTreino
  s_t = rep(0,N+n.ahead)
  y_t = rep(0,N+n.ahead)
  f_t = rep(0,N+n.ahead+1)
  f_t[1:m] = log(beta_t[1:m])
  y_t[1:N] = datTreino
  
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    s_t[t] = y_t[t]/beta_t[t] - 1
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  # matrix to store the pseudo samples of the parametric bootstrap, with the
  # pseudo samples in the columns and the observations in the rows
  mYpred = matrix(0,nrow=n.ahead,ncol=Brep)
  for(j in 1:Brep){
    for(t in (N+1):(N+n.ahead)){
      beta_t[t] = exp(f_t[t])
      # observation generated
      y_t[t] = rgamma(1,shape=alpha,scale=beta_t[t]/alpha)
      s_t[t] = y_t[t]/beta_t[t] - 1
      f_t[t+1] = w
      for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
      for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
    }
    mYpred[,j] = y_t[(N+1):(N+n.ahead)]
  }
  
  ypred.mean = apply(mYpred,1,mean)
  ypred.upp = apply(mYpred,1,quantile,probs=.975)
  ypred.low = apply(mYpred,1,quantile,probs=.025)
  
  return(list(ypred.mean=ypred.mean,ypred.upp=ypred.upp,
              ypred.low=ypred.low))
}
