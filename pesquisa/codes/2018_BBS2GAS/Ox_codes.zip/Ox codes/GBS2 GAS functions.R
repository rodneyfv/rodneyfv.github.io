require(numDeriv)
require(mvtnorm)

#############################################

# random number generator of the GBS2(a,b,nu) model
rgbs2 = function(n,a=1,b=1,nu=1){
  z = rnorm(n)
  t = b*((.5*a*z) + sqrt((.5*a*z)^2 + 1))^(1/nu)
  return(t)
}

# probability density function of the GBS2(a,b,nu) model
dgbs2 = function(t,a=1,b=1,nu=1){
  nu*((t/b)^nu + (b/t)^nu)*exp(-.5*((t/b)^(2*nu) + (b/t)^(2*nu) - 2)/(a^2))/
    (t*a*sqrt(2*pi))
}

# distribution function of the GBS2(a,b,nu) law
pgbs2 = function(t,a=1,b=1,nu=1){
  pnorm(((t/b)^nu - (b/t)^nu)/a)
}

# hazard rate function of the GBS2(a,b,nu) distribution
hrgbs2 = function(t,a=1,b=1,nu=1){
  dgbs2(t,a,b,nu)/(1 - pgbs2(t,a,b,nu))
}

# momento of r-th order of the GBS2(a,b,nu) distribution
moment_gbs2 = function(r,a,b,nu){
  (b^r)*exp(a^(-2))*(besselK(a^(-2),(r/nu + 1)/2) + besselK(a^(-2),(r/nu - 1)/2))/(a*sqrt(2*pi))
}

# Hessian matrix of the GBS2 distribution
hessian_gbs2 = function(x,a,b,nu){
  H = matrix(0,3,3)
  H[1,1] = sum(a^(-2) - 3*((x/b)^(2*nu)+(b/x)^(2*nu)-2)/(a^4))
  H[1,2] = H[2,1] = sum(-2*nu*((x/b)^(2*nu)-(b/x)^(2*nu))/(b*(a^3)))
  H[1,3] = H[3,1] = sum(2*log(x/b)*((x/b)^(2*nu)-(b/x)^(2*nu))/(a^3))
  H[2,2] = sum(-nu*((b/x)^(2*nu)-(x/b)^(2*nu)-4*nu)/((b^2)*((x/b)^nu+(b/x)^nu)^2) -
                 nu*((2*nu+1)*(x/b)^(2*nu)+(2*nu-1)*(b/x)^(2*nu))/((a^2)*(b^2)))
  H[2,3] = H[3,2] = sum(-(1/b)*((x/b)^(nu)-(b/x)^(nu))/((x/b)^(nu)+(b/x)^(nu)) -
                          nu*4*log(x/b)/(b*((x/b)^(nu)+(b/x)^(nu))^2) +
                          ((x/b)^(2*nu)-(b/x)^(2*nu))/(b*(a^2)) + 
                          nu*2*log(x/b)*((x/b)^(2*nu)+(b/x)^(2*nu))/(b*(a^2)))
  H[3,3] = sum(-1/nu^2 + 4*(log(x/b)/((x/b)^nu+(b/x)^nu))^2 -
                 2*(log(x/b)^2)*((x/b)^(2*nu)+(b/x)^(2*nu))/(a^2))
  return(H)
}

#############################################

# function used in the information of beta
Ell = function(a){
  f = function(z) dnorm(z)/((a*z)^2 + 4)
  int = integrate(f,0,Inf)
  return(2*int$value)
}

# returns the inverse value of the beta's information, 
# which is used in the GBS2 GAS model as scaling factor
S_t = function(alpha,nu){
  (alpha^2)/(2*(nu^2)*(2+alpha^2) - 4*Ell(alpha)*(alpha*nu)^2)
} 

# function to simulate a sample of size N from a GBS2 GAS(p,q) model
# with the fixed parameters theta, where the first p parameters of
# theta correspond to the score lags, the q after these correspond to
# the f_t lags, the (p+q+1)th parameter correspond to alpha and the 
# (p+q+)th correspond to nu and the nonnull GAS parameters 
# must be indicated in p.fixed and q.fixed.
rgbs2gas = function(N,p,q,theta,p.fixed=NULL,q.fixed=NULL){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  m = max(max(p.fixed),max(q.fixed))
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  # An additional of 20% of the sample size will be generated
  # to decrease the influence of the initial values
  adic = round(N*.20)
  
  beta_t = rep(exp(w),N+adic+2*m)
  f_t = rep(w,N+adic+1+2*m)
  y_t = rep(0,N+adic+2*m)
  s_t = rep(0,N+adic+2*m)
  for(t in m:(N+adic+2*m)){
    beta_t[t] = exp(f_t[t])
    y_t[t] = rgbs2(1,a=alpha,b=beta_t[t],nu=nu)
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(list(y_t=y_t[(2*m+adic+1):(N+2*m+adic)],beta_t=beta_t[(2*m+adic+1):(N+2*m+adic)]))
}

# conditional loglikelihood of the GBS2 GAS(p,q) model
# the number of GAS parameters  are p and q, and the 
# nonnull parameters must be indicated in p.fixed and q.fixed. 
# a mx1 vector of initial estimates beta_0 must be also provided,
# where m is the maximum lag of p.fixed and q.fixed
loglik_gbs2gas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(GASdata)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  m = max(max(p.fixed),max(q.fixed))
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  y_t = GASdata
  
  beta_t = rep(0,N)
  f_t = rep(0,N+1)
  s_t = rep(0,N)
  ell = rep(0,N)
  
  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in 1:(m-1)){
    beta_t[t] = exp(f_t[t])
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
  }
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    ell[t] = log(dgbs2(y_t[t],a=alpha,b=beta_t[t],nu=nu))
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(sum(ell[(m+1):N]))
}
# function to be used with optim
loglik_gbs2gas_optim = function(theta){
  -loglik_gbs2gas(theta,p_optim,q_optim,beta0_optim,p.fixed_optim,q.fixed_optim)/length(GASdata)
}

# function to be used with optim
loglik_gbs2gas_deriv = function(theta){
  loglik_gbs2gas(theta,p_optim,q_optim,beta0_optim,p.fixed,q.fixed)
}


#############################

# Returns the value of the Delta_t, the score function used in the GBS2 GAS
Delta_t = function(y,a,b,nu){
  nu*(((y/b)^(2*nu) - (b/y)^(2*nu))/(a^2) -
        ((y/b)^nu - (b/y)^nu)/((y/b)^nu + (b/y)^nu))
}

# Returns the value of the derivative of Delta_t with respect to beta_t
dDelta_db_t = function(y,a,b,nu){
  2*(nu^2)*( 2/((y/b)^nu + (b/y)^nu)^2 - ((y/b)^(2*nu) + (b/y)^(2*nu))/(a^2) )/b
}

# Derivative of Ell(alpha). The function dEll is
# used in the derivative of beta's information
dEll = function(a){
  f = function(z) dnorm(z)*(z^2)/((a*z)^2 + 4)^2
  int = integrate(f,0,Inf)
  return(-4*a*int$value)
}

# derivative of the scaling factor of the GBS2 GAS
dS_t = function(a,nu){
  (2*a^(-3) + dEll(a))/((nu^2)*(2*a^(-2) + 1 - 2*Ell(a))^2)
} 

# derivative of the loglikelihood with respect to alpha
grad_alpha_gbs2 = function(y,a,b,nu){
  -1/a + ((y/b)^(2*nu) - 2 + (b/y)^(2*nu))/(a^3)
}

# derivative of the score function Delta_t with respect to alpha
dDelta_dalpha_t = function(y,a,b,nu){
  -2*nu*((y/b)^(2*nu) - (b/y)^(2*nu))/(a^3)
}

# derivative of the loglikelihood with respect to nu
grad_nu_gbs2 = function(y,a,b,nu){
  1/nu + log(y/b)*((y/b)^nu - (b/y)^nu)/((y/b)^nu + (b/y)^nu) -
    log(y/b)*((y/b)^(2*nu) - (b/y)^(2*nu))/(a^2)
}

# derivative of the score function Delta_t with respect to nu
dDelta_dnu_t = function(y,a,b,nu){
  ((y/b)^(2*nu) - (b/y)^(2*nu))/(a^2) + 2*nu*log(y/b)*((y/b)^(2*nu) + (b/y)^(2*nu))/(a^2) -
    ((y/b)^nu - (b/y)^nu)/((y/b)^nu + (b/y)^nu) - 4*nu*log(y/b)/((y/b)^nu + (b/y)^nu)^2
}


# function to calculate the gradient of the fixed parameters 
# in the GBS2 GAS(p,q) model
grad_gbs2gas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL){
  
  N = length(GASdata)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  m = max(max(p.fixed),max(q.fixed))
  y_t = GASdata
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  
  beta_t = rep(0,N)
  f_t = rep(0,N+1)
  s_t = rep(0,N)
  # this matrix Z will store the values varying in time of the
  # vector z_t = (1,s_{t-1},...,s_{t-p},f_{t-1},...,f_{t-q})'
  Z = matrix(0,nrow=p+q+1,ncol=(N+1))
  Z[1,] = rep(1,N+1)
  
  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in 1:(m-1)){
    beta_t[t] = exp(f_t[t])
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
  }
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    f_t[t+1] = w
    for(i in 1:p){
      f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
      Z[i+1,t+1] = s_t[t-p.fixed[i]+1]
    } 
    for(i in 1:q){
      f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
      Z[i+p+1,t+1] = f_t[t-q.fixed[i]+1]
    } 
  }
  
  # matrices with the first derivatives of the time varying parameter f_t
  # the N columns in df_dtheta1, for example, will store the N derivatives
  # values varying in time
  df_dtheta1 = matrix(0,p+q+1,N)
  df_alpha = rep(0,N)
  df_nu = rep(0,N)
  for(t in (m+1):N){
    df_dtheta1[,t] = Z[,t]
    for(i in 1:q){
      df_dtheta1[,t] = df_dtheta1[,t] + B[i]*df_dtheta1[,t-q.fixed[i]]
      df_alpha[t] = df_alpha[t] + B[i]*df_alpha[t-q.fixed[i]]
      df_nu[t] = df_nu[t] + B[i]*df_nu[t-q.fixed[i]]
    }
    for(i in 1:p){
      # components corresponding to the GAS parameters
      dD_dbt = dDelta_db_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      df_dtheta1[,t] = df_dtheta1[,t] + 
        A[i]*S_alpha_nu*df_dtheta1[,t-p.fixed[i]]*
        beta_t[t-p.fixed[i]]*
        dD_dbt
      # components corresponding to alpha
      dD_da = dDelta_dalpha_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu) +
        dD_dbt*beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]]
      df_alpha[t] = df_alpha[t] + 
        A[i]*
        (S_alpha_nu*dD_da + 
           Delta_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)*dS_t(alpha,nu))
      # components corresponding to nu
      dD_dnu = dDelta_dnu_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu) +
        dD_dbt*beta_t[t-p.fixed[i]]*df_nu[t-p.fixed[i]]
      df_nu[t] = df_nu[t] + 
        A[i]*S_alpha_nu*
        (dD_dnu - 
           2*Delta_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)/nu)
      
    }
  }
  
  dloglik = rep(0,p+q+1)
  dloglik_alpha = 0
  dloglik_nu = 0
  for(t in (m+1):N){
    # loglik corresponding to the GAS parameters
    dloglik = dloglik + df_dtheta1[,t]*Delta_t(y_t[t],alpha,beta_t[t],nu)
    # loglik corresponding to alpha
    dloglik_alpha = dloglik_alpha + 
      grad_alpha_gbs2(y_t[t],alpha,beta_t[t],nu) + 
      df_alpha[t]*Delta_t(y_t[t],alpha,beta_t[t],nu)
    # loglik corresponding to nu
    dloglik_nu = dloglik_nu + 
      grad_nu_gbs2(y_t[t],alpha,beta_t[t],nu) + 
      df_nu[t]*Delta_t(y_t[t],alpha,beta_t[t],nu)
  }
  
  return(c(dloglik,dloglik_alpha,dloglik_nu))
}
# function to be used with optim
grad_gbs2gas_optim = function(theta){
  -grad_gbs2gas(theta,p_optim,q_optim,beta0_optim,p.fixed_optim,q.fixed_optim)/length(GASdata)
}

#############################

# components of a fitted GBS2 GAS(p,q) model. The function returns the
# fitted conditional medians, the loglikelihood contribution of each
# observation, the time varying paramaters f_t, the score components,
# the quantile residuals and the generalized cox-snell residuals
comp_gbs2gas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(GASdata)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  m = max(max(p.fixed),max(q.fixed))
  y_t = GASdata
  
  beta_t = rep(0,N)
  f_t = rep(0,N+1)
  s_t = rep(0,N)
  ell = rep(0,N)
  res.quant = rep(0,N)
  res.gcs = rep(0,N)
  res.gbs = rep(0,N)
  
  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    ell[t] = log(dgbs2(y_t[t],a=alpha,b=beta_t[t],nu=nu))
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    # quantile residuals
    res.quant[t] = qnorm(pgbs2(y_t[t],a=alpha,b=beta_t[t],nu=nu))
    # generalized cox-snell residuals
    res.gcs[t] = -log(pgbs2(y_t[t],a=alpha,b=beta_t[t],nu=nu))
    # residuals based on the relation of GBS2 and Normal distributions
    res.gbs[t] = ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/alpha
      
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(list(beta_t=beta_t,ell=ell,f_t=f_t,s_t=s_t,
              res.quant=res.quant,res.gcs=res.gcs,res.gbs=res.gbs))
}

#############################

# function to forecast observations of a fitted GBS2 GAS(p,q) model.
# The forecast horizon must be indicated in n.ahead. The previsions are
# obtained through parametric bootstrap method, and the number of 
# pseudo samples to be used have to be indicated in Brep. Predictions of
# the median variables, and bands of 95% of confidence.
forecast_gbs2gas = function(theta,p,q,p.fixed=NULL,q.fixed=NULL,
                            datTreino,betaTreino,
                            n.ahead=1,Brep=50){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(datTreino)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  m = max(max(p.fixed),max(q.fixed))
  
  beta_t = rep(0,N+n.ahead)
  beta_t[1:N] = betaTreino
  s_t = rep(0,N+n.ahead)
  y_t = rep(0,N+n.ahead)
  f_t = rep(0,N+n.ahead+1)
  f_t[1:m] = log(beta_t[1:m])
  y_t[1:N] = datTreino
  
  for(t in m:N){
    
    beta_t[t] = exp(f_t[t])
    
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  # matrix to store the pseudo samples of the parametric bootstrap, with the
  # pseudo samples in the columns and the observations in the rows
  mYpred = matrix(0,nrow=n.ahead,ncol=Brep)
  for(j in 1:Brep){
    for(t in (N+1):(N+n.ahead)){
      beta_t[t] = exp(f_t[t])
      # observation generated
      y_t[t] = rgbs2(1,a=alpha,b=beta_t[t],nu=nu)
      s_t[t] = S_alpha_nu * 
        nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
              ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
      
      f_t[t+1] = w
      for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
      for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
    }
    mYpred[,j] = y_t[(N+1):(N+n.ahead)]
  }
  
  ypred.median = apply(mYpred,1,median)
  ypred.upp = apply(mYpred,1,quantile,probs=.975)
  ypred.low = apply(mYpred,1,quantile,probs=.025)
  
  return(list(ypred.median=ypred.median,ypred.upp=ypred.upp,
              ypred.low=ypred.low))
}

# function to forecast observations of a fitted GBS2 GAS(p,q) model.
# The forecast horizon must be indicated in n.ahead. The previsions are
# obtained through parametric bootstrap method and using the method 
# proposed by Blasques et al (2016) to take considering both parameter
# and innovation uncertainty of the GAS parameters. Predictions of
# the median variables, and bands of 95% of confidence.
forecast2_gbs2gas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL,
                             n.ahead=1,Brep=50){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(GASdata)
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  m = max(max(p.fixed),max(q.fixed))
  
  # matrix to store the pseudo samples of the parametric bootstrap, with the
  # pseudo samples in the columns and the observations in the rows
  mYpred = matrix(0,nrow=n.ahead,ncol=Brep)
  #  estimate of the CMLE's covariance matrix
  mJi = solve(-hessian_gbs2gas(theta,p,q,beta0,p.fixed,q.fixed))
  
  beta_t = rep(0,N+n.ahead)
  s_t = rep(0,N+n.ahead)
  y_t = rep(0,N+n.ahead); y_t[1:N] = GASdata
  f_t = rep(0,N+n.ahead+1)
  
  for(j in 1:Brep){
    # drawing a vector from the approximated distribution of the CMLE
    theta_boot = rmvnorm(1,mean=theta,sigma=mJi)
    # storing the simulated estimates of the GAS parameters
    w_boot = theta_boot[1]
    A_boot = theta_boot[2:(p+1)]
    B_boot = theta_boot[(p+2):(p+q+1)]
    # obtaining the filtered sample for these simulated estimates
    mod_comp = comp_gbs2gas(c(theta_boot[1:(p+q+1)],alpha,nu),p,q,beta0,p.fixed,q.fixed)
    f_t[1:(N+1)] = mod_comp$f_t
    s_t[1:N] = mod_comp$s_t
    beta_t[1:N] = mod_comp$beta_t
    # loop to compute the predictions
    for(t in (N+1):(N+n.ahead)){
      beta_t[t] = exp(f_t[t])
      # observation generated
      y_t[t] = rgbs2(1,a=alpha,b=beta_t[t],nu=nu)
      s_t[t] = S_alpha_nu * 
        nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
              ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
      f_t[t+1] = w_boot
      for(i in 1:p) f_t[t+1] = f_t[t+1] + A_boot[i]*s_t[t-p.fixed[i]+1]
      for(i in 1:q) f_t[t+1] = f_t[t+1] + B_boot[i]*f_t[t-q.fixed[i]+1]
    }
    mYpred[,j] = y_t[(N+1):(N+n.ahead)]
  }
  
  ypred.median = apply(mYpred,1,median)
  ypred.upp = apply(mYpred,1,quantile,probs=.975)
  ypred.low = apply(mYpred,1,quantile,probs=.025)
  
  return(list(ypred.median=ypred.median,ypred.upp=ypred.upp,
              ypred.low=ypred.low))
}

#############################

# This function applies the density forecast technique 
# (Dielbold, 1998 and Bauwens, 2004) to the GBS2 GAS 
# model. Most of the arguments are like in the previous functions,
# but the data used to fit the model must be stored in 
# datTreino, and the test data must be idicated in 
# the datTest variable. The function returns the probability
# integral transform, which should be compared with a U(0,1)
# distribution.
densForecast_gbs2gas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL,
                                datTreino,datTeste){
  
  if(is.null(p.fixed)){p.fixed = c(1:p)}
  if(is.null(q.fixed)){q.fixed = c(1:q)}
  
  N = length(datTreino)
  N_teste = length(datTeste)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  m = max(max(p.fixed),max(q.fixed))
  y_t = c(datTreino,datTeste)
  
  beta_t = rep(0,N+N_teste)
  f_t = rep(0,N+1+N_teste)
  s_t = rep(0,N+N_teste)
  # vector to store the probability integral transform
  u_t = rep(0,N_teste)
  
  # obtaining first the fitted conditional medians
  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in 1:(m-1)){
    beta_t[t] = exp(f_t[t])
    s_t[t] = ((alpha^2)/(2*(nu^2)*(2+alpha^2) - 4*Ell(alpha)*(alpha*nu)^2)) * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
  }
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    s_t[t] = ((alpha^2)/(2*(nu^2)*(2+alpha^2) - 4*Ell(alpha)*(alpha*nu)^2)) * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  # calculating the conditional medians for out of sample
  # observations and obtaining the probability integral
  # transform corresponding to these observations
  for(t in (N+1):(N+N_teste)){
    beta_t[t] = exp(f_t[t])
    # probability integral transform
    u_t[t-N] = pgbs2(y_t[t],a=alpha,b=beta_t[t],nu=nu)
    s_t[t] = ((alpha^2)/(2*(nu^2)*(2+alpha^2) - 4*Ell(alpha)*(alpha*nu)^2)) * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    f_t[t+1] = w
    for(i in 1:p) f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
    for(i in 1:q) f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
  }
  
  return(u_t)
}

#############################


# Returns the value of the second derivative of Delta_t with respect to beta_t
d2Delta_db2_t = function(y,a,b,nu){
  dD_db = dDelta_db_t(y,a,b,nu)
  -dD_db/b + 8*(nu^3)*( ((y/b)^nu-(b/y)^nu)/((y/b)^nu+(b/y)^nu)^3 +
                          ((y/b)^(2*nu)-(b/y)^(2*nu))/(2*(a^2)) )/(b^2)
}

# creates a nx1 vector with 1 in the i-th position and zero elsewhere
base_vec = function(n,i){
  v = rep(0,n)
  v[i] = 1
  return(v)
}

# Derivative of Ell(alpha). The function dEll is
# used in the derivative of beta's information
d2Ell = function(a){
  f = function(z) dnorm(z)*(z^4)/((a*z)^2 + 4)^3
  int = integrate(f,0,Inf)
  return( dEll(a)/a + 16*(a^2)*int$value)
}

# second derivative of the scaling factor of the GBS2 GAS with respect to alpha
d2S_da2_t = function(a,nu){
  La = Ell(a)
  dLa = dEll(a)
  d2La = d2Ell(a)
  ( (-6*(a^(-4)) + d2La)*(2*(a^(-2)) + 1 - 2*La) + 4*(2*(a^(-3)) + dLa)^2 )/((nu^2)*(2*(a^(-2)) + 1 - 2*La)^3)
} 

# second order derivative of the score Delta_t with respect to alpha and beta_t
d2Delta_dbt_dalpha_t = function(y,a,b,nu){
  4*(nu^2)*((y/b)^(2*nu) + (b/y)^(2*nu))/((a^3)*b)
}

# Second derivative of Delta_t with respect to nu
d2Delta_dnu2_t = function(y,a,b,nu){
  4*log(y/b)*((y/b)^(2*nu)+(b/y)^(2*nu))/a^2 +
    4*nu*(log(y/b)^2)*((y/b)^(2*nu)-(b/y)^(2*nu))/(a^2) -
    8*log(y/b)/(((y/b)^nu+(b/y)^nu)^2) +
    8*nu*(log(y/b)^2)*((y/b)^nu-(b/y)^nu)/(((y/b)^nu+(b/y)^nu)^3)
}

# second order derivative of the score Delta_t with respect to nu and beta_t
d2Delta_dbt_dnu_t = function(y,a,b,nu){
  dD_db = dDelta_db_t(y,a,b,nu)
  2*dD_db/nu - 4*(nu^2)*log(y/b)*( 2*((y/b)^nu-(b/y)^nu)/((y/b)^nu+(b/y)^nu)^3 +
                                     ((y/b)^(2*nu)-(b/y)^(2*nu))/(a^2) )/b
}

# second order derivative of the score Delta_t with respect to nu and alpha
d2Delta_dalpha_dnu_t = function(y,a,b,nu){
  -2*( (y/b)^(2*nu)-(b/y)^(2*nu) + 2*nu*log(y/b)*((y/b)^(2*nu)+(b/y)^(2*nu)))/(a^3)
}

# returns the Hessian matrix of a GBS2 GAS(p,q) model. The arguments of
# the function are the same as grad_gbs2gas
hessian_gbs2gas = function(theta,p,q,beta0,p.fixed=NULL,q.fixed=NULL){
  
  N = length(GASdata)
  w = theta[1]
  A = theta[2:(p+1)]
  B = theta[(p+2):(p+q+1)]
  alpha = theta[(p+q+2)]
  nu = theta[(p+q+3)]
  m = max(max(p.fixed),max(q.fixed))
  y_t = GASdata
  # scaling factor (inverse of beta's information)
  S_alpha_nu = S_t(alpha,nu)
  # first derivative of the scaling factor with respect to alpha
  dS_da = dS_t(alpha,nu)
  # second derivative of the scaling factor with respect to alpha
  d2S_da2 = d2S_da2_t(alpha,nu)
  
  beta_t = rep(0,N)
  f_t = rep(0,N+1)
  s_t = rep(0,N)
  # this matrix Z will store the values varying in time of the
  # vector z_t = (1,s_{t-1},...,s_{t-p},f_{t-1},...,f_{t-q})'
  Z = matrix(0,nrow=p+q+1,ncol=(N+1))
  Z[1,] = rep(1,N+1)
  
  beta_t[1:length(beta0)] = beta0
  f_t[1:length(beta0)] = log(beta0)
  for(t in 1:(m-1)){
    beta_t[t] = exp(f_t[t])
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
  }
  for(t in m:N){
    beta_t[t] = exp(f_t[t])
    s_t[t] = S_alpha_nu * 
      nu*(((y_t[t]/beta_t[t])^(2*nu) - (beta_t[t]/y_t[t])^(2*nu))/(alpha^2) -
            ((y_t[t]/beta_t[t])^nu - (beta_t[t]/y_t[t])^nu)/((y_t[t]/beta_t[t])^nu + (beta_t[t]/y_t[t])^nu))
    f_t[t+1] = w
    for(i in 1:p){
      f_t[t+1] = f_t[t+1] + A[i]*s_t[t-p.fixed[i]+1]
      Z[i+1,t+1] = s_t[t-p.fixed[i]+1]
    } 
    for(i in 1:q){
      f_t[t+1] = f_t[t+1] + B[i]*f_t[t-q.fixed[i]+1]
      Z[i+p+1,t+1] = f_t[t-q.fixed[i]+1]
    } 
  }
  
  # loop to compute the components used in the first derivatives
  # of the GAS models' fixed parameters
  df_dtheta1 = matrix(0,p+q+1,N)
  df_alpha = rep(0,N)
  df_nu = rep(0,N)
  for(t in (m+1):N){
    df_dtheta1[,t] = Z[,t]
    for(i in 1:q){
      df_dtheta1[,t] = df_dtheta1[,t] + B[i]*df_dtheta1[,t-q.fixed[i]]
      df_alpha[t] = df_alpha[t] + B[i]*df_alpha[t-q.fixed[i]]
      df_nu[t] = df_nu[t] + B[i]*df_nu[t-q.fixed[i]]
    }
    for(i in 1:p){
      # components corresponding to the GAS parameters
      dD_dbt = dDelta_db_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      df_dtheta1[,t] = df_dtheta1[,t] + 
        A[i]*S_alpha_nu*df_dtheta1[,t-p.fixed[i]]*
        beta_t[t-p.fixed[i]]*
        dD_dbt
      # components corresponding to alpha
      dD_da = dDelta_dalpha_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu) +
        dD_dbt*beta_t[t-p.fixed[i]]*df_alpha[t-q.fixed[i]]
      df_alpha[t] = df_alpha[t] + 
        A[i]*
        (S_alpha_nu*dD_da + 
           Delta_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)*dS_t(alpha,nu))
      # components corresponding to nu
      dD_dnu = dDelta_dnu_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu) +
        dD_dbt*beta_t[t-p.fixed[i]]*df_nu[t-q.fixed[i]]
      df_nu[t] = df_nu[t] + 
        A[i]*S_alpha_nu*
        (dD_dnu - 
           2*Delta_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)/nu)
    }
  }
  
  # loop to compute the second derivatives of the
  # time varying parameter f_t
  md2f_d2theta1 = array(0,dim=c(p+q+1,p+q+1,N))
  d2f_dalpha2 = rep(0,N)
  d2f_dnu2 = rep(0,N)
  d2f_dtheta1_dalpha = matrix(0,p+q+1,N)
  d2f_dtheta1_dnu = matrix(0,p+q+1,N)
  d2f_dnu_dalpha = rep(0,N)
  for(t in (m+1):N){
    mM_t = rep(0,p+q+1)
    mN = matrix(0,p+q+1,p+q+1)
    mQ = matrix(0,p+q+1,p+q+1)
    for(i in 1:p){
      D = Delta_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      # components corresponding to the GAS parameters
      dD_dbt = dDelta_db_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      mM_t = cbind(mM_t,S_alpha_nu*dD_dbt*
                     beta_t[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]])
      mN = mN + S_alpha_nu*dD_dbt*beta_t[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]]%*%t(base_vec(p+q+1,i+1)) + 
        A[i]*S_alpha_nu*d2Delta_db2_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)*
        (beta_t[t-p.fixed[i]]^2)*df_dtheta1[,t-p.fixed[i]]%*%t(df_dtheta1[,t-p.fixed[i]]) + 
        A[i]*S_alpha_nu*beta_t[t-p.fixed[i]]*dD_dbt*md2f_d2theta1[,,t-p.fixed[i]] + 
        A[i]*S_alpha_nu*beta_t[t-p.fixed[i]]*dD_dbt*df_dtheta1[,t-p.fixed[i]]%*%t(df_dtheta1[,t-p.fixed[i]])
      # components corresponding to alpha
      d2D_dbt2 = d2Delta_db2_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      d2D_dbt_da = d2Delta_dbt_dalpha_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      dD_da = dDelta_dalpha_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu) +
        dD_dbt*beta_t[t-p.fixed[i]]*df_alpha[t-q.fixed[i]]
      d2D_da2 = 6*nu*
        ((y_t[t-p.fixed[i]]/beta_t[t-p.fixed[i]])^(2*nu) - (beta_t[t-p.fixed[i]]/y_t[t-p.fixed[i]])^(2*nu))/(alpha^4)+
        4*(nu^2)*
        ((y_t[t-p.fixed[i]]/beta_t[t-p.fixed[i]])^(2*nu) + (beta_t[t-p.fixed[i]]/y_t[t-p.fixed[i]])^(2*nu))*
        df_alpha[t-p.fixed[i]]/(alpha^3) +
        dD_dbt*beta_t[t-p.fixed[i]]*(d2f_dalpha2[t-p.fixed[i]] + (df_alpha[t-p.fixed[i]])^2) + 
        beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]]*(d2D_dbt_da + d2D_dbt2*beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]])
      d2f_dalpha2[t] = d2f_dalpha2[t] + 
        A[i]*(S_alpha_nu*d2D_da2 + 2*dS_da*dD_da +
                Delta_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)*d2S_da2)
      # components corresponding to nu
      dD_dnu = dDelta_dnu_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu) +
        dD_dbt*beta_t[t-p.fixed[i]]*df_nu[t-p.fixed[i]]
      d2D_dbt_dnu = d2Delta_dbt_dnu_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      d2D_dnu2 = d2Delta_dnu2_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      h = d2D_dnu2 + beta_t[t-p.fixed[i]]*df_nu[t-p.fixed[i]]*(
        2*d2D_dbt_dnu + d2D_dbt2*beta_t[t-p.fixed[i]]*df_nu[t-p.fixed[i]]) +
        dD_dbt*beta_t[t-p.fixed[i]]*((df_nu[t-p.fixed[i]])^2 + d2f_dnu2[t-p.fixed[i]]) +
        2*D/(nu^2) - 2*dD_dnu/nu
      d2f_dnu2[t] = d2f_dnu2[t] + 
        A[i]*S_alpha_nu*(-2*(dD_dnu - 2*D/nu)/nu + h)
      # components corresponding to alpha and the GAS parameters
      d2f_dtheta1_dalpha[,t] = d2f_dtheta1_dalpha[,t] +
        (S_alpha_nu*dD_da + D*dS_da)*base_vec(p+q+1,i+1) +
        A[i]*( S_alpha_nu*(d2D_dbt_da*beta_t[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]] +
                             d2D_dbt2*(beta_t[t-p.fixed[i]]^2)*df_alpha[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]] +
                             dD_dbt*beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]] +
                             dD_dbt*beta_t[t-p.fixed[i]]*d2f_dtheta1_dalpha[,t-p.fixed[i]]) +
                 dS_da*dD_dbt*beta_t[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]])
      # components corresponding to nu and the GAS parameters
      d2f_dtheta1_dnu[,t] = d2f_dtheta1_dnu[,t] +
        S_alpha_nu*(dD_dnu - 2*D/nu)*base_vec(p+q+1,i+1) +
        A[i]*S_alpha_nu*( d2D_dbt_dnu*beta_t[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]] +
                            d2D_dbt2*(beta_t[t-p.fixed[i]]^2)*df_nu[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]] +
                            dD_dbt*beta_t[t-p.fixed[i]]*df_nu[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]] +
                            dD_dbt*beta_t[t-p.fixed[i]]*d2f_dtheta1_dnu[,t-p.fixed[i]] -
                            2*dD_dbt*beta_t[t-p.fixed[i]]*df_dtheta1[,t-p.fixed[i]]/nu)
      # components corresponding to nu and alpha
      d2D_da_dnu = d2Delta_dalpha_dnu_t(y_t[t-p.fixed[i]],alpha,beta_t[t-p.fixed[i]],nu)
      d2f_dnu_dalpha[t] = d2f_dnu_dalpha[t] +
        A[i]*( dS_da*(dD_dnu - 2*D/nu) +
                 S_alpha_nu*( d2D_da_dnu + d2D_dbt_dnu*beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]] +
                                beta_t[t-p.fixed[i]]*df_nu[t-p.fixed[i]]*(d2D_dbt_da +
                                                                            d2D_dbt2*beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]]) +
                                dD_dbt*df_nu[t-p.fixed[i]]*beta_t[t-p.fixed[i]]*df_alpha[t-p.fixed[i]] +
                                dD_dbt*beta_t[t-p.fixed[i]]*d2f_dnu_dalpha[t-p.fixed[i]] -
                                2*dD_da/nu))
    }
    for(i in 1:q){
      # components corresponding to the GAS parameters
      mM_t = cbind(mM_t,df_dtheta1[,t-q.fixed[i]])
      mQ = mQ + df_dtheta1[,t-q.fixed[i]]%*%t(base_vec(p+q+1,1+p+i)) + 
        B[i]*md2f_d2theta1[,,t-q.fixed[i]]
      # components corresponding to alpha
      d2f_dalpha2[t] = d2f_dalpha2[t] + 
        B[i]*d2f_dalpha2[t-q.fixed[i]]
      # components corresponding to nu
      d2f_dnu2[t] = d2f_dnu2[t] +
        B[i]*d2f_dnu2[t-q.fixed[i]]
      # components corresponding to alpha and the GAS parameters
      d2f_dtheta1_dalpha[,t] = d2f_dtheta1_dalpha[,t] + 
        df_alpha[t-q.fixed[i]]*base_vec(p+q+1,1+p+i) + B[i]*d2f_dtheta1_dalpha[,t-q.fixed[i]]
      # components corresponding to nu and the GAS parameters
      d2f_dtheta1_dnu[,t] = d2f_dtheta1_dnu[,t] +
        df_nu[t-q.fixed[i]]*base_vec(p+q+1,1+p+i) + B[i]*d2f_dtheta1_dnu[,t-q.fixed[i]]
      # components corresponding to nu and alpha
      d2f_dnu_dalpha[t] = d2f_dnu_dalpha[t] + B[i]*d2f_dnu_dalpha[t-q.fixed[i]]
    }
    # components corresponding to the GAS parameters
    md2f_d2theta1[,,t] = t(mM_t) + mN + mQ
  }
  
  # loop to compute the second derivatives of the
  # log-likelihood function of the GAS model
  d2loglik_dtheta2 = matrix(0,p+q+1,p+q+1)
  d2loglik_dalpha2 = 0
  d2loglik_dnu2 = 0
  d2loglik_dtheta_dalpha = rep(0,p+q+1)
  d2loglik_dtheta_dnu = rep(0,p+q+1)
  d2loglik_dnu_dalpha = 0
  for(t in (m+1):N){
    # second derivative of the loglik corresponding to the GAS parameters
    D = Delta_t(y_t[t],alpha,beta_t[t],nu)
    d2loglik_dtheta2 = d2loglik_dtheta2 + dDelta_db_t(y_t[t],alpha,beta_t[t],nu)*
      beta_t[t]*df_dtheta1[,t]%*%t(df_dtheta1[,t]) +
      D*md2f_d2theta1[,,t]
    # second derivative of the loglik corresponding to alpha
    dD_dbt = dDelta_db_t(y_t[t],alpha,beta_t[t],nu)
    dD_da = dDelta_dalpha_t(y_t[t],alpha,beta_t[t],nu) +
      dD_dbt*beta_t[t]*df_alpha[t]
    hess_loglik_t = hessian_gbs2(y_t[t],alpha,beta_t[t],nu)
    d2loglik_dalpha2 = d2loglik_dalpha2 + hess_loglik_t[1,1] + 
      hess_loglik_t[1,2]*beta_t[t]*df_alpha[t] + 
      df_alpha[t]*dD_da + D*d2f_dalpha2[t]
    # second derivative of the loglik corresponding to nu
    dD_dnu = dDelta_dnu_t(y_t[t],alpha,beta_t[t],nu) +
      dD_dbt*beta_t[t]*df_nu[t]
    d2loglik_dnu2 = d2loglik_dnu2 + hess_loglik_t[3,3] +
      hess_loglik_t[3,2]*beta_t[t]*df_nu[t] +
      df_nu[t]*dD_dnu + D*d2f_dnu2[t]
    # second derivative of the loglik corresponding to alpha and the GAS parameters
    d2loglik_dtheta_dalpha = d2loglik_dtheta_dalpha +
      df_dtheta1[,t]*dD_da + D*d2f_dtheta1_dalpha[,t]
    # second derivative of the loglik corresponding to nu and the GAS parameters
    d2loglik_dtheta_dnu = d2loglik_dtheta_dnu +
      df_dtheta1[,t]*dD_dnu + D*d2f_dtheta1_dnu[,t]
    # second derivative of the loglik corresponding to nu and alpha
    d2loglik_dnu_dalpha = d2loglik_dnu_dalpha + hess_loglik_t[1,3] + 
      hess_loglik_t[2,3]*beta_t[t]*df_alpha[t] + df_nu[t]*dD_da + D*d2f_dnu_dalpha[t]
  }
  
  # Hessian matrix of all fixed parameters
  mJ = matrix(0,p+q+3,p+q+3)
  mJ[1:(p+q+1),1:(p+q+1)] = d2loglik_dtheta2
  mJ[1:(p+q+1),p+q+2] = d2loglik_dtheta_dalpha
  mJ[p+q+2,1:(p+q+1)] = t(mJ[1:(p+q+1),p+q+2])
  mJ[1:(p+q+1),p+q+3] = d2loglik_dtheta_dnu
  mJ[p+q+3,1:(p+q+1)] = t(mJ[1:(p+q+1),p+q+3])
  mJ[p+q+2,p+q+2] = d2loglik_dalpha2
  mJ[p+q+2,p+q+3] = mJ[p+q+3,p+q+2] = d2loglik_dnu_dalpha
  mJ[p+q+3,p+q+3] = d2loglik_dnu2
  
  return(mJ)
}
