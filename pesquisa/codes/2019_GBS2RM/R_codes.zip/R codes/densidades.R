# Gráfico da densidade GBS2 para diferentes valores dos parâmetros

source("GBS2RM_functions.R")

#postscript(file="GBS2pdf.ps",horizontal = TRUE)
postscript(file="GBS2pdf.ps",horizontal = FALSE, width = 14.0, height = 6.0,
           paper="special")
par(mfrow=c(1,3))
curve(dgbs2(x,1,1,1),xlim=c(0.01,2),lty=1,lwd=1.3,ylab="f(x)",ylim=c(0,3),
      cex.axis=1.5,cex.lab=1.5,cex.sub=1.5,sub="(a)")
curve(dgbs2(x,1,1,1.5),xlim=c(0.01,2),add=TRUE,lty=2,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
curve(dgbs2(x,1,1,2),xlim=c(0.01,2),add=TRUE,lty=4,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
curve(dgbs2(x,1,1,3),xlim=c(0.01,2),add=TRUE,lty=3,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
text(1.6,3,expression(paste(alpha,"=",1,", ",eta,"=",1)),cex=1.5)
legend(1.3,2.9,lty=c(1,2,4,3),bty="n",
       legend=expression(paste(nu,"=",1),paste(nu,"=",1.5),
                         paste(nu,"=",2),paste(nu,"=",3)),cex=1.5)


curve(dgbs2(x,.3,1,1),xlim=c(0.01,2),lty=1,lwd=1.3,ylab="f(x)",ylim=c(0,3),
      cex.axis=1.5,cex.lab=1.5,cex.sub=1.5,sub="(b)")
curve(dgbs2(x,1,1,1),xlim=c(0.01,2),add=TRUE,lty=2,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
curve(dgbs2(x,1.5,1,1),xlim=c(0.01,2),add=TRUE,lty=4,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
curve(dgbs2(x,3,1,1),xlim=c(0.01,2),add=TRUE,lty=3,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
text(1.6,3,expression(paste(nu,"=",1,", ",eta,"=",1)),cex=1.5)
legend(1.3,2.9,lty=c(1,2,4,3),bty="n",
       legend=expression(paste(alpha,"=",0.3),paste(alpha,"=",1),
                         paste(alpha,"=",1.5),paste(alpha,"=",3)),cex=1.5)


curve(dgbs2(x,2.5,1,1),xlim=c(0.01,2),lty=1,lwd=1.3,ylab="f(x)",ylim=c(0,3),
      cex.axis=1.5,cex.lab=1.5,cex.sub=1.5,sub="(c)")
curve(dgbs2(x,1,1,2.5),xlim=c(0.01,2),add=TRUE,lty=2,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
curve(dgbs2(x,2,1,2),xlim=c(0.01,2),add=TRUE,lty=4,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
curve(dgbs2(x,5,1,5),xlim=c(0.01,2),add=TRUE,lty=3,lwd=1.3,ylab="f(x)",ylim=c(0,3),cex.axis=2,cex.lab=1.5,cex.sub=1.5)
text(1.5,3,expression(paste(eta,"=",1)),cex=1.5)
legend(1.1,2.9,lty=c(1,2,4,3),bty="n",
       legend=expression(paste(alpha,"=",2.5,","~nu,"=",1),
                         paste(alpha,"=",1,","~nu,"=",2.5),
                         paste(alpha,"=",2,","~nu,"=",2),
                         paste(alpha,"=",5,","~nu,"=",5)),cex=1.5)
dev.off()


####################################################################
####################################################################


