source("GBS2RM_functions.R")

require(lattice)   # vai ser usado pra fazer gr?fico de contorno
leukemia = read.table("leukemia.mat",sep=",",header=FALSE)
dim(leukemia)

ydat = log(leukemia[,2])
x2 = log(leukemia[,1])
x3 = leukemia[,3]
n = length(ydat)
p = 3
Xdat = cbind(rep(1,n),x2,x3)
#cbind(ydat,Xdat)
hist(ydat[which(x3==0)],prob=TRUE,xlab = "y",ylab="Frequ?ncia",main="",
     sub="(b)",cex.axis=1.5,cex.lab=1.5,xlim=c(0,6),col=rgb(0.1,0.1,0.1,0.5))
hist(ydat[which(x3==1)],prob=TRUE,xlab = "y",ylab="Frequ?ncia",main="",
     sub="(b)",cex.axis=1.5,cex.lab=1.5,xlim=c(0,6),add=T,col=rgb(0.8,0.8,0.8,0.5))
legend(4,.8,c(expression(x[3]~"=0"),expression(x[3]~"=1")),
       fill=c(rgb(0.1,0.1,0.1,0.5),rgb(0.8,0.8,0.8,0.5)),bty='n')

postscript(file="disp_boxplot_dados.eps",horizontal=FALSE, width=10.0, height=5.0,
           paper="special")
par(mfrow=c(1,3))
plot(x2,ydat,ylab = "y", xlab = expression(x[2]),main="",
     sub="(a)",cex.axis=1.5,cex.lab=1.5,pch=x3,cex=1.5)
legend(6.5,1,c(expression(x[3]~"=0"),expression(x[3]~"=1")),pch=c(0,1),
       bty='n',cex=2)
boxplot(ydat~x3,xlab=expression(x[3]),ylab=expression(y),names=c("0","1"),sub="(b)",
        cex.axis=1.5,cex.lab=1.5)
boxplot(x2~x3,xlab=expression(x[3]),ylab=expression(x[2]),names=c("0","1"),sub="(c)",
        cex.axis=1.5,cex.lab=1.5)
dev.off()

# Estimativa do modelo MRBS
theta_bs = c(7.2929, -0.50583, 0.67364, 1.3654,.5)
# estimativa de m?xima verossimilhan?a do modelo MRGBS2
theta_gbs2 = c(6.1595, -0.36055, 0.055097, 6.9141, 1.2725)
J = -gbs2rm_hessian(theta_gbs2,ydat,Xdat)
Ji = solve(J)

sqrt(diag(Ji))
theta_gbs2

############################################################
# Teste de raz?o de verossimilhan?as
# H0: nu = .5
# H1: nu!= 0.5

W_stat = 2*(gbs2rm_loglik(theta_gbs2,ydat,Xdat) - gbs2rm_loglik(theta_bs,ydat,Xdat))
qchisq(.05,1,lower.tail=TRUE)
1 - pchisq(W_stat,1)

############################################################
# Crit?rios de qualidade do ajuste

AICgbs2 = -2*gbs2rm_loglik(theta_gbs2,ydat,Xdat) + (p+2)*2; AICgbs2
BICgbs2 = -2*gbs2rm_loglik(theta_gbs2,ydat,Xdat) + (p+2)*log(n); BICgbs2
AICbs = -2*gbs2rm_loglik(theta_bs,ydat,Xdat) + (p+1)*2; AICbs
BICbs = -2*gbs2rm_loglik(theta_bs,ydat,Xdat) + (p+1)*log(n); BICbs

############################################################
# Gr?fico de res?duos contra valores ajustados

# valores ajustados
vbeta = theta_gbs2[c(1:p)]
vmu = Xdat%*%vbeta

resid_shn = gbs2rm_resid(theta_gbs2,ydat,Xdat,type="lGBS2")
plot(vmu,resid_shn,xlab="Valores preditos",ylab=expression(r[SHN]),
     sub="(a)",cex.axis=1.5,cex.lab=1.5)
abline(h=c(qnorm(.975),qnorm(.025)),lty=2,lwd=1.5)
#identify(vmu,resid_shn,n=2)

resid_csg = gbs2rm_resid(theta_gbs2,ydat,Xdat,type="CoxSnell")
plot(vmu,resid_csg,xlab="Valores preditos",ylab=expression(r[CSG]),
     sub="(b)",cex.axis=1.5,cex.lab=1.5)
abline(h=c(qexp(.95)),lty=2,lwd=1.5)
#identify(vmu,resid_csg,n=2)

############################################################
# gr?ficos de envelope simulado dos res?duos SHN e CSG

# Os elementos da matriz est?o dispostos da seguinte maneira
# coluna 1:estat?sticas de ordem dos res?duos do ajuste
# coluna 2:banda simulada de 2.5%
# coluna 3:m?dia das estat. de ordem dos res?duos simulados
# coluna 4:banda simulada de 97.5%
m_rSHN = read.table("leukemia_rSHN_Envel.mat")
m_rCSG = read.table("leukemia_rCSG_Envel.mat")

# 46 pontos igualmente espacados em (0,1), tirando os dois das pontas
pont_esp = ppoints(n)

# Envolope dos res?duos SHN
matplot(m_rSHN,qnorm(pont_esp),type=c("p","l","l","l"),pch=20,lty=c(1,1,2,1),col=rep(1,4),
        lwd=1.5,ylab="Quantis empíricos",xlab="Quantis assintóticos",
        sub="(c)",cex.axis=1.5,cex.lab=1.5)

# Envolope dos res?duos CSG
matplot(m_rCSG,qexp(pont_esp),type=c("p","l","l","l"),pch=20,lty=c(1,1,2,1),col=rep(1,4),
        lwd=1.5,ylab="Quantis empíricos",xlab="Quantis assintóticos",
        sub="(d)",cex.axis=1.5,cex.lab=1.5)

# gerando o gr?fico dos res?duos
postscript(file="resid_analysis.eps",horizontal = FALSE, width = 10.0, height = 10.0,
           paper="special")
par(mfrow=c(2,2))
# residuos x valores ajustados: SHN
# residuos x valores ajustados: CSG
# envelope simulado: SHN
# envelope simulado: CSG
dev.off()


############################################################
# An?lise de influ?ncia local

# pondera??o de casos
mDelta = gbs2rm_perturbationmat(theta_gbs2,ydat,Xdat,perturbation="caseweight")
B1 = matrix(0,(p+2),(p+2)); B1[c(4,5),c(4,5)] = Ji[c(4,5),c(4,5)]
mB = t(mDelta)%*%(Ji - B1)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(a)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,abs(lmax)[cord],cord)
cord = 15; text(cord+1,abs(lmax)[cord],cord)
cord = 17; text(cord,abs(lmax)[cord]+.02,cord)
#identify(c(1:n),abs(lmax),n=3)
# lmax para os par?metros de forma
B2 = matrix(0,(p+2),(p+2)); B2[c(1:p),c(1:p)] = Ji[c(1:p),c(1:p)]
mB = t(mDelta)%*%(Ji - B2)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(b)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=5)


# perturba??o na vari?vel resposta
# lmax para o vetor beta
mDelta = gbs2rm_perturbationmat(theta_gbs2,ydat,Xdat,perturbation="response")
B1 = matrix(0,(p+2),(p+2)); B1[c(4,5),c(4,5)] = Ji[c(4,5),c(4,5)]
mB = t(mDelta)%*%(Ji - B1)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(c)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,abs(lmax)[cord],cord)
cord = 15; text(cord+1,abs(lmax)[cord],cord)
cord = 17; text(cord,abs(lmax)[cord]+.02,cord)
#identify(c(1:n),abs(lmax),n=3)
# lmax para os par?metros de forma
B2 = matrix(0,(p+2),(p+2)); B2[c(1:p),c(1:p)] = Ji[c(1:p),c(1:p)]
mB = t(mDelta)%*%(Ji - B2)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(d)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,abs(lmax)[cord],cord)
cord = 15; text(cord+1,abs(lmax)[cord],cord)
cord = 17; text(cord,abs(lmax)[cord]+.02,cord)
#identify(c(1:n),abs(lmax),n=5)


# perturba??o na vari?vel explicativa
# lmax para o vetor beta
mDelta = gbs2rm_perturbationmat(theta_gbs2,ydat,Xdat,perturbation="predictor",pred_pert=2)
B1 = matrix(0,(p+2),(p+2)); B1[c(4,5),c(4,5)] = Ji[c(4,5),c(4,5)]
mB = t(mDelta)%*%(Ji - B1)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(e)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,abs(lmax)[cord],cord)
cord = 15; text(cord+1,abs(lmax)[cord],cord)
cord = 17; text(cord,abs(lmax)[cord]+.02,cord)
#identify(c(1:n),abs(lmax),n=3)
# lmax para os par?metros de forma
B2 = matrix(0,(p+2),(p+2)); B2[c(1:p),c(1:p)] = Ji[c(1:p),c(1:p)]
mB = t(mDelta)%*%(Ji - B2)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(f)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,abs(lmax)[cord],cord)
cord = 15; text(cord+1,abs(lmax)[cord],cord)
cord = 17; text(cord,abs(lmax)[cord]+.02,cord)
#identify(c(1:n),abs(lmax),n=5)

# gerando o gr?ficos de influ?ncia local
postscript(file="influencia_local.eps",horizontal = FALSE, width = 8.0, height = 15.0,
           paper="special")
par(mfrow=c(3,2))
# pondera??o de casos: beta
# pondera??o de casos: par?metros de formas
# perturba??o na resposta: beta
# perturba??o na resposta: par?metros de formas
# perturba??o no preditor: beta
# perturba??o no preditor: par?metros de formas
dev.off()


############################################################
# Alavanca generalizada
gl = gbs2rm_leverage(theta_gbs2,ydat,Xdat,type="beta")

# gerando o gr?fico de alavanca generalizada para beta
postscript(file="alavanca_gen.eps",horizontal = FALSE, width = 10.0, height = 6.0,
           paper="special")
par(mfrow=c(1,1))
plot(c(1:n),diag(gl),type="h",axes=FALSE,ylab=expression("GL("~beta~")"[ii]),
     xlab="?ndice")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 2; text(cord+1,diag(gl)[cord],cord)
cord = 21; text(cord+1,diag(gl)[cord],cord)
dev.off()
#diag(gl)
#diag(Xdat%*%solve(t(Xdat)%*%Xdat)%*%t(Xdat))

############################################################
# Dist?ncia de Cook generalizada
# para o vetor de par?metros theta
GD_theta = sapply(1:n, function(x) gbs2rm_gcookdist(theta_gbs2,x,ydat,Xdat)$GD_theta)
GD_beta = sapply(1:n, function(x) gbs2rm_gcookdist(theta_gbs2,x,ydat,Xdat)$GD_beta)
GD_shape = sapply(1:n, function(x) gbs2rm_gcookdist(theta_gbs2,x,ydat,Xdat)$GD_shape)

# gr?ficos de GD para o vetor completo de par?metros do modelo
plot(c(1:n),GD_theta,type="h",axes=FALSE,ylab=expression("GD("~theta~")"),
     xlab="?ndice",sub="(a)")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,GD_theta[cord],cord)
cord = 15; text(cord+1,GD_theta[cord],cord)
cord = 17; text(cord+1,GD_theta[cord],cord)

# para o vetor de par?metros beta
plot(c(1:n),GD_beta,type="h",axes=FALSE,ylab=expression("GD("~beta~")"),
     xlab="?ndice",sub="(b)")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,GD_beta[cord],cord)
cord = 15; text(cord+1,GD_beta[cord],cord)
cord = 17; text(cord+1,GD_beta[cord],cord)

# para o vetor de par?metros de forma
plot(c(1:n),GD_shape,type="h",axes=FALSE,ylab=expression("GD("~alpha~","~nu~")"),
     xlab="?ndice",sub="(c)")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
cord = 14; text(cord-1,GD_shape[cord],cord)
cord = 15; text(cord+1,GD_shape[cord],cord)
cord = 17; text(cord+1,GD_shape[cord],cord)

# gerando o gr?ficos das dist?ncias de Cook generalizadas
postscript(file="gen_cookdist.eps",horizontal = FALSE, width = 10.0, height = 5.0,
           paper="special")
par(mfrow=c(1,3))
# dist?ncia de Cook generalizada: theta
# dist?ncia de Cook generalizada: beta
# dist?ncia de Cook generalizada: par?metros de forma
dev.off()


############################################################
# Analisando a fun??o de log-verossimilhan?a perfilada de alpha e nu

theta_L_alpha_nu = theta_gbs2
# fun??o de log-verossimilhan?a perfilada de alpha e nu
loglik_alpha_nu = function(alpha,nu){
  n = length(alpha); L = rep(0,n)
  for(i in 1:n){
    theta_L_alpha_nu[4] = alpha[i]; theta_L_alpha_nu[5] = nu[i]
    L[i] = gbs2rm_loglik(theta_L_alpha_nu,ydat,Xdat)
  }
  return(L)
}

# combina??es dos par?metros alpha e nu
v_alpha = seq(6,8,length=200)
v_nu = seq(1.2,1.4,length=200)
# gr?fico de contorno da fun??o de log-verossimilhan?a perfilada
fL_alpha_nu_contour = outer(v_alpha,v_nu,loglik_alpha_nu)
contour(v_alpha,v_nu,fL_alpha_nu_contour,nlevels=200,
        xlab=expression(alpha),ylab=expression(nu),
        sub="(a)",cex.axis=1.5,cex.lab=1)
points(theta_gbs2[4],theta_gbs2[5],pch=8,lwd=2)

############################################################
# Construindo intervalos de predição de 95% de confiaça

# Nessas matrizes estão intervalos de predição (IP) para as observações do banco de
# dados dos pacientes com leucemia. Cada observação foi retirada dos dados, o
# modelo foi re-ajustado e um IP de 95% de confiança foi calculado para a resposta
# eliminada dos dados. As observações 14 e 15 não foram consideradas nesse processo.

# intervalos percentil
PI_perc = read.table("leukemia_IntervPred_perc.txt")
# intervalos BCa
PI_BCa = read.table("leukemia_IntervPred_BCa.txt")
PI_perc = PI_perc[-c(14,15),]
PI_BCa = PI_BCa[-c(14,15),]

x2pred = x2[-c(14,15)]
ydatpred = ydat[-c(14,15)]
  
# porcentagem de cobertura das observações da variável resposta
100*sum((PI_perc[,1]<PI_perc[,2])*(PI_perc[,2]<PI_perc[,3]))/31
100*sum((PI_BCa[,1]<PI_BCa[,2])*(PI_BCa[,2]<PI_BCa[,3]))/31

# obtendo índice das observações de x2 ordenado
x2_index_sort = sort(x2pred,index.return=TRUE)
par(mfrow=c(1,2))
# gráfico com intervalos de predição percentil
plot(x2pred,ydatpred,ylim=c(-1,7),ylab = "y", xlab = expression(x[2]),main="",
     sub="(a)",cex.axis=1.5,cex.lab=1.5,cex=1,pch=20)
lines(x2pred[x2_index_sort$ix],PI_perc[x2_index_sort$ix,1])
lines(x2pred[x2_index_sort$ix],PI_perc[x2_index_sort$ix,3])
# gráfico com intervalos de predição BCa
plot(x2pred,ydatpred,ylim=c(-1,7),ylab = "y", xlab = expression(x[2]),main="",
     sub="(b)",cex.axis=1.5,cex.lab=1.5,cex=1,pch=20)
lines(x2pred[x2_index_sort$ix],PI_BCa[x2_index_sort$ix,1])
lines(x2pred[x2_index_sort$ix],PI_BCa[x2_index_sort$ix,3])

# Nessas matrizes estão IPs percentil e BCa para valores de x2 variando entre 6 e 12,
# para cada nível do fator AG.

# intervalos percentil
PI_Xnew0_perc = read.table("leukemia_IntervPred_Xnew0_perc.txt")
PI_Xnew1_perc = read.table("leukemia_IntervPred_Xnew1_perc.txt")
# intervalos BCa
PI_Xnew0_BCa = read.table("leukemia_IntervPred_Xnew0_BCa.txt")
PI_Xnew1_BCa = read.table("leukemia_IntervPred_Xnew1_BCa.txt")
xnew = c(0:99)*.06 + 6

postscript(file="PI_xnew.eps",horizontal = FALSE, width = 10.0, height = 6.0,
           paper="special")
par(mfrow=c(1,2))
plot(x2,ydat,ylim=c(-1,6),ylab = "y", xlab = expression(x[2]),main="",
     sub="(a)",cex.axis=1.5,cex.lab=1.5,cex=1,pch=x3)
text(c(11.3,11.5),c(-.1,-.25),c("14","15"))
lines(xnew,PI_Xnew0_perc[,1],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=1,lwd=1.3)
lines(xnew,PI_Xnew0_perc[,2],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=1,lwd=1.3)
lines(xnew,PI_Xnew1_perc[,1],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=2,lwd=1.3)
lines(xnew,PI_Xnew1_perc[,2],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=2,lwd=1.3)
legend(7.4,.5,c(expression(x[3]~"=0"),expression(x[3]~"=1")),pch=c(0,1),
       bty='n',cex=1.5)
legend(6.4,.5,lty=c(1,2),c("",""),
       bty='n',cex=1.5)

plot(x2,ydat,ylim=c(-1,6),ylab = "y", xlab = expression(x[2]),main="",
     sub="(b)",cex.axis=1.5,cex.lab=1.5,cex=1,pch=x3)
text(c(11.3,11.5),c(-.1,-.25),c("14","15"))
lines(xnew,PI_Xnew0_BCa[,1],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=1,lwd=1.3)
lines(xnew,PI_Xnew0_BCa[,2],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=1,lwd=1.3)
lines(xnew,PI_Xnew1_BCa[,1],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=2,lwd=1.3)
lines(xnew,PI_Xnew1_BCa[,2],cex.axis=1.5,cex.lab=1.5,cex=1,pch=20,type="l",lty=2,lwd=1.3)
legend(7.4,.5,c(expression(x[3]~"=0"),expression(x[3]~"=1")),pch=c(0,1),
       bty='n',cex=1.5)
legend(6.4,.5,lty=c(1,2),c("",""),
       bty='n',cex=1.5)
dev.off()

##################################################################################
##################################################################################
##################################################################################

# Analise do modelo sem os pontos 14 e 15

ydat = log(leukemia[-c(14,15),2])
x2 = log(leukemia[-c(14,15),1])
x3 = leukemia[-c(14,15),3]
n = length(ydat)
Xdat = cbind(rep(1,n),x2,x3)

# estimativa de m?xima verossimilhan?a do modelo MRGBS2
theta_gbs2 = c(4.2195, -0.17864, 0.64292, 11.135, 1.8068)
J = -gbs2rm_hessian(theta_gbs2,ydat,Xdat)
Ji = solve(J)


############################################################
# An?lise de influ?ncia local

# pondera??o de casos
mDelta = gbs2rm_perturbationmat(theta_gbs2,ydat,Xdat,perturbation="caseweight")
B1 = matrix(0,(p+2),(p+2)); B1[c(4,5),c(4,5)] = Ji[c(4,5),c(4,5)]
mB = t(mDelta)%*%(Ji - B1)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(a)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=3)
# lmax para os par?metros de forma
B2 = matrix(0,(p+2),(p+2)); B2[c(1:p),c(1:p)] = Ji[c(1:p),c(1:p)]
mB = t(mDelta)%*%(Ji - B2)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(b)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=5)


# perturba??o na vari?vel resposta
# lmax para o vetor beta
mDelta = gbs2rm_perturbationmat(theta_gbs2,ydat,Xdat,perturbation="response")
B1 = matrix(0,(p+2),(p+2)); B1[c(4,5),c(4,5)] = Ji[c(4,5),c(4,5)]
mB = t(mDelta)%*%(Ji - B1)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(c)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=3)
# lmax para os par?metros de forma
B2 = matrix(0,(p+2),(p+2)); B2[c(1:p),c(1:p)] = Ji[c(1:p),c(1:p)]
mB = t(mDelta)%*%(Ji - B2)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(d)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=5)


# perturba??o na vari?vel explicativa
# lmax para o vetor beta
mDelta = gbs2rm_perturbationmat(theta_gbs2,ydat,Xdat,perturbation="predictor",pred_pert=2)
B1 = matrix(0,(p+2),(p+2)); B1[c(4,5),c(4,5)] = Ji[c(4,5),c(4,5)]
mB = t(mDelta)%*%(Ji - B1)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(e)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=3)
# lmax para os par?metros de forma
B2 = matrix(0,(p+2),(p+2)); B2[c(1:p),c(1:p)] = Ji[c(1:p),c(1:p)]
mB = t(mDelta)%*%(Ji - B2)%*%mDelta
lmax = eigen(mB)$vectors[,1]
plot(c(1:n),abs(lmax),type="h",axes=FALSE,ylab=expression("|"~l[max]~"|"),
     xlab="?ndice",sub="(f)",ylim=c(0,1))
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#identify(c(1:n),abs(lmax),n=5)


############################################################
# Alavanca generalizada
gl = gbs2rm_leverage(theta_gbs2,ydat,Xdat,type="beta")

par(mfrow=c(1,1))
plot(c(1:n),diag(gl),type="h",axes=FALSE,ylab=expression("GL("~beta~")"[ii]),
     xlab="?ndice")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
#diag(gl)
#diag(Xdat%*%solve(t(Xdat)%*%Xdat)%*%t(Xdat))

############################################################
# Dist?ncia de Cook generalizada
# para o vetor de par?metros theta
GD_theta = sapply(1:n, function(x) gbs2rm_gcookdist(theta_gbs2,x,ydat,Xdat)$GD_theta)
GD_beta = sapply(1:n, function(x) gbs2rm_gcookdist(theta_gbs2,x,ydat,Xdat)$GD_beta)
GD_shape = sapply(1:n, function(x) gbs2rm_gcookdist(theta_gbs2,x,ydat,Xdat)$GD_shape)

# gr?ficos de GD para o vetor completo de par?metros do modelo
plot(c(1:n),GD_theta,type="h",axes=FALSE,ylab=expression("GD("~theta~")"),
     xlab="?ndice",sub="(a)")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)
# para o vetor de par?metros beta
plot(c(1:n),GD_beta,type="h",axes=FALSE,ylab=expression("GD("~beta~")"),
     xlab="?ndice",sub="(b)")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)

# para o vetor de par?metros de forma
plot(c(1:n),GD_shape,type="h",axes=FALSE,ylab=expression("GD("~alpha~","~nu~")"),
     xlab="?ndice",sub="(c)")
axis(2)
axis(1, at = c(1:n), labels = c(1:n),cex.axis=.7)

