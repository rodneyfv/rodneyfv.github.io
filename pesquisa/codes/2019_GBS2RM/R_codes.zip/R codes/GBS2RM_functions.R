require(numDeriv)
require(maxLik)

# Gerador de ocorrencias aleatorias do modelo GBS2(a,b,nu)
rgbs2 = function(n,a=1,b=1,nu=1){
  z = rnorm(n)
  t = b*((.5*a*z) + sqrt((.5*a*z)^2 + 1))^(1/nu)
  return(t)
}

# funcao densidade do modelo GBS2(a,b,nu)
dgbs2 = function(t,a=1,b=1,nu=1){
  nu*((t/b)^nu + (b/t)^nu)*exp(-.5*((t/b)^(2*nu) + (b/t)^(2*nu) - 2)/(a^2))/
    (t*a*sqrt(2*pi))
}

# funcao distribuicao do modelo GBS2(a,b,nu)
pgbs2 = function(t,a=1,b=1,nu=1){
  pnorm(((t/b)^nu - (b/t)^nu)/a)
}

#funcao taxa de falha da distribuicao GBS2(a,b,nu)
hrgbs2 = function(t,a=1,b=1,nu=1){
  dgbs2(t,a,b,nu)/(1 - pgbs2(t,a,b,nu))
}

# momento de ordem r da distribuicao GBS2(a,b,nu)
moment_gbs2 = function(r,a,b,nu){
  (b^r)*exp(a^(-2))*(besselK(a^(-2),(r/nu + 1)/2) + besselK(a^(-2),(r/nu - 1)/2))/(a*sqrt(2*pi))
}

# momento de ordem r da distribuicao GBS2(a,b,nu)
hessian_gbs2 = function(x,a,b,nu){
  H = matrix(0,3,3)
  H[1,1] = sum(a^(-2) - 3*((x/b)^(2*nu)+(b/x)^(2*nu)-2)/(a^4))
  H[1,2] = H[2,1] = sum(-2*nu*((x/b)^(2*nu)-(b/x)^(2*nu))/(b*(a^3)))
  H[1,3] = H[3,1] = sum(2*log(x/b)*((x/b)^(2*nu)-(b/x)^(2*nu))/(a^3))
  H[2,2] = sum(-nu*((b/x)^(2*nu)-(x/b)^(2*nu)-4*nu)/((b^2)*((x/b)^nu+(b/x)^nu)^2) -
                 nu*((2*nu+1)*(x/b)^(2*nu)+(2*nu-1)*(b/x)^(2*nu))/((a^2)*(b^2)))
  H[2,3] = H[3,2] = sum(-(1/b)*((x/b)^(nu)-(b/x)^(nu))/((x/b)^(nu)+(b/x)^(nu)) -
                          nu*4*log(x/b)/(b*((x/b)^(nu)+(b/x)^(nu))^2) +
                          ((x/b)^(2*nu)-(b/x)^(2*nu))/(b*(a^2)) + 
                          nu*2*log(x/b)*((x/b)^(2*nu)+(b/x)^(2*nu))/(b*(a^2)))
  H[3,3] = sum(-1/nu^2 + 4*(log(x/b)/((x/b)^nu+(b/x)^nu))^2 -
                 2*(log(x/b)^2)*((x/b)^(2*nu)+(b/x)^(2*nu))/(a^2))
  return(H)
}

#############################################

# Gerador de ocorrencias aleatorias do modelo SHN(a,mu,sig)
rshn = function(n,a=1,mu=0,sig=2){
  z = rnorm(n)
  y = asinh(a*.5*z)*sig + mu
  return(y)
}

# funcao densidade do modelo SHN(a,mu,sig)
dshn = function(y,a=1,mu=0,sig=2){
  2*cosh((y-mu)/sig)*dnorm(2*sinh((y-mu)/sig)/a)/(a*sig)
}

# funcao distribuicao do modelo SHN(a,mu,sig)
pshn = function(y,a=1,mu=0,sig=2){
  pnorm(2*sinh((y-mu)/sig)/a)
}

a=1;mu=0;sig=1
#y = rgbs2(1000,a,mu,sig)
y = rshn(1000,a,mu,sig)
mean(y);mean(y^2);mean(y^3);mean(y^4)
#mean(log(y));mean(log(y)^2);mean(log(y)^3);mean(log(y)^4)
#moment_gbs2(1,a,mu,sig);moment_gbs2(2,a,mu,sig);moment_gbs2(3,a,mu,sig);moment_gbs2(4,a,mu,sig);
moment_gbs2(1,a,exp(mu),1/sig);moment_gbs2(2,a,exp(mu),1/sig);moment_gbs2(3,a,exp(mu),1/sig);moment_gbs2(4,a,exp(mu),1/sig);

#############################################

# Modelo de regressão GBS2 - GBS2RM

# função de log-verossimilhança do modelo GBS2RM
gbs2rm_loglik = function(theta,ydat,Xdat){
  # número de regressores
  p = length(theta) - 2
  # vetor dos parâmetros do preditor linear
  vbeta = theta[1:p]
  # parâmetros de forma alfa e nu
  alpha = theta[p+1]
  nu = theta[p+2]
  # preditor linear (valores ajustados)
  vmu = Xdat%*%vbeta
  # termos que compõem a função de verossimilhança 
  vxi1 = nu*cosh(nu*(ydat - vmu))/alpha
  vxi2 = 2*sinh(nu*(ydat - vmu))/alpha
  # função de log-verossimilhança
  ltheta = sum(log(2/sqrt(2*pi)) + log(vxi1) - .5*(vxi2^2))
  
  return(ltheta)
}

# função escore do modelo GBS2RM (gradiente da log-verossimilhança)
gbs2rm_score = function(theta,ydat,Xdat){
  # número de regressores
  p = length(theta) - 2
  # vetor dos parâmetros do preditor linear
  vbeta = theta[1:p]
  # parâmetros de forma alfa e nu
  alpha = theta[p+1]
  nu = theta[p+2]
  # preditor linear (valores ajustados)
  vmu = Xdat%*%vbeta
  # termos que compõem a função de verossimilhança 
  vxi1 = nu*cosh(nu*(ydat - vmu))/alpha
  vxi2 = 2*sinh(nu*(ydat - vmu))/alpha
  
  # termos que compõem a função escore 
  va = 2*vxi1*vxi2 - (nu^2)*.5*(vxi2/vxi1)
  Ubeta = t(Xdat)%*%va
  Ualpha = sum((vxi2^2 - 1)/alpha)
  Unu = sum( 1/nu + (vxi2/vxi1)*(nu/2)*(ydat - vmu) - 
              vxi1*vxi2*2*(ydat - vmu)/nu )
  return(c(Ubeta,Ualpha,Unu))
}

# matriz hessiana da função de log-verossimilhança do modelo GBS2RM
gbs2rm_hessian = function(theta,ydat,Xdat){
  # número de regressores
  p = length(theta) - 2
  # número de observações
  n = length(ydat)
  # vetor dos parâmetros do preditor linear
  vbeta = theta[1:p]
  # parâmetros de forma alfa e nu
  alpha = theta[p+1]
  nu = theta[p+2]
  # preditor linear (valores ajustados)
  vmu = Xdat%*%vbeta
  # termos que compõem a função de verossimilhança 
  vxi1 = nu*cosh(nu*(ydat - vmu))/alpha
  vxi2 = 2*sinh(nu*(ydat - vmu))/alpha
  vcosh2 = cosh(2*nu*(ydat - vmu))
  # matriz que armazenará a hessiana
  mHess = matrix(0,p+2,p+2)
  
  # termos que compõem a hessiana
  vb = c((-3*(vxi2^2) + 1)/(alpha^2))
  vc = c(4*vxi1*vxi2*(ydat - vmu)/(alpha*nu))
  vd = c(-4*vxi1*vxi2/alpha)
  vf = c(-1/nu^2 + ((ydat - vmu)*nu/(alpha*vxi1))^2 -
           4*((ydat - vmu)^2)*vcosh2/(alpha^2) )
  vg = c( -nu*(ydat - vmu)/(cosh(nu*(ydat - vmu))^2) - tanh(nu*(ydat - vmu)) +
            4*nu*vcosh2*(ydat - vmu)/(alpha^2) + 2*sinh(2*nu*(ydat - vmu))/(alpha^2) )
  vh = c((nu^2)*( (1/cosh(nu*(ydat - vmu)))^2 - 4*vcosh2/(alpha^2) ))
  mHess[c(1:p),c(1:p)] = t(Xdat)%*%diag(c(vh))%*%Xdat
  mHess[c(1:p),(p+1)] = t(Xdat)%*%vd
  mHess[(p+1),c(1:p)] = t(vd)%*%Xdat
  mHess[c(1:p),(p+2)] = t(Xdat)%*%vg
  mHess[(p+2),c(1:p)] = t(vg)%*%Xdat
  mHess[(p+1),(p+1)] = sum(vb)
  mHess[(p+2),(p+2)] = sum(vf)
  mHess[(p+1),(p+2)] = mHess[(p+2),(p+1)] = sum(vc)
  
  return(mHess)
}

# função para calcular a matriz de perturbação do modelo GBS2RM. São 
# considerados os esquemas de ponderação de casos, perturbação na variável
# resposta e perturbação em um preditor. Ao utilizar a última opção, é 
# necessário informar qual preditor está sendo considerado, colando o
# número da sua coluna na matriz do modelo na variável pred_pert
gbs2rm_perturbationmat = function(theta,ydat,Xdat, perturbation = c("caseweight","response","predictor"), pred_pert=NULL){
  # número de regressores
  p = length(theta) - 2
  # número de observações
  n = length(ydat)
  # vetor dos parâmetros do preditor linear
  vbeta = theta[1:p]
  # parâmetros de forma alfa e nu
  alpha = theta[p+1]
  nu = theta[p+2]
  # preditor linear (valores ajustados)
  vmu = Xdat%*%vbeta
  # termos que compõem a função de verossimilhança 
  vxi1 = nu*cosh(nu*(ydat - vmu))/alpha
  vxi2 = 2*sinh(nu*(ydat - vmu))/alpha

  # esquema de ponderação de casos
  if(perturbation=="caseweight"){
  Da = t((vxi2^2 - 1)/alpha)
  Dnu = t(1/nu + (vxi2/vxi1)*nu*.5*(ydat - vmu) - vxi2*vxi1*(2/nu)*(ydat - vmu))
  va = c(2*vxi2*vxi1 - (nu^2)*.5*(vxi2/vxi1))
  Dbeta = t(Xdat)%*%diag(va)
  }
  # esquema de perturbação na variável resposta
  if(perturbation=="response"){
    Sy = sd(ydat)
    Da = t( 4*Sy*vxi2*vxi1/alpha )
    Dnu = t( nu*Sy*(ydat - vmu)/(cosh(nu*(ydat - vmu))^2) + Sy*tanh(nu*(ydat - vmu)) - 
              4*nu*Sy*(ydat - vmu)*cosh(2*nu*(ydat - vmu))/(alpha^2) - 
               4*Sy*sinh(nu*(ydat - vmu))*cosh(nu*(ydat - vmu))/(alpha^2))
    vm = (nu^2)*c( 4*cosh(2*nu*(ydat - vmu))/(alpha^2) - (1/cosh(nu*(ydat - vmu)))^2 )
    Dbeta = Sy*t(Xdat)%*%diag(vm)
  }
  # esquema de perturbação em um preditor
  if(perturbation=="predictor"){
    Sx = sd(Xdat[,pred_pert])
    Da = t( -4*Sx*vbeta[pred_pert]*vxi2*vxi1/alpha )
    Dnu = -Sx*vbeta[pred_pert]*t( (nu^3)*(ydat - vmu)/(alpha*vxi1)^2 + nu*.5*(vxi2/vxi1) - 
               4*nu*(ydat - vmu)*cosh(2*nu*(ydat - vmu))/(alpha^2) - 
               2*vxi2*vxi1/nu )
    vo1 = (nu^2)*c( (1/cosh(nu*(ydat - vmu)))^2 - 
                  4*cosh(2*nu*(ydat - vmu))/(alpha^2) )
    vo2 = nu*c( 2*sinh(2*nu*(ydat - vmu))/(alpha^2) - tanh(nu*(ydat - vmu)) )
    vqj = rep(0,p); vqj[pred_pert] = 1
    Dbeta = Sx*vbeta[pred_pert]*t(Xdat)%*%diag(vo1) + Sx*vqj%*%t(vo2)
  }
  D = rbind(Dbeta,Da,Dnu)
  return(D)
}

# função que retorna a matriz de alavanca generalizada do modelo GBS2RM
# o tipo da matriz de alavancagem deve ser especificado na variável type,
# indicando se é referente ao vetor theta, de todos parâmetros, ou ao
# vetor beta, parâmetros dos regressores
gbs2rm_leverage = function(theta,ydat,Xdat,type=c("theta","beta")){
  # número de regressores
  p = length(theta) - 2
  # número de observações
  n = length(ydat)
  # vetor dos parâmetros do preditor linear
  vbeta = theta[1:p]
  # parâmetros de forma alfa e nu
  alpha = theta[p+1]
  nu = theta[p+2]
  # preditor linear (valores ajustados)
  vmu = Xdat%*%vbeta
  # termos que compõem a função de verossimilhança 
  vxi1 = nu*cosh(nu*(ydat - vmu))/alpha
  vxi2 = 2*sinh(nu*(ydat - vmu))/alpha
  
  if(type=="theta"){
  # termos que compõem a matriz derivadas segundas em relação a theta e y
  Da = t( 4*vxi2*vxi1/alpha )
  Dnu = t( nu*(ydat - vmu)/(cosh(nu*(ydat - vmu))^2) + tanh(nu*(ydat - vmu)) - 
           4*nu*(ydat - vmu)*cosh(2*nu*(ydat - vmu))/(alpha^2) - 
           4*sinh(nu*(ydat - vmu))*cosh(nu*(ydat - vmu))/(alpha^2) )
  vm = (nu^2)*c( 4*cosh(2*nu*(ydat - vmu))/(alpha^2) - (1/cosh(nu*(ydat - vmu)))^2 )
  Dbeta = t(Xdat)%*%diag(vm)
    
  Lty = rbind(Dbeta,Da,Dnu)
  
  # matriz de derivadas do valor predito em relação a theta
  Dt = cbind(Xdat, rep(0,n), rep(0,n))
  # matriz de alavanca generalizada
  GL = Dt%*%solve(-gbs2rm_hessian(theta,ydat,Xdat))%*%Lty
  }
  if(type=="beta"){
    # termos que compõem a matriz derivadas segundas em relação a beta e y
#    vh = c(-(nu^2)*(4/(alpha^2) + 2*(vxi2^2) - 1 + (nu^2)*.25*((vxi2/vxi1)^2) ))
    # nesse substituímos um valor usando o fato da esperança da função escore
    # para alfa ser zero
    vh = c(-(nu^2)*(4/(alpha^2) + 1 + (nu^2)*.25*((vxi2/vxi1)^2) ))
    mV = diag(vh)
    # matriz de alavanca generalizada
    GL = Xdat%*%solve(t(Xdat)%*%mV%*%Xdat)%*%t(Xdat)%*%mV
  }
  
  return(GL)
}

# função que retorna a distância de Cook generalizada para uma observação
#  do modelo GBS2RM. O índice da observação analisada é armazanado na 
# variável obs.
gbs2rm_gcookdist = function(theta,obs,ydat,Xdat){
  # número de regressores
  p = length(theta) - 2
  # número de observações
  n = length(ydat)
  # vetor da variável resposta sem a i-ésima observação, com i=obs
  y_i = ydat[-obs]
  # matriz do modelo sem a i-ésima linha, com i=obs
  X_i = Xdat[-obs,]
  # matriz hessiana do modelo completo, com todos os dados
  Ltt = gbs2rm_hessian(theta,ydat,Xdat)
  # função escore do modelo sem considerar a i-ésima observação
  Lt_i = gbs2rm_score(theta,y_i,X_i)
  # inverso da matriz de informação observada do modelo completo
  Ji = solve(-Ltt)
  # aproximação por um passo da estimativa de theta sem a i-ésima observação
  theta_i = theta + Ji%*%(Lt_i)
  
  # distância de Cook generalizada para o vetor de parâmetros theta
  GD_theta = t(Lt_i)%*%Ji%*%(Lt_i)
  # distância de Cook generalizada do vetor dos parâmetros dos regressores
  GD_beta = t(Lt_i[c(1:p)])%*%Ji[c(1:p),c(1:p)]%*%(Lt_i[c(1:p)])
  # distância de Cook generalizada do vetor dos parâmetros de forma, alfa e nu
  GD_shape = t(Lt_i[c(p+1,p+2)])%*%Ji[c(p+1,p+2),c(p+1,p+2)]%*%(Lt_i[c(p+1,p+2)])

  return(list(GD_theta=GD_theta, GD_beta=GD_beta, GD_shape=GD_shape))
}

# função de log-verossimilhança do modelo GBS2RM com sinal trocado e tendo
# apenas o vetor de parâmetros como argumento. Esse formato de função é 
# necessário para realizar a otimização usando o optim.
# variavel resposta deve estar armazenada na variável ydat
# as variaveis explicativas devem estar armazenadas na variável Xdat
gbs2rm_loglik2 = function(theta){ -gbs2rm_loglik(theta,ydat,Xdat) }

# função para obter resíduos do modelo GBS2RM. O tipo de resíduo deve ser
# indicado na variável type, sendo as opções: resído de Cox-Snell generealizados;
# resíduo componente do desvio; resíduo log-GBS2
gbs2rm_resid = function(theta,ydat,Xdat,type=c("CoxSnell","DevComp","lGBS2")){
  # número de regressores
  p = length(theta) - 2
  # número de observações
  n = length(ydat)
  # vetor dos parâmetros do preditor linear
  vbeta = theta[1:p]
  # parâmetros de forma alfa e nu
  alpha = theta[p+1]
  nu = theta[p+2]
  # preditor linear (valores ajustados)
  vmu = Xdat%*%vbeta

  # Resíduo log-GBS2 
  vxi2 = 2*sinh(nu*(ydat - vmu))/alpha
  if(type=="lGBS2"){
    resid = vxi2
  }
  if(type=="CoxSnell"){
    # Resíduo de Cox-Snell generalizados
    resid = -log(1-pnorm(vxi2))
  }
  if(type=="DevComp"){
    # Resíduo componente do desvio
    resid = sign(ydat - vmu)*sqrt(-2*log(cosh(nu*(ydat - vmu))) + vxi2^2)
  }
  
  return(resid=resid)
}

