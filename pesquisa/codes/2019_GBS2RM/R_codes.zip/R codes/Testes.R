source("GBS2RM_functions.R")

#dados_loglik = rgbs2(100,1,1,1)
loglik_gbs2 = function(theta_loglik){
#  n = length(data_loglik)
  a_loglik <- theta_loglik[1]
  b_loglik <- theta_loglik[2]
  nu_loglik <- theta_loglik[3]
#  L = rep(0,n)
#  for(i in 1:n){L[i] = dgbs2(data_loglik[i],a,b,nu)}
#  loglik = sum(log(L))
#  return(-loglik)
  return(loglik=-sum(log(dgbs2(dados_loglik,a_loglik,b_loglik,nu_loglik)))/length(dados_loglik))
}

# gerando dados da GBS2
theta0 = c(.3,.5,.9)
n = 100000
dados_loglik = rgbs2(n,theta0[1],theta0[2],theta0[3])
loglik_gbs2(theta0)
sum(log(dgbs2(dados_loglik,theta0[1],theta0[2],theta0[3])))

require(numDeriv)
hessian(loglik_gbs2,theta0)
grad(loglik_gbs2,theta0)

# matriz hessiana analítica da GBS2
hessian_gbs2(dados_loglik,theta0[1],theta0[2],theta0[3])
# estimando os parâmetros pelo optim
mod = optim(theta0,loglik_gbs2,hessian=TRUE)
mod
# matriz hessiana numerica do optim
mod$hessian
# informação de beta estimada numericamente do optim
mod$hessian[2,2]


# matriz hessiana analitica da GBS2
(-hessian_gbs2(dados_loglik,mod$par[1],mod$par[2],mod$par[3]))/100000
# informação de beta pela matriz hessiana analitica da GBS2
#(-hessian_gbs2(dados_loglik,mod$par[1],mod$par[2],mod$par[3])[2,2])/100000
(-hessian_gbs2(dados_loglik,theta0[1],theta0[2],theta0[3])[2,2])/100000

#a = theta0[1]; b = theta0[2]; nu = theta0[3]
a = mod$par[1]; b = mod$par[2]; nu = mod$par[3]

# estimando a informação de beta pela expressão obtida analiticamente
x = rgbs2(1000000,a,b,nu)
I1 = mean(1/((x/b)^nu + (b/x)^nu)^2)
I2 = mean((x/b)^(2*nu) - (b/x)^(2*nu))
2*(nu^2)*(2+a^2)/((a*b)^2) - 4*(nu^2)*I1/(b^2) + nu*(1 - 1/b^2)*I2/(a^2)

# estimando a informação de beta pela expressão obtida analiticamente
I3 = -mean( -nu*((b/x)^(2*nu) - (x/b)^(2*nu) - 4*nu)/( (b*((x/b)^nu + (b/x)^nu))^2) -
              nu*((2*nu + 1)*(x/b)^(2*nu) + (2*nu - 1)*(b/x)^(2*nu))/(a*b)^2)
I3
#mean(((b/x)^(2*nu) - (x/b)^(2*nu))/( ((x/b)^nu + (b/x)^nu)^2))
#mean((x/b)^(2*nu) - (b/x)^(2*nu))
#mean((x/b)^(2*nu) + (b/x)^(2*nu)); 2 + a^2

# estimando a informação de beta pela expressão reduzida (final)
z = rnorm(1000000)
La = mean(1/((a*z)^2 +4))
2*(nu^2)*(2 + a^2)/(a*b)^2 - 4*(nu^2)*La/(b^2)
