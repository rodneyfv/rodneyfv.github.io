
library(glmnet)
library(plotmo)

dados <- read.table('./crime.txt')
head(dados)
dim(dados)

# X1 = total overall reported crime rate per 1 million residents
# X2 = reported violent crime rate per 100,000 residents
# X3 = annual police funding in $/resident
# X4 = % of people 25 years+ with 4 yrs. of high school
# X5 = % of 16 to 19 year-olds not in highschool and not highschool graduates.
# X6 = % of 18 to 24 year-olds in college
# X7 = % of people 25 years+ with at least 4 years of college
colnames(dados) <- c('taxa_crime', 'taxa_crime_violento', 'policia',
                     'em', 'fora_em', 'facul',
                     'facul4')

summary(dados)

# variáveis
y <- dados$taxa_crime
X <- dados[,c(3,4,5,6,7)]
n <- nrow(X)
p <- ncol(X)

# variáveis padronizadas
ypad <- y - mean(y)
Xpad <- matrix(0, nrow=n, ncol=p)
for (j in 1:p) {
  Xpad[,j] <- (X[,j] - mean(X[,j]))/sd((X[,j] - mean(X[,j])))
}
colnames(Xpad) <- colnames(X)



# escolhendo a penalização para o lasso via validação cruzada
cv_lasso_fit <- cv.glmnet(Xpad, ypad, type.measure = 'mse', nfolds = 10)
cv_lasso_fit$lambda.min
# png(file="crime_mse_cv_lambdas.png", 
#    width=600, height=500, res = 100)
plot(cv_lasso_fit, sign.lambda = 1)
# dev.off()

# Ajuste do lasso
lasso_fit <- glmnet(Xpad, ypad, family = 'gaussian', alpha = 1,
                    intercept = FALSE)
coef(lasso_fit, s = cv_lasso_fit$lambda.min)  

# png(file="trajetoria_lasso_estim.png", 
#     width=600, height=600, res = 100)
plotmo::plot_glmnet(lasso_fit, ylab='coeficientes', lwd=2, 
                    main='lasso', cex.main=2)
# dev.off()

# calculando erro padrão para as estimativas do lasso usando bootstrap
B <- 500
boot_coef <- matrix(NA, nrow = B, ncol = p)
for (b in 1:B) {
  idx <- sample(1:n, replace = TRUE)
  fit_b <- glmnet(Xpad[idx, ], ypad[idx], family = 'gaussian', alpha = 1,
                  intercept = FALSE)
  # [-1] remove o intercepto
  boot_coef[b, ] <- as.vector(coef(fit_b, s = cv_lasso_fit$lambda.min)[-1])
}
# erros padrão bootstrap
boot_ep <- apply(boot_coef, 2, sd)
boot_ep


# Ajuste de uma regressão ridge
ridge_fit <- glmnet(Xpad, ypad, family = 'gaussian', alpha = 0,
                    intercept = FALSE)

# png(file="trajetoria_ridge_estim.png", 
#     width=600, height=600, res = 100)
plotmo::plot_glmnet(ridge_fit, ylab='coeficientes', lwd=2, 
                    main='Ridge', cex.main=2)
# dev.off()

# Ajuste de mínimos quadrados ordinários
mqo_fit <- lm(ypad ~ -1 + Xpad)
sumario_mqo_fit <- summary(mqo_fit)


# Ajuste de mínimos quadrados ordinários usando somente as 
# variáveis selecionadas com o lasso
mqo_fit <- lm(ypad ~ -1 + Xpad)
var_selec_lasso <- which(coef(lasso_fit, s = cv_lasso_fit$lambda.min)[-1] != 0)

mqo_fit_relax_lasso <- lm(ypad ~ -1 + Xpad[,var_selec_lasso])
summary(mqo_fit_relax_lasso)
sumario_mqo_fit_relax_lasso <- summary(mqo_fit_relax_lasso)



# Estimativas e erros padrão com MQO
round(sumario_mqo_fit$coefficients[,1:2], 2)
# Estimativas e erros padrão (bootstrap) do lasso
round(cbind(coef(lasso_fit, s = cv_lasso_fit$lambda.min)[-1], boot_ep), 2)
# estimativas e erros padrão do lasso+MQO
round(sumario_mqo_fit_relax_lasso$coefficients[,1:2], 2)
