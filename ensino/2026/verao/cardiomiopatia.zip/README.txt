Dados de cardiomiopatia analisados no livro de Fan et al (Statistical Foundations of Data Science, p. 429) 
e disponibilizados pelos autores.

Para maiores detalhes, ver os links abaixo:
https://runzelipsu.github.io/DataScience/
https://runzelipsu.github.io/DataScience/dataset/ch8/Ro131_des.txt
https://runzelipsu.github.io/DataScience/dataset/ch8/Genenum.csv
https://runzelipsu.github.io/DataScience/dataset/ch8/Ro131.csv
