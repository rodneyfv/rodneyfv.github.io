rm(list = ls())
library(glmnet)
library(monomvn)

set.seed(2025)

# Fonte dos dados:
# https://hastie.su.domains/StatLearnSparsity/data.html

# Dados do estudo de diabetes
dados <- read.table('./diabetesdata.txt', header = TRUE)
# View(dados)
# View(data_quadmodel)
dim(dados)
names(dados)

###################################
# Organizando os dados para o modelo
n <- nrow(dados)
p <- ncol(dados) - 1

# normalizando os dados
x <- matrix(NA, nrow=n, ncol=p)
for(i in 1:p){
  x[,i] <- (dados[,i] - mean(dados[,i]))/(sd(dados[,i])*sqrt(n-1))
}
y <- (dados$Y - mean(dados$Y))/(sd(dados$Y)*sqrt(441))

colnames(x) <- colnames(dados[,1:p])
head(x)

###################################
# ajuste do lasso
lasso_fit <- glmnet::glmnet(x, y, family = 'gaussian', intercept = FALSE,
                            alpha = 1)

# png(file="diabetes_lasso_path.png", 
#      width=600, height=500, res = 100)
plot(lasso_fit, xvar = 'lambda', sign.lambda = 1, 
     lwd=2, ylab='Coeficientes')
# dev.off()

# validação cruzada para escolher lambda
cv_lasso_fit <- glmnet::cv.glmnet(x, y, family = 'gaussian', intercept = FALSE,
                                  alpha = 1, type.measure = 'mse', nfolds = 10) 

# png(file="diabetes_lasso_mse_cv.png", 
#     width=600, height=500, res = 100)
plot(cv_lasso_fit, sign.lambda = 1)
# dev.off()

# coeficientes estimados usando o lambda 'ótimo'
cv_lasso_fit$lambda.1se
id_labda_min <- which(lasso_fit$lambda == cv_lasso_fit$lambda.1se)
beta_hat_lasso <- coef(lasso_fit, s=lasso_fit$lambda[id_labda_min])
beta_hat_lasso



###################################
# ajuste do lasso Bayesiano

n_mcmc <- 5000 # iteracoes de MCMC
n_thin <- 5 # lag entre os valores mantidos
burnin <- 1000 # numero de valores iniciais descartados

blasso_fit <- blasso(X = x,
              y = y,
              icept = FALSE,
              T = n_mcmc,      
              thin = n_thin,      
              verb = 1)

blasso_fit_summary <- summary(blasso_fit)

dim(blasso_fit$beta)
plot(blasso_fit)

beta_mcmc <- blasso_fit$beta[-c(1:burnin),]
lambda2_mcmc <- blasso_fit$lambda2[-c(1:burnin)]
s2_mcmc <- blasso_fit$s2[-c(1:burnin)]

# algumas cadeias de MCMC
dim(beta_mcmc)

# png(file="diabetes_blasso_mcmc.png", 
#     width=1000, height=500, res = 100)
# par(mfrow=c(1,3), mar = c(4,4,1,1), mgp=c(2.5,1,0))
plot(beta_mcmc[,1], type='l', ylab=expression(beta[1]),
     cex.lab=1.5)
plot(beta_mcmc[,2], type='l', ylab=expression(beta[2]),
     cex.lab=1.5)
plot(s2_mcmc, type='l', ylab=expression(sigma^2),
     cex.lab=1.5)
# dev.off()

# histograma da distribuicao a posteriori
# png(file="diabetes_blasso_beta2_hist.png", 
#     width=800, height=500, res = 100)
hist(beta_mcmc[,2], prob=TRUE, xlab=expression(beta[2]), ylab='Frequência',
     xlim=c(-.3, .3), cex.lab=1.5, main="", col='gray')
tmp <- seq(-.3, .3, length=1000)
lines(tmp, exp(-abs(tmp)/sd(y))/(2*sd(y)), col='red', lwd=2)
legend("topright", legend=c('posteriori', 'priori'), 
       fill=c('gray', 'red'), bty='n', cex = 1.5)
# dev.off()


# boxplot dos betas gerados via MCMC

# png(file="diabetes_blasso_boxplots.png", 
#     width=800, height=500, res = 100)
boxplot(beta_mcmc, names=c(expression(beta[1]),expression(beta[2]),
                           expression(beta[3]),expression(beta[4]),
                           expression(beta[5]),expression(beta[6]),
                           expression(beta[7]),expression(beta[8]),
                           expression(beta[9]),expression(beta[10])),
        ylab="Coeficientes")
abline(h=0, lty=2, lwd=2, col='red')
# dev.off()

# médias, erro padrão e quantis a posteriori
round(apply(beta_mcmc, 2, mean), 4)
round(apply(beta_mcmc, 2, sd), 4)
round(apply(beta_mcmc, 2, function(x) quantile(x, c(.025, .975))), 4)

## sumário da variância
plot(blasso_fit, burnin=100, which="s2")
blasso_fit_summary$s2


## sumário do parâmetro de penalização
plot(blasso_fit, burnin=200, which="lambda2")
blasso_fit_summary$lambda2



