library(glmnet)
source("lasso_inference.R")

set.seed(2025)

# Fonte dos dados:
# https://hastie.su.domains/StatLearnSparsity/data.html

# Dados do estudo de diabetes
dados <- read.table('./diabetesdata.txt', header = TRUE)
data_quadmodel <- read.table('./diabetes_data_quadmodel.txt', header = TRUE)
# View(dados)
# View(data_quadmodel)
dim(dados)
dim(data_quadmodel)
names(dados)

###################################

# dados com variaveis do modelo quadratico normalizadas
x <- as.matrix(data_quadmodel)
colnames(x) <- colnames(data_quadmodel)
colnames(x)[1:15]
# normalizando os dados da variavel resposta
y <- (dados$Y - mean(dados$Y))/(sd(dados$Y)*sqrt(441))

# dimensao dos dados
n <- nrow(x)
p <- ncol(x)


###################################
# ajuste do lasso
lasso_fit <- glmnet::glmnet(x, y, family = 'gaussian', intercept = FALSE,
                            alpha = 1)

# png(file="diabetes_quad_lasso_path.png",
#      width=600, height=500, res = 100)
plot(lasso_fit, xvar = 'lambda', sign.lambda = 1, 
     lwd=2, ylab='Coeficientes')
# dev.off()

# validação cruzada para escolher lambda
cv_lasso_fit <- glmnet::cv.glmnet(x, y, family = 'gaussian', intercept = FALSE,
                                  alpha = 1, type.measure = 'mse', nfolds = 10) 

# png(file="diabetes_quad_lasso_mse_cv.png",
#     width=600, height=500, res = 100)
plot(cv_lasso_fit, sign.lambda = 1)
# dev.off()

# coeficientes estimados usando o lambda 'ótimo'
cv_lasso_fit$lambda.min
beta_hat_lasso <- coef(lasso_fit, s=cv_lasso_fit$lambda.min)
sum(beta_hat_lasso!=0)

# png(file="diabetes_quad_lasso_coefs.png",
#     width=600, height=500, res = 100)
plot(beta_hat_lasso[2:(p+1)], pch=' ', cex.lab=1.4, 
     cex.axis=1.5, cex=1, lwd = 1.5, ylab='Estimativa', xlab='índice')
grid()
abline(h=0, lwd=0.5, lty=2, col='red')
points(beta_hat_lasso[2:(p+1)], col="black", pch=20)
# dev.off()

# dez maiores estimativas pelo lasso
id_top10 <- order(abs(beta_hat_lasso), decreasing = TRUE)[1:10]
round(beta_hat_lasso[id_top10], 4)
colnames(x)[id_top10]

# require(xtable)
# xtable(cbind(id_top10, round(beta_hat_lasso[id_top10], 2)))

###################################
# ajuste do lasso deviesado

devlasso_fit <- SSLasso(x,y,verbose = TRUE, alpha = .05, intercept = FALSE, 
                        lambda = cv_lasso_fit$lambda.1se)

lmin <- max(devlasso_fit$up.lim)
lmax <- min(devlasso_fit$low.lim)

# png("diabetes_quad_devlasso_coefs.png",
#     width=600, height=500, res = 100)
plot(devlasso_fit$coef, ylim=c(lmin, lmax), pch=20, cex.lab=1.4, 
     cex.axis=1.5, cex=1, lwd = 1.5, ylab='Estimativa', xlab='índice')
grid()
for(j in 1:p){
  segments(j,devlasso_fit$low.lim[j],j,devlasso_fit$up.lim[j], 
           col="orange",lwd=2)
}
abline(h=0, lwd=0.5, lty=2, col='red')
points(devlasso_fit$unb.coef,col="blue", pch=20)
points(devlasso_fit$coef, col="black", pch=20)
legend("bottomright",c("Lasso","Lasso deviesado","IC de 95%"),
       col=c("black","blue","orange"),pch=c(20,20,NA_integer_),
       lty = c(0,0,1), bty='n', cex=1.1,lwd=2)
# dev.off()


# indices dos ICs que contem zero mas cuja estimativa lasso é diferente de zero
lasso_vs_devlasso <- (devlasso_fit$coef!=0)*(devlasso_fit$up.lim>0)*
  (devlasso_fit$low.lim<0)
id_dif <- which(lasso_vs_devlasso == 1)
id_dif

# png("diabetes_quad_lassodif0_coefs_IC_comzero.png",
#     width=600, height=500, res = 100)
plot(devlasso_fit$coef, ylim=c(lmin, lmax), pch=' ', cex.lab=1.4, 
     cex.axis=1.5, cex=1, lwd = 1.5, ylab='Estimativa', xlab='índice')
grid()
for(j in id_dif){
  segments(j,devlasso_fit$low.lim[j],j,devlasso_fit$up.lim[j], 
           col="orange",lwd=2)
}
abline(h=0, lwd=0.5, lty=2, col='red')
points(id_dif, devlasso_fit$unb.coef[id_dif],col="blue", pch=20)
points(id_dif, devlasso_fit$coef[id_dif], col="black", pch=20)
legend("bottomright",c("Lasso","Lasso deviesado","IC de 95%"),
       col=c("black","blue","orange"),pch=c(20,20,NA_integer_),
       lty = c(0,0,1), bty='n', cex=1.1,lwd=2)
# dev.off()


# png("diabetes_quad_devlasso_pvalor.png",
#     width=600, height=500, res = 100)
plot(devlasso_fit$pvals, type='h', cex.lab=1.4, 
     cex.axis=1.5, cex=1, lwd = 1.5, ylab='Valor-p', xlab='índice')
abline(h=0.05, lty=2, col='red', lwd=2)
# dev.off()
# quais covariaveis ficaram com valor-p abaixo de 5%
which(devlasso_fit$pvals < 0.05)

# comparação do top-10 do lasso com valores pelo lasso deviesado
id_top10 <- order(abs(beta_hat_lasso), decreasing = TRUE)[1:10]
round(beta_hat_lasso[id_top10], 4)
round(devlasso_fit$unb.coef[id_top10], 4)
round(devlasso_fit$low.lim[id_top10], 4)
round(devlasso_fit$up.lim[id_top10], 4)
colnames(x)[id_top10]

# xtable(cbind(id_top10, round(beta_hat_lasso[id_top10], 2),
#              round(devlasso_fit$unb.coef[id_top10], 2),
#              round(devlasso_fit$low.lim[id_top10], 2),
#              round(devlasso_fit$up.lim[id_top10], 2)))

