library(glmnet)

set.seed(2025)

# Fonte dos dados:
# https://hastie.su.domains/StatLearnSparsity/data.html

# Dados do estudo de diabetes
dados <- read.table('./diabetesdata.txt', header = TRUE)
data_quadmodel <- read.table('./diabetes_data_quadmodel.txt', header = TRUE)
# View(dados)
# View(data_quadmodel)
dim(dados)
dim(data_quadmodel)
names(dados)

###################################
# Organizando os dados para o modelo
n <- nrow(dados)
p <- ncol(dados) - 1

# normalizando os dados
x <- matrix(NA, nrow=n, ncol=p)
for(i in 1:p){
  x[,i] <- (dados[,i] - mean(dados[,i]))/(sd(dados[,i])*sqrt(n-1))
}
y <- (dados$Y - mean(dados$Y))/(sd(dados$Y)*sqrt(441))

colnames(x) <- colnames(dados[,1:p])
head(x)

###################################
# ajuste do lasso
lasso_fit <- glmnet::glmnet(x, y, family = 'gaussian', intercept = FALSE,
                            alpha = 1)

# png(file="diabetes_lasso_path.png", 
#      width=600, height=500, res = 100)
plot(lasso_fit, xvar = 'lambda', sign.lambda = 1, 
     lwd=2, ylab='Coeficientes')
# dev.off()

# validação cruzada para escolher lambda
cv_lasso_fit <- glmnet::cv.glmnet(x, y, family = 'gaussian', intercept = FALSE,
                                  alpha = 1, type.measure = 'mse', nfolds = 10) 

# png(file="diabetes_lasso_mse_cv.png", 
#     width=600, height=500, res = 100)
plot(cv_lasso_fit, sign.lambda = 1)
# dev.off()

# coeficientes estimados usando o lambda 'ótimo'
cv_lasso_fit$lambda.1se
beta_hat_lasso <- coef(lasso_fit, s=cv_lasso_fit$lambda.1se)
beta_hat_lasso


###################################
# Bootstrap

B <- 300 # numero de replicas bootstrap

# arrays para salvar as replicas bootstrap
lasso_fit_boot <- list()
lasso_fit_boot$beta_hat_lasso <- matrix(NA, nrow=B, ncol=p)
lasso_fit_boot$lambda1se <- rep(NA, B)
coefpath_boot <- list()
lambda_boot <- list()

for(b in 1:B){
  # reamostragem bootstrap
  id_boot <- sample(1:n, replace = TRUE)
  x_boot <- x[id_boot, ]
  y_boot <- y[id_boot]
  
  # modelo estimado bootstrap
  cv_lasso_star <- glmnet::cv.glmnet(x_boot, y_boot, family = 'gaussian', 
                                         intercept = FALSE, alpha = 1, 
                                         type.measure = 'mse', nfolds = 10) 

  # estimativas boostrap
  lambda_star <- cv_lasso_star$lambda.1se
  beta_hat_lasso_star <- coef(cv_lasso_star$glmnet.fit, s=lambda_star)
  
  lasso_fit_boot$beta_hat_lasso[b,] <- as.numeric(beta_hat_lasso_star[2:(p+1)])
  lasso_fit_boot$lambda1se[b] <- lambda_star
  
  coefpath_boot[[b]] <- cv_lasso_star$glmnet.fit$beta
  lambda_boot[[b]] <- cv_lasso_star$glmnet.fit$lambda
  
  # progresso
  cat(paste(floor(100*b/B),'%\n'))
}


# png(file="diabetes_boot_beta1_beta2_lambda.png",
#     width=1000, height=500, res = 100)
# par(mfrow=c(1,3), mar = c(4,4,1,1), mgp=c(2.5,1,0))
# beta 1
lmin <- min(lasso_fit_boot$beta_hat_lasso[,1])
lmax <- max(lasso_fit_boot$beta_hat_lasso[,1])
hist(lasso_fit_boot$beta_hat_lasso[,1], prob=TRUE, 
     xlab=expression(beta[1]), ylab='Frequência',
     xlim=c(lmin-.01, lmax+.01), cex.lab=1.5, main="", col='gray')
# beta 2
lmin <- min(lasso_fit_boot$beta_hat_lasso[,2])
lmax <- max(lasso_fit_boot$beta_hat_lasso[,2])
hist(lasso_fit_boot$beta_hat_lasso[,2], prob=TRUE, 
     xlab=expression(beta[2]), ylab='Frequência',
     xlim=c(lmin-.01, lmax+.01), cex.lab=1.5, main="", col='gray')
# lambda
lmin <- min(lasso_fit_boot$lambda1se)
lmax <- max(lasso_fit_boot$lambda1se)
hist(lasso_fit_boot$lambda1se, prob=TRUE,
     xlab=expression(lambda), ylab='Frequência',
     xlim=c(lmin-.001, lmax+.001), cex.lab=1.5, main="", col='gray')
# dev.off()


# png(file="diabetes_boot_lassopath.png",
#     width=1000, height=500, res = 100)
# par(mfrow=c(1,2), mar = c(4,4,1,1), mgp=c(2.5,1,0))
# beta 1
plot(-log(lasso_fit$lambda), lasso_fit$beta[1,], type='n',
     xlab=expression(-log(lambda)), ylab=expression(beta[1]), cex.lab=1.5,
     ylim=c(-.1, .1))
for(b in 1:B){
  lines(-log(lambda_boot[[b]]), coefpath_boot[[b]][1,], col='LightGray')
}
lines(-log(lasso_fit$lambda), lasso_fit$beta[1,], col='Red', lwd=2)
abline(v=-log(cv_lasso_fit$lambda.1se), lty=2, lwd=2, col=1)
# beta 2
plot(-log(lasso_fit$lambda), lasso_fit$beta[2,], type='n',
     xlab=expression(-log(lambda)), ylab=expression(beta[2]), cex.lab=1.5,
     ylim=c(-.25, .1))
for(b in 1:B){
  lines(-log(lambda_boot[[b]]), coefpath_boot[[b]][2,], col='LightGray')
}
lines(-log(lasso_fit$lambda), lasso_fit$beta[2,], col='Red', lwd=2)
abline(v=-log(cv_lasso_fit$lambda.1se), lty=2, lwd=2, col=1)
# dev.off()

# png(file="diabetes_boot_boxplots.png",
#     width=800, height=500, res = 100)
boxplot(lasso_fit_boot$beta_hat_lasso,
        names=c(expression(beta[1]),expression(beta[2]),
                  expression(beta[3]),expression(beta[4]),
                  expression(beta[5]),expression(beta[6]),
                  expression(beta[7]),expression(beta[8]),
                  expression(beta[9]),expression(beta[10])),
        ylab="Coeficientes", cex.lab=1.5)
abline(h=0, lty=2, lwd=2, col='red')
# dev.off()

# png(file="diabetes_boot_probzero.png",
#     width=800, height=500, res = 100)
barplot(colMeans(lasso_fit_boot$beta_hat_lasso==0),
        ylab = 'Probabilidade de ser zero',
        names=c(expression(beta[1]),expression(beta[2]),
                expression(beta[3]),expression(beta[4]),
                expression(beta[5]),expression(beta[6]),
                expression(beta[7]),expression(beta[8]),
                expression(beta[9]),expression(beta[10])), 
        cex.lab=1.5)
# dev.off()

# erros padrão bootstrap
round(apply(lasso_fit_boot$beta_hat_lasso, 2, sd), 4)
# intervalos de confiança bootstrap percentil
round(apply(lasso_fit_boot$beta_hat_lasso, 2, 
            function(x) quantile(x, c(.025, .975))), 4)


